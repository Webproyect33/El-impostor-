/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback } from 'react';
import { GameState, Player, RoundInfo } from './types';
import { WORD_DATABASE, WordPair } from './data/words';
import { SplashScreen } from './components/SplashScreen';
import { IntroScreen } from './components/IntroScreen';
import { PlayerCountScreen } from './components/PlayerCountScreen';
import { PlayerNamesScreen } from './components/PlayerNamesScreen';
import { CardRevealScreen } from './components/CardRevealScreen';
import { GameActiveScreen } from './components/GameActiveScreen';
import { ExportApkModal } from './components/ExportApkModal';
import { Smartphone, Download } from 'lucide-react';
import { playSound } from './utils/audio';

const AVATAR_COLORS = [
  'from-rose-500 to-red-600',
  'from-blue-500 to-cyan-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-purple-500 to-indigo-600',
  'from-fuchsia-500 to-pink-600',
  'from-lime-500 to-emerald-600',
  'from-sky-500 to-blue-600',
  'from-violet-500 to-purple-600',
  'from-teal-500 to-green-600',
];

export default function App() {
  const [gameState, setGameState] = useState<GameState>('splash');
  const [playerCount, setPlayerCount] = useState<number>(4);
  const [playerNames, setPlayerNames] = useState<string[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [roundInfo, setRoundInfo] = useState<RoundInfo | null>(null);
  const [roundCount, setRoundCount] = useState<number>(1);
  const [showApkModal, setShowApkModal] = useState<boolean>(false);

  // Setup a new round using given or current player names
  const initializeRound = useCallback((names: string[], currentRoundNumber: number) => {
    // 1. Pick a random word pair from the 500+ database
    const randomIndex = Math.floor(Math.random() * WORD_DATABASE.length);
    const chosenWordPair: WordPair = WORD_DATABASE[randomIndex];

    // 2. Select a random player to be the Impostor
    const impostorIndex = Math.floor(Math.random() * names.length);

    // 3. Select a random player who starts the conversation / giving clues
    const startingIndex = Math.floor(Math.random() * names.length);

    // 4. Build Player instances with their secret assigned word
    const builtPlayers: Player[] = names.map((name, idx) => {
      const isImpostor = idx === impostorIndex;
      return {
        id: idx + 1,
        name: name,
        isImpostor: isImpostor,
        assignedWord: isImpostor ? chosenWordPair.impostorWord : chosenWordPair.secretWord,
        avatarColor: AVATAR_COLORS[idx % AVATAR_COLORS.length],
        hasSeenWord: false,
      };
    });

    const newRoundInfo: RoundInfo = {
      category: chosenWordPair.category,
      secretWord: chosenWordPair.secretWord,
      impostorWord: chosenWordPair.impostorWord,
      impostorPlayerId: builtPlayers[impostorIndex].id,
      startingPlayerId: builtPlayers[startingIndex].id,
      roundNumber: currentRoundNumber,
    };

    setPlayers(builtPlayers);
    setRoundInfo(newRoundInfo);
    setGameState('card_reveal');
  }, []);

  // Handlers for state transitions
  const handleSplashFinished = () => {
    setGameState('intro');
  };

  const handleIntroFinished = () => {
    setGameState('player_count');
  };

  const handlePlayerCountConfirmed = (count: number) => {
    setPlayerCount(count);
    setGameState('player_names');
  };

  const handleNamesConfirmed = (names: string[]) => {
    setPlayerNames(names);
    setRoundCount(1);
    initializeRound(names, 1);
  };

  const handleFinishCardReveal = () => {
    setGameState('game_active');
  };

  // Play another round keeping the same player names
  const handlePlayAnotherRound = () => {
    const nextRound = roundCount + 1;
    setRoundCount(nextRound);
    initializeRound(playerNames, nextRound);
  };

  // Full restart back to player count selection
  const handleFullRestart = () => {
    setGameState('player_count');
  };

  return (
    <main className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-center">
      {gameState === 'splash' && (
        <SplashScreen onComplete={handleSplashFinished} />
      )}

      {gameState === 'intro' && (
        <IntroScreen onContinue={handleIntroFinished} />
      )}

      {gameState === 'player_count' && (
        <PlayerCountScreen
          initialCount={playerCount}
          onConfirm={handlePlayerCountConfirmed}
        />
      )}

      {gameState === 'player_names' && (
        <PlayerNamesScreen
          playerCount={playerCount}
          initialNames={playerNames}
          onConfirm={handleNamesConfirmed}
          onBack={() => setGameState('player_count')}
        />
      )}

      {gameState === 'card_reveal' && roundInfo && (
        <CardRevealScreen
          players={players}
          roundInfo={roundInfo}
          onFinishReveal={handleFinishCardReveal}
        />
      )}

      {gameState === 'game_active' && roundInfo && (
        <GameActiveScreen
          players={players}
          roundInfo={roundInfo}
          onPlayAnotherRound={handlePlayAnotherRound}
          onFullRestart={handleFullRestart}
        />
      )}

      {/* Floating Preview APK Generator Button */}
      <div className="fixed top-3 right-3 z-40">
        <button
          onClick={() => {
            playSound('click');
            setShowApkModal(true);
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-red-500/40 text-xs font-semibold shadow-lg backdrop-blur transition-all active:scale-95 cursor-pointer group"
          title="Descargar ZIP y compilar APK para Android"
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="hidden sm:inline">Descargar</span>
          <span className="font-bold text-red-400">.APK</span>
        </button>
      </div>

      <ExportApkModal
        isOpen={showApkModal}
        onClose={() => setShowApkModal(false)}
      />
    </main>
  );
}
