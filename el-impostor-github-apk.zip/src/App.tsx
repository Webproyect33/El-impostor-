import React, { useState, useCallback } from 'react';
import { GameState, Player, RoundInfo } from './types';
import { WORD_DATABASE, WordPair } from './data/words';
import { SplashScreen } from './components/SplashScreen';
import { IntroScreen } from './components/IntroScreen';
import { PlayerCountScreen } from './components/PlayerCountScreen';
import { PlayerNamesScreen } from './components/PlayerNamesScreen';
import { CardRevealScreen } from './components/CardRevealScreen';
import { GameActiveScreen } from './components/GameActiveScreen';

const AVATAR_COLORS = [
  'from-rose-500 to-red-600',
  'from-blue-500 to-cyan-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-purple-500 to-indigo-600',
  'from-fuchsia-500 to-pink-600',
  'from-lime-500 to-emerald-600',
  'from-sky-500 to-blue-600',
  'from-violet-500 to-purple-600',
  'from-teal-500 to-green-600',
];

export default function App() {
  const [gameState, setGameState] = useState<GameState>('splash');
  const [playerCount, setPlayerCount] = useState<number>(4);
  const [playerNames, setPlayerNames] = useState<string[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [roundInfo, setRoundInfo] = useState<RoundInfo | null>(null);
  const [roundCount, setRoundCount] = useState<number>(1);

  const initializeRound = useCallback((names: string[], currentRoundNumber: number) => {
    const randomIndex = Math.floor(Math.random() * WORD_DATABASE.length);
    const chosenWordPair: WordPair = WORD_DATABASE[randomIndex];
    const impostorIndex = Math.floor(Math.random() * names.length);
    const startingIndex = Math.floor(Math.random() * names.length);

    const builtPlayers: Player[] = names.map((name, idx) => {
      const isImpostor = idx === impostorIndex;
      return {
        id: idx + 1,
        name: name,
        isImpostor: isImpostor,
        assignedWord: isImpostor ? chosenWordPair.impostorWord : chosenWordPair.secretWord,
        avatarColor: AVATAR_COLORS[idx % AVATAR_COLORS.length],
        hasSeenWord: false,
      };
    });

    const newRoundInfo: RoundInfo = {
      category: chosenWordPair.category,
      secretWord: chosenWordPair.secretWord,
      impostorWord: chosenWordPair.impostorWord,
      impostorPlayerId: builtPlayers[impostorIndex].id,
      startingPlayerId: builtPlayers[startingIndex].id,
      roundNumber: currentRoundNumber,
    };

    setPlayers(builtPlayers);
    setRoundInfo(newRoundInfo);
    setGameState('card_reveal');
  }, []);

  const handleSplashFinished = () => setGameState('intro');
  const handleIntroFinished = () => setGameState('player_count');
  const handlePlayerCountConfirmed = (count: number) => {
    setPlayerCount(count);
    setGameState('player_names');
  };
  const handleNamesConfirmed = (names: string[]) => {
    setPlayerNames(names);
    setRoundCount(1);
    initializeRound(names, 1);
  };
  const handleFinishCardReveal = () => setGameState('game_active');
  const handlePlayAnotherRound = () => {
    const nextRound = roundCount + 1;
    setRoundCount(nextRound);
    initializeRound(playerNames, nextRound);
  };
  const handleFullRestart = () => setGameState('player_count');

  return (
    <main className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-center">
      {gameState === 'splash' && <SplashScreen onComplete={handleSplashFinished} />}
      {gameState === 'intro' && <IntroScreen onContinue={handleIntroFinished} />}
      {gameState === 'player_count' && (
        <PlayerCountScreen initialCount={playerCount} onConfirm={handlePlayerCountConfirmed} />
      )}
      {gameState === 'player_names' && (
        <PlayerNamesScreen
          playerCount={playerCount}
          initialNames={playerNames}
          onConfirm={handleNamesConfirmed}
          onBack={() => setGameState('player_count')}
        />
      )}
      {gameState === 'card_reveal' && roundInfo && (
        <CardRevealScreen players={players} roundInfo={roundInfo} onFinishReveal={handleFinishCardReveal} />
      )}
      {gameState === 'game_active' && roundInfo && (
        <GameActiveScreen
          players={players}
          roundInfo={roundInfo}
          onPlayAnotherRound={handlePlayAnotherRound}
          onFullRestart={handleFullRestart}
        />
      )}
    </main>
  );
}
