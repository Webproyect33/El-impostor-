export type GameState = 
  | 'splash'
  | 'intro'
  | 'player_count'
  | 'player_names'
  | 'card_reveal'
  | 'game_active';

export interface Player {
  id: number;
  name: string;
  isImpostor: boolean;
  assignedWord: string;
  avatarColor: string;
  hasSeenWord: boolean;
}

export interface RoundInfo {
  category: string;
  secretWord: string;
  impostorWord: string;
  impostorPlayerId: number;
  startingPlayerId: number;
  roundNumber: number;
}
