import React, { useState, useEffect } from 'react';
import { Player, RoundInfo } from '../types';
import { RotateCcw, RefreshCw, UserX, Clock, Eye, Sparkles } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/audio';

interface GameActiveScreenProps {
  players: Player[];
  roundInfo: RoundInfo;
  onPlayAnotherRound: () => void;
  onFullRestart: () => void;
}

export const GameActiveScreen: React.FC<GameActiveScreenProps> = ({
  players,
  roundInfo,
  onPlayAnotherRound,
  onFullRestart,
}) => {
  const [showTruthModal, setShowTruthModal] = useState<boolean>(false);
  const [seconds, setSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);

  const startingPlayer = players.find((p) => p.id === roundInfo.startingPlayerId) || players[0];
  const impostorPlayer = players.find((p) => p.id === roundInfo.impostorPlayerId) || players[0];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleRevealTruth = () => {
    playSound('reveal');
    triggerHaptic(60);
    setShowTruthModal(true);
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-between items-center bg-slate-950 px-4 sm:px-6 py-8 relative overflow-hidden">
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-950/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="w-full max-w-md z-10 space-y-4">
        <div className="flex items-center justify-between">
          <span className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-slate-400">
            Ronda #{roundInfo.roundNumber} • {roundInfo.category}
          </span>
          <button
            onClick={() => setIsTimerRunning(!isTimerRunning)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-amber-400 hover:text-amber-300"
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{formatTime(seconds)}</span>
          </button>
        </div>
        <div className="w-full bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-red-500/15 border border-amber-500/30 rounded-2xl p-4 sm:p-5 text-center shadow-lg relative overflow-hidden">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 font-mono text-[11px] font-bold uppercase tracking-wider mb-2">
            🎲 Comienza la ronda
          </div>
          <h2 className="text-2xl sm:text-3xl font-heading font-black text-white">
            {startingPlayer.name}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Empieza diciendo una palabra o pista relacionada con su palabra secreta
          </p>
        </div>
      </div>
      <div className="w-full max-w-md my-auto z-10 flex flex-col items-center space-y-4">
        <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-3">
          <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 font-bold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-red-400" /> Dinámica de juego
          </h3>
          <ul className="text-xs sm:text-sm text-slate-300 space-y-2 list-disc list-inside">
            <li>Cada jugador dice <strong>una sola palabra</strong> por turno.</li>
            <li>El impostor tiene una palabra distinta y debe pasar desapercibido.</li>
            <li>Al terminar la ronda, debatan y voten quién creen que es el impostor.</li>
          </ul>
        </div>
        <button
          onClick={handleRevealTruth}
          className="w-full py-3.5 px-5 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-700 hover:border-red-500/60 text-slate-200 hover:text-white font-semibold text-sm transition-all flex items-center justify-center gap-2.5 shadow-md active:scale-98 cursor-pointer"
        >
          <Eye className="w-4 h-4 text-red-400" />
          <span>Revelar impostor y palabras secretas</span>
        </button>
      </div>
      <div className="w-full max-w-md z-10 flex flex-col gap-3 pt-2">
        <button
          onClick={() => {
            playSound('click');
            triggerHaptic(30);
            onPlayAnotherRound();
          }}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-lg shadow-[0_0_25px_rgba(225,29,72,0.5)] active:scale-95 transition-all flex items-center justify-center gap-3 border border-red-400/40 cursor-pointer"
        >
          <RefreshCw className="w-5 h-5" />
          <span>Jugar otra ronda</span>
        </button>
        <button
          onClick={() => {
            playSound('click');
            triggerHaptic(20);
            onFullRestart();
          }}
          className="w-full py-3.5 px-5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Reiniciar (Cambiar jugadores)</span>
        </button>
      </div>
      {showTruthModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border-2 border-red-500/60 rounded-3xl p-6 shadow-2xl space-y-6 text-center animate-in zoom-in-95 duration-200">
            <div className="inline-flex p-3 rounded-2xl bg-red-950/80 border border-red-800 text-red-400 shadow-inner">
              <UserX className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <span className="text-xs uppercase font-mono tracking-widest text-red-400 font-bold">
                El Impostor era:
              </span>
              <h3 className="font-heading text-3xl font-black text-white">
                {impostorPlayer.name}
              </h3>
            </div>
            <div className="space-y-3 pt-2 text-left">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-[11px] font-mono text-emerald-400 uppercase font-bold">
                  Palabra de la mayoría:
                </span>
                <p className="text-lg font-bold text-white">{roundInfo.secretWord}</p>
              </div>
              <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-800/60 space-y-1">
                <span className="text-[11px] font-mono text-red-400 uppercase font-bold">
                  Palabra del impostor ({impostorPlayer.name}):
                </span>
                <p className="text-lg font-bold text-red-200">{roundInfo.impostorWord}</p>
              </div>
            </div>
            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={() => {
                  setShowTruthModal(false);
                  onPlayAnotherRound();
                }}
                className="w-full py-3.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-base transition-colors shadow-lg"
              >
                Jugar otra ronda ahora
              </button>
              <button
                onClick={() => setShowTruthModal(false)}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
