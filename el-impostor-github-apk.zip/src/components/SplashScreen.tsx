import React, { useEffect, useState } from 'react';
import { GameLogo } from './GameLogo';
import { playSound } from '../utils/audio';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Smooth loading bar progression
    const startTime = Date.now();
    const duration = 2400; // 2.4 seconds

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.floor((elapsed / duration) * 100));
      setProgress(pct);

      if (elapsed >= duration) {
        clearInterval(interval);
        setTimeout(() => {
          playSound('alert');
          onComplete();
        }, 300);
      }
    }, 30);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="min-h-screen w-full flex flex-col justify-between items-center bg-slate-950 px-6 py-10 relative overflow-hidden select-none">
      {/* Background glow ambiance */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-rose-700/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top spacer */}
      <div className="w-full flex justify-end">
        <span className="text-[11px] font-mono tracking-widest text-slate-500 uppercase">v2.0 • Edición Fiesta</span>
      </div>

      {/* Main Logo & Loader */}
      <div className="w-full max-w-sm flex flex-col items-center my-auto space-y-10 z-10">
        <GameLogo size="xl" />

        {/* Progress Bar Container */}
        <div className="w-full space-y-2.5">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-slate-400 tracking-wider">Cargando base de datos secreta...</span>
            <span className="text-red-400 font-bold">{progress}%</span>
          </div>

          <div className="h-3 w-full bg-slate-900 border border-slate-800 rounded-full overflow-hidden p-0.5 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-amber-400 rounded-full transition-all duration-75 ease-out shadow-[0_0_12px_rgba(239,68,68,0.8)]"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Bottom Watermark Requirement: "created by Kendry" with small font */}
      <div className="z-10 text-center">
        <p className="text-xs text-slate-500 tracking-wider font-medium font-mono hover:text-slate-400 transition-colors">
          created by <span className="text-red-400 font-semibold">Kendry</span>
        </p>
      </div>
    </div>
  );
};
