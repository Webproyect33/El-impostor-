import React, { useEffect, useState, useCallback, useRef } from 'react';
import { ShieldAlert, ArrowRight, Fingerprint } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/audio';

interface IntroScreenProps {
  onContinue: () => void;
}

const WORDS = ["Cuidado,", "hay", "un", "impostor", "entre", "nosotros"];

export const IntroScreen: React.FC<IntroScreenProps> = ({ onContinue }) => {
  const [visibleWordCount, setVisibleWordCount] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const finishReveal = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    setVisibleWordCount(WORDS.length);
    setIsFinished(true);
    playSound('alert');
    triggerHaptic(50);
  }, []);

  const handleScreenTap = () => {
    if (!isFinished) {
      finishReveal();
    } else {
      playSound('click');
      onContinue();
    }
  };

  useEffect(() => {
    let current = 0;
    const interval = setInterval(() => {
      current += 1;
      if (current <= WORDS.length) {
        setVisibleWordCount(current);
        playSound('click');
        triggerHaptic(20);
        if (current === WORDS.length) {
          setIsFinished(true);
          playSound('alert');
          clearInterval(interval);
        }
      }
    }, 450);

    timerRef.current = interval;
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      onClick={handleScreenTap}
      className="min-h-screen w-full flex flex-col justify-between items-center bg-slate-950 px-6 py-12 cursor-pointer relative overflow-hidden select-none"
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-red-950/40 via-slate-950 to-black pointer-events-none"></div>
      <div className="z-10 flex items-center gap-2 text-red-500/80 uppercase font-mono text-xs tracking-widest pt-4">
        <ShieldAlert className="w-4 h-4 animate-pulse" />
        <span>Mensaje del Sistema</span>
      </div>
      <div className="w-full max-w-xl my-auto z-10 text-center px-4">
        <div className="flex flex-wrap justify-center items-center gap-x-3.5 gap-y-3 sm:gap-x-5 sm:gap-y-4 text-3xl sm:text-5xl md:text-6xl font-black font-heading leading-tight">
          {WORDS.map((word, idx) => {
            const isVisible = idx < visibleWordCount;
            const isImpostorWord = word.toLowerCase().includes('impostor');
            return (
              <span
                key={idx}
                className={`transition-all duration-300 transform ${
                  isVisible ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-75 translate-y-4 pointer-events-none'
                } ${
                  isImpostorWord
                    ? 'text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.9)] underline decoration-red-500/60 uppercase scale-105'
                    : 'text-slate-100'
                }`}
              >
                {word}
              </span>
            );
          })}
        </div>
        {!isFinished && (
          <p className="mt-8 text-xs sm:text-sm text-slate-500 font-mono tracking-wider animate-pulse flex items-center justify-center gap-2">
            <Fingerprint className="w-4 h-4" /> Toca la pantalla para apresurar
          </p>
        )}
      </div>
      <div className="w-full max-w-sm z-10 flex flex-col items-center gap-3">
        {isFinished ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              playSound('click');
              onContinue();
            }}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-lg shadow-[0_0_25px_rgba(225,29,72,0.5)] active:scale-95 transition-all flex items-center justify-center gap-3 border border-red-400/40 cursor-pointer"
          >
            <span>Elegir Jugadores</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        ) : (
          <div className="h-14" />
        )}
        <p className="text-[11px] text-slate-600 font-mono">
          created by <span className="text-slate-500 font-semibold">Kendry</span>
        </p>
      </div>
    </div>
  );
};
