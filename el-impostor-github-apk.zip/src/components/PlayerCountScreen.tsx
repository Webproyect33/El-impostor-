import React, { useState } from 'react';
import { Users, Minus, Plus, ArrowRight, UserCheck, Sparkles } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/audio';

interface PlayerCountScreenProps {
  initialCount?: number;
  onConfirm: (count: number) => void;
}

export const PlayerCountScreen: React.FC<PlayerCountScreenProps> = ({
  initialCount = 4,
  onConfirm,
}) => {
  const [count, setCount] = useState<number>(initialCount);

  const minPlayers = 3;
  const maxPlayers = 20;

  const handleIncrement = () => {
    if (count < maxPlayers) {
      playSound('click');
      triggerHaptic(15);
      setCount((prev) => prev + 1);
    }
  };

  const handleDecrement = () => {
    if (count > minPlayers) {
      playSound('click');
      triggerHaptic(15);
      setCount((prev) => prev - 1);
    }
  };

  const setPreset = (val: number) => {
    playSound('click');
    triggerHaptic(20);
    setCount(val);
  };

  const handleNext = () => {
    playSound('click');
    onConfirm(count);
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-between items-center bg-slate-950 px-6 py-10 relative overflow-hidden">
      {/* Glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-900/15 rounded-full blur-3xl pointer-events-none"></div>

      {/* Header */}
      <div className="w-full max-w-md text-center pt-2 space-y-2 z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/60 border border-red-800/40 text-red-400 text-xs font-semibold uppercase tracking-wider">
          <Users className="w-3.5 h-3.5" /> Configuración de Sala
        </div>
        <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-white">
          ¿Cuántos jugadores son?
        </h2>
        <p className="text-sm text-slate-400">
          Se necesita un mínimo de 3 jugadores para jugar
        </p>
      </div>

      {/* Interactive Stepper */}
      <div className="w-full max-w-md my-auto flex flex-col items-center gap-6 z-10">
        <div className="flex items-center justify-center gap-6 w-full">
          <button
            onClick={handleDecrement}
            disabled={count <= minPlayers}
            className={`w-16 h-16 rounded-2xl flex items-center justify-center border transition-all ${
              count <= minPlayers
                ? 'border-slate-800 bg-slate-900/50 text-slate-600 cursor-not-allowed'
                : 'border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-white hover:border-red-500/50 shadow-lg active:scale-95'
            }`}
          >
            <Minus className="w-7 h-7" />
          </button>

          <div className="flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-red-500/40 rounded-3xl w-36 h-36 shadow-[0_0_35px_rgba(239,68,68,0.2)] relative">
            <span className="font-heading text-6xl font-black text-white drop-shadow-md">
              {count}
            </span>
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider mt-1">
              Jugadores
            </span>
          </div>

          <button
            onClick={handleIncrement}
            disabled={count >= maxPlayers}
            className={`w-16 h-16 rounded-2xl flex items-center justify-center border transition-all ${
              count >= maxPlayers
                ? 'border-slate-800 bg-slate-900/50 text-slate-600 cursor-not-allowed'
                : 'border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-white hover:border-red-500/50 shadow-lg active:scale-95'
            }`}
          >
            <Plus className="w-7 h-7" />
          </button>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap justify-center gap-2">
          {[3, 4, 5, 6, 7, 8, 10, 12].map((num) => (
            <button
              key={num}
              onClick={() => setPreset(num)}
              className={`px-3.5 py-1.5 rounded-xl text-sm font-bold font-mono transition-all ${
                count === num
                  ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(239,68,68,0.6)] scale-105'
                  : 'bg-slate-900/90 text-slate-400 border border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              {num}
            </button>
          ))}
        </div>

        {/* Game summary preview */}
        <div className="w-full bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between text-xs sm:text-sm">
          <div className="flex items-center gap-2 text-slate-300">
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Inocentes: <strong className="text-white">{count - 1}</strong></span>
          </div>
          <div className="h-4 w-px bg-slate-800" />
          <div className="flex items-center gap-2 text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
            <span>Impostor: <strong className="text-red-400">1</strong></span>
          </div>
        </div>
      </div>

      {/* Confirm Button */}
      <div className="w-full max-w-md z-10">
        <button
          onClick={handleNext}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-lg shadow-[0_0_25px_rgba(225,29,72,0.5)] active:scale-95 transition-all flex items-center justify-center gap-3 border border-red-400/40 cursor-pointer"
        >
          <span>Asignar Nombres</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
