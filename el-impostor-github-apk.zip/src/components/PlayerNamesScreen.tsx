import React, { useState } from 'react';
import { User, Edit2, Check, ArrowRight, ArrowLeft, Shuffle, Sparkles } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/audio';

interface PlayerNamesScreenProps {
  playerCount: number;
  initialNames?: string[];
  onConfirm: (names: string[]) => void;
  onBack: () => void;
}

const AVATAR_COLORS = [
  'from-rose-500 to-red-600',
  'from-blue-500 to-cyan-600',
  'from-emerald-500 to-teal-600',
  'from-amber-500 to-orange-600',
  'from-purple-500 to-indigo-600',
  'from-fuchsia-500 to-pink-600',
  'from-lime-500 to-emerald-600',
  'from-sky-500 to-blue-600',
  'from-violet-500 to-purple-600',
  'from-teal-500 to-green-600',
];

const FUN_NICKNAMES = [
  'Alex', 'Sam', 'Leo', 'Sofia', 'Mateo', 'Valen', 'Lucas', 'Mia', 
  'Diego', 'Camila', 'Bruno', 'Elena', 'Nico', 'Clara', 'Gabi', 'Dante',
  'Zoe', 'Hugo', 'Lara', 'Felipe', 'Max', 'Luna', 'Tomás', 'Julia'
];

export const PlayerNamesScreen: React.FC<PlayerNamesScreenProps> = ({
  playerCount,
  initialNames = [],
  onConfirm,
  onBack,
}) => {
  const [names, setNames] = useState<string[]>(() => {
    return Array.from({ length: playerCount }, (_, i) => {
      if (initialNames[i] && initialNames[i].trim() !== '') {
        return initialNames[i];
      }
      return `Jugador ${i + 1}`;
    });
  });

  const handleNameChange = (index: number, newName: string) => {
    const updated = [...names];
    updated[index] = newName;
    setNames(updated);
  };

  const handleQuickRandomize = () => {
    playSound('click');
    triggerHaptic(20);
    const shuffled = [...FUN_NICKNAMES].sort(() => Math.random() - 0.5);
    const newNames = Array.from({ length: playerCount }, (_, i) => shuffled[i % shuffled.length]);
    setNames(newNames);
  };

  const handleStartGame = () => {
    // Fill any empty names with fallback
    const finalized = names.map((n, i) => n.trim() === '' ? `Jugador ${i + 1}` : n.trim());
    playSound('start');
    triggerHaptic(40);
    onConfirm(finalized);
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-between items-center bg-slate-950 px-4 sm:px-6 py-8 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-950/20 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Header */}
      <div className="w-full max-w-lg z-10 space-y-2">
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              playSound('click');
              onBack();
            }}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Volver
          </button>
          <button
            onClick={handleQuickRandomize}
            className="flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 px-3 py-1.5 rounded-lg bg-amber-950/40 border border-amber-800/40 transition-colors"
          >
            <Shuffle className="w-3.5 h-3.5" /> Nombres al azar
          </button>
        </div>

        <div className="text-center pt-2">
          <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
            Nombres de los Jugadores
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Personaliza el nombre de cada uno o déjalo por defecto
          </p>
        </div>
      </div>

      {/* Players List Grid */}
      <div className="w-full max-w-lg my-4 flex-1 overflow-y-auto max-h-[60vh] pr-1 space-y-3 z-10 custom-scrollbar">
        {names.map((name, index) => {
          const colorGradient = AVATAR_COLORS[index % AVATAR_COLORS.length];
          return (
            <div
              key={index}
              className="flex items-center gap-3 p-3 sm:p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800/90 hover:border-slate-700 transition-all shadow-md group focus-within:border-red-500/60 focus-within:bg-slate-900"
            >
              {/* Avatar circle */}
              <div
                className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br ${colorGradient} flex items-center justify-center text-white font-bold font-heading text-base shadow-sm shrink-0`}
              >
                {name.trim().charAt(0).toUpperCase() || `${index + 1}`}
              </div>

              {/* Input */}
              <div className="flex-1 relative">
                <label className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block mb-0.5">
                  Jugador {index + 1}
                </label>
                <input
                  type="text"
                  value={name}
                  maxLength={18}
                  onChange={(e) => handleNameChange(index, e.target.value)}
                  placeholder={`Jugador ${index + 1}`}
                  className="w-full bg-transparent text-white font-semibold text-sm sm:text-base outline-none focus:ring-0 placeholder:text-slate-600"
                />
              </div>

              {/* Edit indicator */}
              <div className="text-slate-500 group-hover:text-slate-400 pr-2">
                <Edit2 className="w-4 h-4 opacity-60" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Confirm & Start Round */}
      <div className="w-full max-w-lg z-10 pt-2">
        <button
          onClick={handleStartGame}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-lg shadow-[0_0_25px_rgba(225,29,72,0.5)] active:scale-95 transition-all flex items-center justify-center gap-3 border border-red-400/40 cursor-pointer"
        >
          <span>Continuar a Revelación</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
