import React from 'react';
import { UserX, Eye } from 'lucide-react';

interface GameLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
}

export const GameLogo: React.FC<GameLogoProps> = ({ size = 'lg', showSubtitle = true }) => {
  const sizeClasses = {
    sm: 'w-12 h-12 text-xl',
    md: 'w-16 h-16 text-2xl',
    lg: 'w-24 h-24 text-3xl',
    xl: 'w-32 h-32 text-4xl',
  };

  const iconSizes = {
    sm: 24,
    md: 32,
    lg: 48,
    xl: 64,
  };

  return (
    <div className="flex flex-col items-center justify-center text-center">
      <div className="relative mb-4 group">
        <div className="absolute -inset-2 bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 rounded-full blur-xl opacity-70 animate-pulse"></div>
        <div className={`relative ${sizeClasses[size]} rounded-full bg-slate-900 border-2 border-red-500/80 shadow-2xl flex items-center justify-center text-red-400 overflow-hidden`}>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-red-950/60 via-slate-900 to-black"></div>
          <div className="relative z-10">
            <UserX size={iconSizes[size]} className="text-red-400 drop-shadow-[0_0_12px_rgba(239,68,68,0.8)]" />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-transparent via-red-500/20 to-transparent -translate-y-full animate-scanline"></div>
        </div>
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-red-600 border border-slate-900"></span>
        </span>
      </div>

      <div className="space-y-1">
        <h1 className="font-heading text-4xl sm:text-5xl font-extrabold tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-red-500 via-rose-400 to-amber-400 drop-shadow-sm uppercase">
          El Impostor
        </h1>
        {showSubtitle && (
          <p className="text-xs sm:text-sm uppercase tracking-[0.25em] text-slate-400 font-semibold flex items-center justify-center gap-1.5">
            <Eye className="w-3.5 h-3.5 text-red-400" /> Juego de deducción y secretos
          </p>
        )}
      </div>
    </div>
  );
};
