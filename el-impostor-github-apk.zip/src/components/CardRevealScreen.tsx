import React, { useState } from 'react';
import { Player, RoundInfo } from '../types';
import { Eye, Lock, ArrowRight, Sparkles, HelpCircle, ShieldAlert, Fingerprint, Tag } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/audio';

interface CardRevealScreenProps {
  players: Player[];
  roundInfo: RoundInfo;
  onFinishReveal: () => void;
}

export const CardRevealScreen: React.FC<CardRevealScreenProps> = ({
  players,
  roundInfo,
  onFinishReveal,
}) => {
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [hasRevealedCurrent, setHasRevealedCurrent] = useState<boolean>(false);

  const currentPlayer = players[currentPlayerIndex];
  const isLastPlayer = currentPlayerIndex === players.length - 1;

  const handlePressStart = (e: React.SyntheticEvent) => {
    // Prevent default context menu on long press
    if ('button' in e && (e as React.MouseEvent).button !== 0) return;
    setIsFlipped(true);
    setHasRevealedCurrent(true);
    playSound('cardFlip');
    triggerHaptic(40);
  };

  const handlePressEnd = () => {
    if (isFlipped) {
      setIsFlipped(false);
      playSound('cardFlip');
      triggerHaptic(20);
    }
  };

  const handleNextPlayer = () => {
    playSound('click');
    triggerHaptic(30);

    if (isLastPlayer) {
      playSound('start');
      onFinishReveal();
    } else {
      setIsFlipped(false);
      setHasRevealedCurrent(false);
      setCurrentPlayerIndex((prev) => prev + 1);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-between items-center bg-slate-950 px-4 sm:px-6 py-8 relative overflow-hidden select-none">
      {/* Dynamic atmospheric lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-950/20 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Bar / Progress */}
      <div className="w-full max-w-md z-10 flex flex-col items-center space-y-2">
        <div className="flex items-center justify-between w-full text-xs font-mono text-slate-400 px-2">
          <span>Ronda Secreta</span>
          <span className="text-red-400 font-bold">
            Turno {currentPlayerIndex + 1} de {players.length}
          </span>
        </div>

        {/* Step pill indicators */}
        <div className="flex items-center gap-1.5 w-full">
          {players.map((p, idx) => (
            <div
              key={p.id}
              className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                idx < currentPlayerIndex
                  ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]'
                  : idx === currentPlayerIndex
                  ? 'bg-amber-400'
                  : 'bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Main 3D Card Area */}
      <div className="w-full max-w-sm my-auto flex flex-col items-center z-10 perspective-1000">
        <div className="text-center mb-4 space-y-1">
          <p className="text-xs uppercase tracking-widest font-mono text-slate-400">
            Pasa el dispositivo a:
          </p>
          <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
            {currentPlayer.name}
          </h2>
        </div>

        {/* 3D Flip Card */}
        <div
          onPointerDown={handlePressStart}
          onPointerUp={handlePressEnd}
          onPointerLeave={handlePressEnd}
          onPointerCancel={handlePressEnd}
          onContextMenu={(e) => e.preventDefault()}
          className={`w-full h-80 sm:h-96 rounded-3xl cursor-pointer relative transform-style-3d transition-transform duration-500 ease-out shadow-2xl ${
            isFlipped ? 'rotate-y-180 scale-102' : 'scale-100 hover:scale-[1.01]'
          }`}
          style={{ touchAction: 'none' }}
        >
          {/* ================= CARD FRONT (Player Name Side) ================= */}
          <div className="absolute inset-0 w-full h-full backface-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border-2 border-slate-700/80 p-6 sm:p-8 flex flex-col justify-between items-center text-center shadow-2xl overflow-hidden group">
            {/* Background pattern */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-red-950/30 via-transparent to-transparent pointer-events-none"></div>

            {/* Top card badge */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700 text-xs font-mono text-slate-300">
              <Lock className="w-3.5 h-3.5 text-amber-400" /> Confidencial
            </div>

            {/* Middle: Player Name */}
            <div className="space-y-3 my-auto">
              <div
                className={`w-16 h-16 sm:w-20 sm:h-20 mx-auto rounded-2xl bg-gradient-to-br ${currentPlayer.avatarColor} flex items-center justify-center text-white font-extrabold text-2xl sm:text-3xl shadow-lg`}
              >
                {currentPlayer.name.charAt(0).toUpperCase()}
              </div>

              <div className="space-y-1">
                <span className="text-[11px] font-mono uppercase tracking-widest text-slate-400">
                  Es el turno de
                </span>
                <h3 className="font-heading text-3xl sm:text-4xl font-black text-white">
                  {currentPlayer.name}
                </h3>
              </div>
            </div>

            {/* Bottom: Hold instruction */}
            <div className="space-y-2 w-full">
              <div className="flex items-center justify-center gap-2 text-xs sm:text-sm font-bold text-red-400 bg-red-950/40 border border-red-800/50 py-3 px-4 rounded-xl animate-subtle-pulse">
                <Fingerprint className="w-4 h-4 animate-bounce" />
                <span>Mantén presionado para ver</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Asegúrate de que nadie más esté mirando
              </p>
            </div>
          </div>

          {/* ================= CARD BACK (Secret Word Side) ================= */}
          <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 rounded-3xl bg-gradient-to-br from-red-950 via-slate-900 to-slate-950 border-2 border-red-500 p-6 sm:p-8 flex flex-col justify-between items-center text-center shadow-[0_0_35px_rgba(239,68,68,0.4)] overflow-hidden">
            {/* Ambient glow */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-red-600/20 via-transparent to-transparent pointer-events-none"></div>

            {/* Top Category Tag */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-900/60 border border-red-700/60 text-xs font-semibold text-red-200">
              <Tag className="w-3.5 h-3.5 text-amber-300" />
              <span>Categoría: {roundInfo.category}</span>
            </div>

            {/* Middle: Secret Word Display */}
            <div className="space-y-3 my-auto w-full px-2">
              <span className="text-xs uppercase font-mono tracking-widest text-red-300 font-bold">
                Tu palabra secreta es:
              </span>
              <div className="py-4 px-3 bg-slate-950/80 border border-red-500/50 rounded-2xl shadow-inner">
                <p className="font-heading text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-wide break-words drop-shadow-md">
                  {currentPlayer.assignedWord}
                </p>
              </div>
              <p className="text-[11px] text-slate-400">
                Memorízala bien antes de soltar la carta
              </p>
            </div>

            {/* Bottom notice */}
            <div className="text-[11px] font-mono text-slate-400 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800">
              Suelta la pantalla para ocultar
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Button Area (Appears once card was inspected / held) */}
      <div className="w-full max-w-sm z-10 min-h-[72px] flex items-center justify-center">
        {hasRevealedCurrent ? (
          <button
            onClick={handleNextPlayer}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-lg shadow-[0_0_25px_rgba(225,29,72,0.5)] active:scale-95 transition-all flex items-center justify-center gap-3 border border-red-400/40 cursor-pointer animate-in fade-in duration-300"
          >
            <span>{isLastPlayer ? 'Empezar juego' : 'Pasar a otro jugador'}</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        ) : (
          <p className="text-xs text-slate-500 font-mono text-center">
            Mantén presionada la tarjeta para desbloquear el siguiente turno
          </p>
        )}
      </div>
    </div>
  );
};
