export interface WordPair {
  id: number;
  category: string;
  secretWord: string;
  impostorWord: string;
}

export const WORD_DATABASE: WordPair[] = [
  {
    "id": 1,
    "category": "Animales",
    "secretWord": "León",
    "impostorWord": "Tigre"
  },
  {
    "id": 2,
    "category": "Animales",
    "secretWord": "Perro",
    "impostorWord": "Lobo"
  },
  {
    "id": 3,
    "category": "Animales",
    "secretWord": "Gato",
    "impostorWord": "Pantera"
  },
  {
    "id": 4,
    "category": "Animales",
    "secretWord": "Caballo",
    "impostorWord": "Cebra"
  },
  {
    "id": 5,
    "category": "Animales",
    "secretWord": "Águila",
    "impostorWord": "Halcón"
  },
  {
    "id": 6,
    "category": "Animales",
    "secretWord": "Delfín",
    "impostorWord": "Tiburón"
  },
  {
    "id": 7,
    "category": "Animales",
    "secretWord": "Oso Panda",
    "impostorWord": "Oso Polar"
  },
  {
    "id": 8,
    "category": "Animales",
    "secretWord": "Cocodrilo",
    "impostorWord": "Caimán"
  },
  {
    "id": 9,
    "category": "Animales",
    "secretWord": "Elefante",
    "impostorWord": "Rinoceronte"
  },
  {
    "id": 10,
    "category": "Animales",
    "secretWord": "Pingüino",
    "impostorWord": "Foca"
  },
  {
    "id": 11,
    "category": "Animales",
    "secretWord": "Jirafa",
    "impostorWord": "Camello"
  },
  {
    "id": 12,
    "category": "Animales",
    "secretWord": "Canguro",
    "impostorWord": "Koala"
  },
  {
    "id": 13,
    "category": "Animales",
    "secretWord": "Rana",
    "impostorWord": "Sapo"
  },
  {
    "id": 14,
    "category": "Animales",
    "secretWord": "Loro",
    "impostorWord": "Tucán"
  },
  {
    "id": 15,
    "category": "Animales",
    "secretWord": "Gorila",
    "impostorWord": "Chimpancé"
  },
  {
    "id": 16,
    "category": "Animales",
    "secretWord": "Serpiente",
    "impostorWord": "Lagarto"
  },
  {
    "id": 17,
    "category": "Animales",
    "secretWord": "Pulpo",
    "impostorWord": "Calamar"
  },
  {
    "id": 18,
    "category": "Animales",
    "secretWord": "Ballena",
    "impostorWord": "Orca"
  },
  {
    "id": 19,
    "category": "Animales",
    "secretWord": "Abeja",
    "impostorWord": "Avispa"
  },
  {
    "id": 20,
    "category": "Animales",
    "secretWord": "Mariposa",
    "impostorWord": "Polilla"
  },
  {
    "id": 21,
    "category": "Animales",
    "secretWord": "Búho",
    "impostorWord": "Lechuza"
  },
  {
    "id": 22,
    "category": "Animales",
    "secretWord": "Cisne",
    "impostorWord": "Flamenco"
  },
  {
    "id": 23,
    "category": "Animales",
    "secretWord": "Zorro",
    "impostorWord": "Chacal"
  },
  {
    "id": 24,
    "category": "Animales",
    "secretWord": "Conejo",
    "impostorWord": "Liebre"
  },
  {
    "id": 25,
    "category": "Animales",
    "secretWord": "Murciélago",
    "impostorWord": "Vampiro"
  },
  {
    "id": 26,
    "category": "Animales",
    "secretWord": "Hámster",
    "impostorWord": "Cobaya"
  },
  {
    "id": 27,
    "category": "Animales",
    "secretWord": "Pavo Real",
    "impostorWord": "Faisán"
  },
  {
    "id": 28,
    "category": "Animales",
    "secretWord": "Castor",
    "impostorWord": "Nutria"
  },
  {
    "id": 29,
    "category": "Animales",
    "secretWord": "Medusa",
    "impostorWord": "Estrella de Mar"
  },
  {
    "id": 30,
    "category": "Animales",
    "secretWord": "Camaleón",
    "impostorWord": "Iguana"
  },
  {
    "id": 31,
    "category": "Animales",
    "secretWord": "Caracol",
    "impostorWord": "Babosa"
  },
  {
    "id": 32,
    "category": "Animales",
    "secretWord": "Escorpión",
    "impostorWord": "Araña"
  },
  {
    "id": 33,
    "category": "Animales",
    "secretWord": "Pelícano",
    "impostorWord": "Gaviota"
  },
  {
    "id": 34,
    "category": "Animales",
    "secretWord": "Cangrejo",
    "impostorWord": "Langosta"
  },
  {
    "id": 35,
    "category": "Animales",
    "secretWord": "Guepardo",
    "impostorWord": "Leopardo"
  },
  {
    "id": 36,
    "category": "Animales",
    "secretWord": "Hiena",
    "impostorWord": "Lobo"
  },
  {
    "id": 37,
    "category": "Animales",
    "secretWord": "Tortuga",
    "impostorWord": "Armadillo"
  },
  {
    "id": 38,
    "category": "Animales",
    "secretWord": "Cabrita",
    "impostorWord": "Oveja"
  },
  {
    "id": 39,
    "category": "Animales",
    "secretWord": "Toro",
    "impostorWord": "Bisonte"
  },
  {
    "id": 40,
    "category": "Animales",
    "secretWord": "Puercoespín",
    "impostorWord": "Erizo"
  },
  {
    "id": 41,
    "category": "Animales",
    "secretWord": "Hipopótamo",
    "impostorWord": "Rinoceronte"
  },
  {
    "id": 42,
    "category": "Animales",
    "secretWord": "Pato",
    "impostorWord": "Ganso"
  },
  {
    "id": 43,
    "category": "Animales",
    "secretWord": "Gallina",
    "impostorWord": "Pavo"
  },
  {
    "id": 44,
    "category": "Animales",
    "secretWord": "Colibrí",
    "impostorWord": "Mariposa"
  },
  {
    "id": 45,
    "category": "Animales",
    "secretWord": "Lémur",
    "impostorWord": "Mono"
  },
  {
    "id": 46,
    "category": "Animales",
    "secretWord": "Pez Payaso",
    "impostorWord": "Pez Dorado"
  },
  {
    "id": 47,
    "category": "Animales",
    "secretWord": "Manta Raya",
    "impostorWord": "Tiburón"
  },
  {
    "id": 48,
    "category": "Animales",
    "secretWord": "Salamandra",
    "impostorWord": "Lagartija"
  },
  {
    "id": 49,
    "category": "Animales",
    "secretWord": "Avestruz",
    "impostorWord": "Emú"
  },
  {
    "id": 50,
    "category": "Animales",
    "secretWord": "Suricata",
    "impostorWord": "Comadreja"
  },
  {
    "id": 51,
    "category": "Animales",
    "secretWord": "Morsa",
    "impostorWord": "León Marino"
  },
  {
    "id": 52,
    "category": "Animales",
    "secretWord": "Perezoso",
    "impostorWord": "Oso Hormiguero"
  },
  {
    "id": 53,
    "category": "Animales",
    "secretWord": "Guacamayo",
    "impostorWord": "Cacatúa"
  },
  {
    "id": 54,
    "category": "Animales",
    "secretWord": "Ciempiés",
    "impostorWord": "Gusano"
  },
  {
    "id": 55,
    "category": "Animales",
    "secretWord": "Mosquito",
    "impostorWord": "Mosca"
  },
  {
    "id": 56,
    "category": "Animales",
    "secretWord": "Grillo",
    "impostorWord": "Saltamontes"
  },
  {
    "id": 57,
    "category": "Animales",
    "secretWord": "Luciérnaga",
    "impostorWord": "Escarabajo"
  },
  {
    "id": 58,
    "category": "Animales",
    "secretWord": "Caballito de Mar",
    "impostorWord": "Pez Espada"
  },
  {
    "id": 59,
    "category": "Animales",
    "secretWord": "Alce",
    "impostorWord": "Ciervo"
  },
  {
    "id": 60,
    "category": "Animales",
    "secretWord": "Chinchilla",
    "impostorWord": "Ardilla"
  },
  {
    "id": 61,
    "category": "Animales",
    "secretWord": "Búfalo",
    "impostorWord": "Buey"
  },
  {
    "id": 62,
    "category": "Animales",
    "secretWord": "Buitre",
    "impostorWord": "Cóndor"
  },
  {
    "id": 63,
    "category": "Animales",
    "secretWord": "Piraña",
    "impostorWord": "Barracuda"
  },
  {
    "id": 64,
    "category": "Animales",
    "secretWord": "Geco",
    "impostorWord": "Camaleón"
  },
  {
    "id": 65,
    "category": "Animales",
    "secretWord": "Antílope",
    "impostorWord": "Gacela"
  },
  {
    "id": 66,
    "category": "Comida y Bebida",
    "secretWord": "Pizza",
    "impostorWord": "Hamburguesa"
  },
  {
    "id": 67,
    "category": "Comida y Bebida",
    "secretWord": "Tacos",
    "impostorWord": "Burritos"
  },
  {
    "id": 68,
    "category": "Comida y Bebida",
    "secretWord": "Café",
    "impostorWord": "Té"
  },
  {
    "id": 69,
    "category": "Comida y Bebida",
    "secretWord": "Sushi",
    "impostorWord": "Ceviche"
  },
  {
    "id": 70,
    "category": "Comida y Bebida",
    "secretWord": "Chocolate",
    "impostorWord": "Nutella"
  },
  {
    "id": 71,
    "category": "Comida y Bebida",
    "secretWord": "Cerveza",
    "impostorWord": "Vino"
  },
  {
    "id": 72,
    "category": "Comida y Bebida",
    "secretWord": "Helado",
    "impostorWord": "Gelatina"
  },
  {
    "id": 73,
    "category": "Comida y Bebida",
    "secretWord": "Manzana",
    "impostorWord": "Pera"
  },
  {
    "id": 74,
    "category": "Comida y Bebida",
    "secretWord": "Naranja",
    "impostorWord": "Mandarina"
  },
  {
    "id": 75,
    "category": "Comida y Bebida",
    "secretWord": "Fresa",
    "impostorWord": "Frambuesa"
  },
  {
    "id": 76,
    "category": "Comida y Bebida",
    "secretWord": "Plátano",
    "impostorWord": "Mango"
  },
  {
    "id": 77,
    "category": "Comida y Bebida",
    "secretWord": "Sandía",
    "impostorWord": "Melón"
  },
  {
    "id": 78,
    "category": "Comida y Bebida",
    "secretWord": "Paella",
    "impostorWord": "Risotto"
  },
  {
    "id": 79,
    "category": "Comida y Bebida",
    "secretWord": "Lasaña",
    "impostorWord": "Espaguetis"
  },
  {
    "id": 80,
    "category": "Comida y Bebida",
    "secretWord": "Perrito Caliente",
    "impostorWord": "Sandwich"
  },
  {
    "id": 81,
    "category": "Comida y Bebida",
    "secretWord": "Empanada",
    "impostorWord": "Pastel de Carne"
  },
  {
    "id": 82,
    "category": "Comida y Bebida",
    "secretWord": "Croissant",
    "impostorWord": "Donut"
  },
  {
    "id": 83,
    "category": "Comida y Bebida",
    "secretWord": "Queso",
    "impostorWord": "Mantequilla"
  },
  {
    "id": 84,
    "category": "Comida y Bebida",
    "secretWord": "Leche",
    "impostorWord": "Yogur"
  },
  {
    "id": 85,
    "category": "Comida y Bebida",
    "secretWord": "Coca Cola",
    "impostorWord": "Pepsi"
  },
  {
    "id": 86,
    "category": "Comida y Bebida",
    "secretWord": "Limonada",
    "impostorWord": "Jugo de Naranja"
  },
  {
    "id": 87,
    "category": "Comida y Bebida",
    "secretWord": "Papas Fritas",
    "impostorWord": "Nachos"
  },
  {
    "id": 88,
    "category": "Comida y Bebida",
    "secretWord": "Palomitas",
    "impostorWord": "Frutos Secos"
  },
  {
    "id": 89,
    "category": "Comida y Bebida",
    "secretWord": "Tarta de Manzana",
    "impostorWord": "Cheesecake"
  },
  {
    "id": 90,
    "category": "Comida y Bebida",
    "secretWord": "Churros",
    "impostorWord": "Waffles"
  },
  {
    "id": 91,
    "category": "Comida y Bebida",
    "secretWord": "Panqueques",
    "impostorWord": "Crepes"
  },
  {
    "id": 92,
    "category": "Comida y Bebida",
    "secretWord": "Mojito",
    "impostorWord": "Margarita"
  },
  {
    "id": 93,
    "category": "Comida y Bebida",
    "secretWord": "Tequila",
    "impostorWord": "Ron"
  },
  {
    "id": 94,
    "category": "Comida y Bebida",
    "secretWord": "Whisky",
    "impostorWord": "Vodka"
  },
  {
    "id": 95,
    "category": "Comida y Bebida",
    "secretWord": "Aguacate",
    "impostorWord": "Guacamole"
  },
  {
    "id": 96,
    "category": "Comida y Bebida",
    "secretWord": "Zanahoria",
    "impostorWord": "Calabaza"
  },
  {
    "id": 97,
    "category": "Comida y Bebida",
    "secretWord": "Tomate",
    "impostorWord": "Pimiento"
  },
  {
    "id": 98,
    "category": "Comida y Bebida",
    "secretWord": "Cebolla",
    "impostorWord": "Ajo"
  },
  {
    "id": 99,
    "category": "Comida y Bebida",
    "secretWord": "Lechuga",
    "impostorWord": "Espinaca"
  },
  {
    "id": 100,
    "category": "Comida y Bebida",
    "secretWord": "Brócoli",
    "impostorWord": "Coliflor"
  },
  {
    "id": 101,
    "category": "Comida y Bebida",
    "secretWord": "Arroz con Pollo",
    "impostorWord": "Chaufa"
  },
  {
    "id": 102,
    "category": "Comida y Bebida",
    "secretWord": "Sopa de Fideos",
    "impostorWord": "Ramen"
  },
  {
    "id": 103,
    "category": "Comida y Bebida",
    "secretWord": "Tortilla Española",
    "impostorWord": "Omelette"
  },
  {
    "id": 104,
    "category": "Comida y Bebida",
    "secretWord": "Arepa",
    "impostorWord": "Pupusa"
  },
  {
    "id": 105,
    "category": "Comida y Bebida",
    "secretWord": "Tamal",
    "impostorWord": "Humita"
  },
  {
    "id": 106,
    "category": "Comida y Bebida",
    "secretWord": "Ketchup",
    "impostorWord": "Mostaza"
  },
  {
    "id": 107,
    "category": "Comida y Bebida",
    "secretWord": "Mayonesa",
    "impostorWord": "Salsa Tártara"
  },
  {
    "id": 108,
    "category": "Comida y Bebida",
    "secretWord": "Miel",
    "impostorWord": "Sirope"
  },
  {
    "id": 109,
    "category": "Comida y Bebida",
    "secretWord": "Azúcar",
    "impostorWord": "Sal"
  },
  {
    "id": 110,
    "category": "Comida y Bebida",
    "secretWord": "Aceite de Oliva",
    "impostorWord": "Vinagre"
  },
  {
    "id": 111,
    "category": "Comida y Bebida",
    "secretWord": "Batido de Fresa",
    "impostorWord": "Smoothie Tropical"
  },
  {
    "id": 112,
    "category": "Comida y Bebida",
    "secretWord": "Champagne",
    "impostorWord": "Sidra"
  },
  {
    "id": 113,
    "category": "Comida y Bebida",
    "secretWord": "Uvas",
    "impostorWord": "Ciruelas"
  },
  {
    "id": 114,
    "category": "Comida y Bebida",
    "secretWord": "Kiwi",
    "impostorWord": "Maracuyá"
  },
  {
    "id": 115,
    "category": "Comida y Bebida",
    "secretWord": "Piña",
    "impostorWord": "Papaya"
  },
  {
    "id": 116,
    "category": "Comida y Bebida",
    "secretWord": "Coco",
    "impostorWord": "Nuez"
  },
  {
    "id": 117,
    "category": "Comida y Bebida",
    "secretWord": "Almendra",
    "impostorWord": "Pistacho"
  },
  {
    "id": 118,
    "category": "Comida y Bebida",
    "secretWord": "Maní / Cacahuate",
    "impostorWord": "Avellana"
  },
  {
    "id": 119,
    "category": "Comida y Bebida",
    "secretWord": "Brownie",
    "impostorWord": "Muffin"
  },
  {
    "id": 120,
    "category": "Comida y Bebida",
    "secretWord": "Galleta con Chispas",
    "impostorWord": "Oreo"
  },
  {
    "id": 121,
    "category": "Comida y Bebida",
    "secretWord": "Chicle",
    "impostorWord": "Caramelo"
  },
  {
    "id": 122,
    "category": "Comida y Bebida",
    "secretWord": "Piruleta",
    "impostorWord": "Algodón de Azúcar"
  },
  {
    "id": 123,
    "category": "Comida y Bebida",
    "secretWord": "Salmón",
    "impostorWord": "Atún"
  },
  {
    "id": 124,
    "category": "Comida y Bebida",
    "secretWord": "Camarones",
    "impostorWord": "Calamares Rebozados"
  },
  {
    "id": 125,
    "category": "Comida y Bebida",
    "secretWord": "Costillas BBQ",
    "impostorWord": "Bife de Chorizo"
  },
  {
    "id": 126,
    "category": "Comida y Bebida",
    "secretWord": "Pollo Frito",
    "impostorWord": "Nuggets"
  },
  {
    "id": 127,
    "category": "Comida y Bebida",
    "secretWord": "Curry",
    "impostorWord": "Chili con Carne"
  },
  {
    "id": 128,
    "category": "Comida y Bebida",
    "secretWord": "Falafel",
    "impostorWord": "Kebab"
  },
  {
    "id": 129,
    "category": "Comida y Bebida",
    "secretWord": "Sangría",
    "impostorWord": "Tinto de Verano"
  },
  {
    "id": 130,
    "category": "Comida y Bebida",
    "secretWord": "Mate",
    "impostorWord": "Té Verde"
  },
  {
    "id": 131,
    "category": "Comida y Bebida",
    "secretWord": "Horchata",
    "impostorWord": "Agua de Jamaica"
  },
  {
    "id": 132,
    "category": "Comida y Bebida",
    "secretWord": "Pera al Vino",
    "impostorWord": "Flan de Caramelo"
  },
  {
    "id": 133,
    "category": "Comida y Bebida",
    "secretWord": "Cereal con Leche",
    "impostorWord": "Avena con Canela"
  },
  {
    "id": 134,
    "category": "Comida y Bebida",
    "secretWord": "Bagel",
    "impostorWord": "Donut Glaseada"
  },
  {
    "id": 135,
    "category": "Comida y Bebida",
    "secretWord": "Canelones",
    "impostorWord": "Raviolis"
  },
  {
    "id": 136,
    "category": "Objetos",
    "secretWord": "Teléfono Móvil",
    "impostorWord": "Tablet"
  },
  {
    "id": 137,
    "category": "Objetos",
    "secretWord": "Computadora Portátil",
    "impostorWord": "Computadora de Mesa"
  },
  {
    "id": 138,
    "category": "Objetos",
    "secretWord": "Reloj de Muñeca",
    "impostorWord": "Smartwatch"
  },
  {
    "id": 139,
    "category": "Objetos",
    "secretWord": "Auriculares",
    "impostorWord": "Altavoz Bluetooth"
  },
  {
    "id": 140,
    "category": "Objetos",
    "secretWord": "Televisor",
    "impostorWord": "Proyector de Cine"
  },
  {
    "id": 141,
    "category": "Objetos",
    "secretWord": "Cámara Fotográfica",
    "impostorWord": "Videocámara"
  },
  {
    "id": 142,
    "category": "Objetos",
    "secretWord": "Consola de Videojuegos",
    "impostorWord": "Máquina Arcade"
  },
  {
    "id": 143,
    "category": "Objetos",
    "secretWord": "Libro",
    "impostorWord": "Revista"
  },
  {
    "id": 144,
    "category": "Objetos",
    "secretWord": "Gafas de Sol",
    "impostorWord": "Gafas de Lectura"
  },
  {
    "id": 145,
    "category": "Objetos",
    "secretWord": "Paraguas",
    "impostorWord": "Impermeable"
  },
  {
    "id": 146,
    "category": "Objetos",
    "secretWord": "Mochila",
    "impostorWord": "Maleta de Viaje"
  },
  {
    "id": 147,
    "category": "Objetos",
    "secretWord": "Billetera",
    "impostorWord": "Monedero"
  },
  {
    "id": 148,
    "category": "Objetos",
    "secretWord": "Llaves",
    "impostorWord": "Tarjeta de Acceso"
  },
  {
    "id": 149,
    "category": "Objetos",
    "secretWord": "Linterna",
    "impostorWord": "Vela"
  },
  {
    "id": 150,
    "category": "Objetos",
    "secretWord": "Tijeras",
    "impostorWord": "Cúter / Navaja"
  },
  {
    "id": 151,
    "category": "Objetos",
    "secretWord": "Espejo",
    "impostorWord": "Ventana"
  },
  {
    "id": 152,
    "category": "Objetos",
    "secretWord": "Cepillo de Dientes",
    "impostorWord": "Hilo Dental"
  },
  {
    "id": 153,
    "category": "Objetos",
    "secretWord": "Champú",
    "impostorWord": "Gel de Ducha"
  },
  {
    "id": 154,
    "category": "Objetos",
    "secretWord": "Toalla",
    "impostorWord": "Bata de Baño"
  },
  {
    "id": 155,
    "category": "Objetos",
    "secretWord": "Almohada",
    "impostorWord": "Cojín de Sofá"
  },
  {
    "id": 156,
    "category": "Objetos",
    "secretWord": "Sábana",
    "impostorWord": "Manta Polar"
  },
  {
    "id": 157,
    "category": "Objetos",
    "secretWord": "Lámpara de Noche",
    "impostorWord": "Candelabro"
  },
  {
    "id": 158,
    "category": "Objetos",
    "secretWord": "Microondas",
    "impostorWord": "Horno Eléctrico"
  },
  {
    "id": 159,
    "category": "Objetos",
    "secretWord": "Refrigerador",
    "impostorWord": "Congelador"
  },
  {
    "id": 160,
    "category": "Objetos",
    "secretWord": "Lavadora",
    "impostorWord": "Secadora"
  },
  {
    "id": 161,
    "category": "Objetos",
    "secretWord": "Aspiradora",
    "impostorWord": "Escoba"
  },
  {
    "id": 162,
    "category": "Objetos",
    "secretWord": "Sartén",
    "impostorWord": "Olla a Presión"
  },
  {
    "id": 163,
    "category": "Objetos",
    "secretWord": "Tenedor",
    "impostorWord": "Cuchara"
  },
  {
    "id": 164,
    "category": "Objetos",
    "secretWord": "Cuchillo de Cocina",
    "impostorWord": "Machete"
  },
  {
    "id": 165,
    "category": "Objetos",
    "secretWord": "Vaso de Vidrio",
    "impostorWord": "Taza de Cerámica"
  },
  {
    "id": 166,
    "category": "Objetos",
    "secretWord": "Plato Hondo",
    "impostorWord": "Bol / Cuenco"
  },
  {
    "id": 167,
    "category": "Objetos",
    "secretWord": "Termo de Café",
    "impostorWord": "Botella de Agua"
  },
  {
    "id": 168,
    "category": "Objetos",
    "secretWord": "Bolígrafo",
    "impostorWord": "Lápiz de Grafito"
  },
  {
    "id": 169,
    "category": "Objetos",
    "secretWord": "Cuaderno",
    "impostorWord": "Agenda Diaria"
  },
  {
    "id": 170,
    "category": "Objetos",
    "secretWord": "Goma de Borrar",
    "impostorWord": "Corrector Líquido"
  },
  {
    "id": 171,
    "category": "Objetos",
    "secretWord": "Calculadora",
    "impostorWord": "Ábaco"
  },
  {
    "id": 172,
    "category": "Objetos",
    "secretWord": "Memoria USB",
    "impostorWord": "Disco Duro Externo"
  },
  {
    "id": 173,
    "category": "Objetos",
    "secretWord": "Teclado de Ordenador",
    "impostorWord": "Ratón / Mouse"
  },
  {
    "id": 174,
    "category": "Objetos",
    "secretWord": "Cargador de Móvil",
    "impostorWord": "Batería Portátil (Powerbank)"
  },
  {
    "id": 175,
    "category": "Objetos",
    "secretWord": "Martillo",
    "impostorWord": "Mazo de Goma"
  },
  {
    "id": 176,
    "category": "Objetos",
    "secretWord": "Destornillador",
    "impostorWord": "Taladro Eléctrico"
  },
  {
    "id": 177,
    "category": "Objetos",
    "secretWord": "Cinta Adhesiva",
    "impostorWord": "Pegamento en Barra"
  },
  {
    "id": 178,
    "category": "Objetos",
    "secretWord": "Candado",
    "impostorWord": "Cerradura"
  },
  {
    "id": 179,
    "category": "Objetos",
    "secretWord": "Mando a Distancia",
    "impostorWord": "Control de Juegos"
  },
  {
    "id": 180,
    "category": "Objetos",
    "secretWord": "Ventilador",
    "impostorWord": "Aire Acondicionado"
  },
  {
    "id": 181,
    "category": "Objetos",
    "secretWord": "Radiador",
    "impostorWord": "Chimenea"
  },
  {
    "id": 182,
    "category": "Objetos",
    "secretWord": "Plancha de Ropa",
    "impostorWord": "Vaporera"
  },
  {
    "id": 183,
    "category": "Objetos",
    "secretWord": "Cafetera Expreso",
    "impostorWord": "Hervidor de Agua"
  },
  {
    "id": 184,
    "category": "Objetos",
    "secretWord": "Tostadora",
    "impostorWord": "Sandwichera"
  },
  {
    "id": 185,
    "category": "Objetos",
    "secretWord": "Batidora",
    "impostorWord": "Licuadora"
  },
  {
    "id": 186,
    "category": "Objetos",
    "secretWord": "Secador de Pelo",
    "impostorWord": "Plancha de Cabello"
  },
  {
    "id": 187,
    "category": "Objetos",
    "secretWord": "Perfume",
    "impostorWord": "Desodorante"
  },
  {
    "id": 188,
    "category": "Objetos",
    "secretWord": "Pintalabios",
    "impostorWord": "Esmalte de Uñas"
  },
  {
    "id": 189,
    "category": "Objetos",
    "secretWord": "Anillo de Oro",
    "impostorWord": "Collar de Plata"
  },
  {
    "id": 190,
    "category": "Objetos",
    "secretWord": "Pulsera",
    "impostorWord": "Pendientes"
  },
  {
    "id": 191,
    "category": "Objetos",
    "secretWord": "Dron con Cámara",
    "impostorWord": "Helicóptero Teledirigido"
  },
  {
    "id": 192,
    "category": "Objetos",
    "secretWord": "Brújula",
    "impostorWord": "GPS"
  },
  {
    "id": 193,
    "category": "Objetos",
    "secretWord": "Mapa de Papel",
    "impostorWord": "Globo Terráqueo"
  },
  {
    "id": 194,
    "category": "Objetos",
    "secretWord": "Telescopio",
    "impostorWord": "Binoculares / Prismáticos"
  },
  {
    "id": 195,
    "category": "Objetos",
    "secretWord": "Microscopio",
    "impostorWord": "Lupa de Aumento"
  },
  {
    "id": 196,
    "category": "Objetos",
    "secretWord": "Guitarra Eléctrica",
    "impostorWord": "Bajo Eléctrico"
  },
  {
    "id": 197,
    "category": "Objetos",
    "secretWord": "Piano de Cola",
    "impostorWord": "Sintetizador"
  },
  {
    "id": 198,
    "category": "Objetos",
    "secretWord": "Violín",
    "impostorWord": "Violonchelo"
  },
  {
    "id": 199,
    "category": "Objetos",
    "secretWord": "Batería Musical",
    "impostorWord": "Bongós"
  },
  {
    "id": 200,
    "category": "Objetos",
    "secretWord": "Trompeta",
    "impostorWord": "Saxofón"
  },
  {
    "id": 201,
    "category": "Objetos",
    "secretWord": "Flauta Travesera",
    "impostorWord": "Clarinete"
  },
  {
    "id": 202,
    "category": "Objetos",
    "secretWord": "Micrófono",
    "impostorWord": "Megáfono"
  },
  {
    "id": 203,
    "category": "Objetos",
    "secretWord": "Monopatín / Skateboard",
    "impostorWord": "Patinete Eléctrico"
  },
  {
    "id": 204,
    "category": "Objetos",
    "secretWord": "Bicicleta de Montaña",
    "impostorWord": "Moto de Cross"
  },
  {
    "id": 205,
    "category": "Objetos",
    "secretWord": "Casco de Seguridad",
    "impostorWord": "Gorra Deportiva"
  },
  {
    "id": 206,
    "category": "Lugares",
    "secretWord": "Playa Tropical",
    "impostorWord": "Piscina Pública"
  },
  {
    "id": 207,
    "category": "Lugares",
    "secretWord": "Cine",
    "impostorWord": "Teatro"
  },
  {
    "id": 208,
    "category": "Lugares",
    "secretWord": "Hospital",
    "impostorWord": "Farmacia"
  },
  {
    "id": 209,
    "category": "Lugares",
    "secretWord": "Aeropuerto",
    "impostorWord": "Estación de Tren"
  },
  {
    "id": 210,
    "category": "Lugares",
    "secretWord": "Biblioteca",
    "impostorWord": "Librería"
  },
  {
    "id": 211,
    "category": "Lugares",
    "secretWord": "Supermercado",
    "impostorWord": "Mercado Tradicional"
  },
  {
    "id": 212,
    "category": "Lugares",
    "secretWord": "Restaurante de Lujo",
    "impostorWord": "Bar de Tapas"
  },
  {
    "id": 213,
    "category": "Lugares",
    "secretWord": "Gimnasio",
    "impostorWord": "Estadio de Fútbol"
  },
  {
    "id": 214,
    "category": "Lugares",
    "secretWord": "Parque de Atracciones",
    "impostorWord": "Circo"
  },
  {
    "id": 215,
    "category": "Lugares",
    "secretWord": "Zoológico",
    "impostorWord": "Acuario"
  },
  {
    "id": 216,
    "category": "Lugares",
    "secretWord": "Museo de Arte",
    "impostorWord": "Galería de Arte"
  },
  {
    "id": 217,
    "category": "Lugares",
    "secretWord": "Hotel de 5 Estrellas",
    "impostorWord": "Hostal de Mochileros"
  },
  {
    "id": 218,
    "category": "Lugares",
    "secretWord": "Discoteca",
    "impostorWord": "Pub Nocturno"
  },
  {
    "id": 219,
    "category": "Lugares",
    "secretWord": "Cementerio",
    "impostorWord": "Cripta Antigua"
  },
  {
    "id": 220,
    "category": "Lugares",
    "secretWord": "Castillo Medieval",
    "impostorWord": "Fortaleza Militar"
  },
  {
    "id": 221,
    "category": "Lugares",
    "secretWord": "Iglesia",
    "impostorWord": "Catedral"
  },
  {
    "id": 222,
    "category": "Lugares",
    "secretWord": "Prisión / Cárcel",
    "impostorWord": "Comisaría de Policía"
  },
  {
    "id": 223,
    "category": "Lugares",
    "secretWord": "Banco Central",
    "impostorWord": "Casino de Apuestas"
  },
  {
    "id": 224,
    "category": "Lugares",
    "secretWord": "Escuela Primaria",
    "impostorWord": "Universidad"
  },
  {
    "id": 225,
    "category": "Lugares",
    "secretWord": "Centro Comercial",
    "impostorWord": "Tienda por Departamentos"
  },
  {
    "id": 226,
    "category": "Lugares",
    "secretWord": "Bosque Encantado",
    "impostorWord": "Selva Amazónica"
  },
  {
    "id": 227,
    "category": "Lugares",
    "secretWord": "Desierto del Sahara",
    "impostorWord": "Playa de Dunas"
  },
  {
    "id": 228,
    "category": "Lugares",
    "secretWord": "Pico de Montaña",
    "impostorWord": "Volcán Activo"
  },
  {
    "id": 229,
    "category": "Lugares",
    "secretWord": "Cueva Subterránea",
    "impostorWord": "Mina de Oro"
  },
  {
    "id": 230,
    "category": "Lugares",
    "secretWord": "Isla Desierta",
    "impostorWord": "Atolón Coralino"
  },
  {
    "id": 231,
    "category": "Lugares",
    "secretWord": "Pabellón de Hielo",
    "impostorWord": "Pista de Esquí"
  },
  {
    "id": 232,
    "category": "Lugares",
    "secretWord": "París",
    "impostorWord": "Roma"
  },
  {
    "id": 233,
    "category": "Lugares",
    "secretWord": "Nueva York",
    "impostorWord": "Londres"
  },
  {
    "id": 234,
    "category": "Lugares",
    "secretWord": "Tokio",
    "impostorWord": "Seúl"
  },
  {
    "id": 235,
    "category": "Lugares",
    "secretWord": "Madrid",
    "impostorWord": "Barcelona"
  },
  {
    "id": 236,
    "category": "Lugares",
    "secretWord": "Egipto (Pirámides)",
    "impostorWord": "México (Chichén Itzá)"
  },
  {
    "id": 237,
    "category": "Lugares",
    "secretWord": "Venecia (Góndolas)",
    "impostorWord": "Ámsterdam (Canales)"
  },
  {
    "id": 238,
    "category": "Lugares",
    "secretWord": "Polo Norte",
    "impostorWord": "Antártida"
  },
  {
    "id": 239,
    "category": "Lugares",
    "secretWord": "Faro Costero",
    "impostorWord": "Puerto Marítimo"
  },
  {
    "id": 240,
    "category": "Lugares",
    "secretWord": "Estación Espacial",
    "impostorWord": "Base Lunar"
  },
  {
    "id": 241,
    "category": "Lugares",
    "secretWord": "Submarino",
    "impostorWord": "Barco Pirata"
  },
  {
    "id": 242,
    "category": "Lugares",
    "secretWord": "Crucero de Vacaciones",
    "impostorWord": "Yate de Lujo"
  },
  {
    "id": 243,
    "category": "Lugares",
    "secretWord": "Granja de Animales",
    "impostorWord": "Invernadero Botánico"
  },
  {
    "id": 244,
    "category": "Lugares",
    "secretWord": "Parque Nacional",
    "impostorWord": "Jardín Botánico"
  },
  {
    "id": 245,
    "category": "Lugares",
    "secretWord": "Laboratorio Secreto",
    "impostorWord": "Búnker Nuclear"
  },
  {
    "id": 246,
    "category": "Lugares",
    "secretWord": "Gasolinera",
    "impostorWord": "Taller Mecánico"
  },
  {
    "id": 247,
    "category": "Lugares",
    "secretWord": "Peluquería / Barbería",
    "impostorWord": "Spa de Belleza"
  },
  {
    "id": 248,
    "category": "Lugares",
    "secretWord": "Lavandería Automática",
    "impostorWord": "Tintorería"
  },
  {
    "id": 249,
    "category": "Lugares",
    "secretWord": "Estación de Bomberos",
    "impostorWord": "Comisaría"
  },
  {
    "id": 250,
    "category": "Lugares",
    "secretWord": "Oficina Corporativa",
    "impostorWord": "Coworking"
  },
  {
    "id": 251,
    "category": "Lugares",
    "secretWord": "Palacio Real",
    "impostorWord": "Mansión de Famosos"
  },
  {
    "id": 252,
    "category": "Lugares",
    "secretWord": "Refugio de Montaña",
    "impostorWord": "Cabaña en el Bosque"
  },
  {
    "id": 253,
    "category": "Lugares",
    "secretWord": "Mirador Panorámico",
    "impostorWord": "Rascacielos"
  },
  {
    "id": 254,
    "category": "Lugares",
    "secretWord": "Campamento Scout",
    "impostorWord": "Glamping"
  },
  {
    "id": 255,
    "category": "Lugares",
    "secretWord": "Cataratas del Niágara",
    "impostorWord": "Cataratas de Iguazú"
  },
  {
    "id": 256,
    "category": "Lugares",
    "secretWord": "Río Amazonas",
    "impostorWord": "Río Nilo"
  },
  {
    "id": 257,
    "category": "Lugares",
    "secretWord": "Gran Cañón",
    "impostorWord": "Valle de la Muerte"
  },
  {
    "id": 258,
    "category": "Lugares",
    "secretWord": "Machu Picchu",
    "impostorWord": "Tulum"
  },
  {
    "id": 259,
    "category": "Lugares",
    "secretWord": "Coliseo Romano",
    "impostorWord": "Acrópolis de Atenas"
  },
  {
    "id": 260,
    "category": "Lugares",
    "secretWord": "Taj Mahal",
    "impostorWord": "Muralla China"
  },
  {
    "id": 261,
    "category": "Lugares",
    "secretWord": "Torre Eiffel",
    "impostorWord": "Torre de Pisa"
  },
  {
    "id": 262,
    "category": "Lugares",
    "secretWord": "Estatua de la Libertad",
    "impostorWord": "Cristo Redentor"
  },
  {
    "id": 263,
    "category": "Lugares",
    "secretWord": "Las Vegas",
    "impostorWord": "Miami Beach"
  },
  {
    "id": 264,
    "category": "Lugares",
    "secretWord": "La Habana",
    "impostorWord": "San Juan de Puerto Rico"
  },
  {
    "id": 265,
    "category": "Lugares",
    "secretWord": "Buenos Aires",
    "impostorWord": "Montevideo"
  },
  {
    "id": 266,
    "category": "Lugares",
    "secretWord": "Bogotá",
    "impostorWord": "Medellín"
  },
  {
    "id": 267,
    "category": "Lugares",
    "secretWord": "Ciudad de México",
    "impostorWord": "Guadalajara"
  },
  {
    "id": 268,
    "category": "Lugares",
    "secretWord": "Santiago de Chile",
    "impostorWord": "Lima"
  },
  {
    "id": 269,
    "category": "Lugares",
    "secretWord": "Río de Janeiro",
    "impostorWord": "São Paulo"
  },
  {
    "id": 270,
    "category": "Lugares",
    "secretWord": "Hawái",
    "impostorWord": "Tahiti / Polinesia"
  },
  {
    "id": 271,
    "category": "Lugares",
    "secretWord": "Islandia (Auroras)",
    "impostorWord": "Noruega (Fiordos)"
  },
  {
    "id": 272,
    "category": "Lugares",
    "secretWord": "Dubái (Burj Khalifa)",
    "impostorWord": "Doha (Catar)"
  },
  {
    "id": 273,
    "category": "Lugares",
    "secretWord": "Disneyland",
    "impostorWord": "Universal Studios"
  },
  {
    "id": 274,
    "category": "Lugares",
    "secretWord": "Panteón Nacional",
    "impostorWord": "Mausoleo Imperial"
  },
  {
    "id": 275,
    "category": "Lugares",
    "secretWord": "Oasis en el Desierto",
    "impostorWord": "Laguna Escondida"
  },
  {
    "id": 276,
    "category": "Profesiones",
    "secretWord": "Médico Cirujano",
    "impostorWord": "Enfermero"
  },
  {
    "id": 277,
    "category": "Profesiones",
    "secretWord": "Policía",
    "impostorWord": "Detective Privado"
  },
  {
    "id": 278,
    "category": "Profesiones",
    "secretWord": "Bombero",
    "impostorWord": "Paramédico"
  },
  {
    "id": 279,
    "category": "Profesiones",
    "secretWord": "Profesor de Escuela",
    "impostorWord": "Profesor Universitario"
  },
  {
    "id": 280,
    "category": "Profesiones",
    "secretWord": "Chef de Cocina",
    "impostorWord": "Camarero / Mesero"
  },
  {
    "id": 281,
    "category": "Profesiones",
    "secretWord": "Piloto de Avión",
    "impostorWord": "Azafata / Auxiliar de Vuelo"
  },
  {
    "id": 282,
    "category": "Profesiones",
    "secretWord": "Astronauta",
    "impostorWord": "Astrónomo"
  },
  {
    "id": 283,
    "category": "Profesiones",
    "secretWord": "Abogado",
    "impostorWord": "Juez del Tribunal"
  },
  {
    "id": 284,
    "category": "Profesiones",
    "secretWord": "Futbolista Profesional",
    "impostorWord": "Entrenador Físico"
  },
  {
    "id": 285,
    "category": "Profesiones",
    "secretWord": "Cantante de Rock",
    "impostorWord": "Cantante de Pop"
  },
  {
    "id": 286,
    "category": "Profesiones",
    "secretWord": "Actor de Hollywood",
    "impostorWord": "Director de Cine"
  },
  {
    "id": 287,
    "category": "Profesiones",
    "secretWord": "Pintor Artístico",
    "impostorWord": "Escultor"
  },
  {
    "id": 288,
    "category": "Profesiones",
    "secretWord": "Veterinario",
    "impostorWord": "Biólogo Marino"
  },
  {
    "id": 289,
    "category": "Profesiones",
    "secretWord": "Arquitecto",
    "impostorWord": "Albañil / Constructor"
  },
  {
    "id": 290,
    "category": "Profesiones",
    "secretWord": "Fotógrafo de Moda",
    "impostorWord": "Modelo de Pasarela"
  },
  {
    "id": 291,
    "category": "Profesiones",
    "secretWord": "Electricista",
    "impostorWord": "Fontanero / Plomero"
  },
  {
    "id": 292,
    "category": "Profesiones",
    "secretWord": "Mecánico de Coches",
    "impostorWord": "Conductor de Taxi"
  },
  {
    "id": 293,
    "category": "Profesiones",
    "secretWord": "Dentista / Odontólogo",
    "impostorWord": "Higienista Dental"
  },
  {
    "id": 294,
    "category": "Profesiones",
    "secretWord": "Programador Informático",
    "impostorWord": "Hacker Ético"
  },
  {
    "id": 295,
    "category": "Profesiones",
    "secretWord": "Mago Ilusionista",
    "impostorWord": "Payaso de Circo"
  },
  {
    "id": 296,
    "category": "Profesiones",
    "secretWord": "Espía Secreto",
    "impostorWord": "Guardaespaldas"
  },
  {
    "id": 297,
    "category": "Profesiones",
    "secretWord": "Pirata Aventurero",
    "impostorWord": "Marinero de Guerra"
  },
  {
    "id": 298,
    "category": "Profesiones",
    "secretWord": "Rey / Monarca",
    "impostorWord": "Príncipe Heredero"
  },
  {
    "id": 299,
    "category": "Profesiones",
    "secretWord": "Presidente del País",
    "impostorWord": "Alcalde de la Ciudad"
  },
  {
    "id": 300,
    "category": "Profesiones",
    "secretWord": "Periodista de Noticias",
    "impostorWord": "Locutor de Radio"
  },
  {
    "id": 301,
    "category": "Profesiones",
    "secretWord": "Youtuber / Streamer",
    "impostorWord": "Influencer de Instagram"
  },
  {
    "id": 302,
    "category": "Profesiones",
    "secretWord": "Jardinero",
    "impostorWord": "Agricultor / Granjero"
  },
  {
    "id": 303,
    "category": "Profesiones",
    "secretWord": "Pescador Artesanal",
    "impostorWord": "Buzo Profesional"
  },
  {
    "id": 304,
    "category": "Profesiones",
    "secretWord": "Panadero",
    "impostorWord": "Pastelero / Repostero"
  },
  {
    "id": 305,
    "category": "Profesiones",
    "secretWord": "Carnicero",
    "impostorWord": "Pescadero"
  },
  {
    "id": 306,
    "category": "Profesiones",
    "secretWord": "Barbero / Peluquero",
    "impostorWord": "Maquillador"
  },
  {
    "id": 307,
    "category": "Profesiones",
    "secretWord": "Costurera / Modista",
    "impostorWord": "Diseñador de Ropa"
  },
  {
    "id": 308,
    "category": "Profesiones",
    "secretWord": "Zapatero",
    "impostorWord": "Artesano de Cuero"
  },
  {
    "id": 309,
    "category": "Profesiones",
    "secretWord": "Cartero / Mensajero",
    "impostorWord": "Repartidor de Comida"
  },
  {
    "id": 310,
    "category": "Profesiones",
    "secretWord": "Cajero de Banco",
    "impostorWord": "Contador / Auditor"
  },
  {
    "id": 311,
    "category": "Profesiones",
    "secretWord": "Agente Inmobiliario",
    "impostorWord": "Tasador de Propiedades"
  },
  {
    "id": 312,
    "category": "Profesiones",
    "secretWord": "Guía Turístico",
    "impostorWord": "Traductor de Idiomas"
  },
  {
    "id": 313,
    "category": "Profesiones",
    "secretWord": "Arqueólogo",
    "impostorWord": "Historiador"
  },
  {
    "id": 314,
    "category": "Profesiones",
    "secretWord": "Científico de Laboratorio",
    "impostorWord": "Químico Farmacéutico"
  },
  {
    "id": 315,
    "category": "Profesiones",
    "secretWord": "Geólogo",
    "impostorWord": "Meteorólogo del Clima"
  },
  {
    "id": 316,
    "category": "Profesiones",
    "secretWord": "Minero de Carbón",
    "impostorWord": "Espeleólogo"
  },
  {
    "id": 317,
    "category": "Profesiones",
    "secretWord": "Cura / Sacerdote",
    "impostorWord": "Monje Budista"
  },
  {
    "id": 318,
    "category": "Profesiones",
    "secretWord": "Psicólogo Clínico",
    "impostorWord": "Psiquiatra"
  },
  {
    "id": 319,
    "category": "Profesiones",
    "secretWord": "Socorrista de Playa",
    "impostorWord": "Instructor de Surf"
  },
  {
    "id": 320,
    "category": "Profesiones",
    "secretWord": "Guardabosques",
    "impostorWord": "Guía de Safari"
  },
  {
    "id": 321,
    "category": "Profesiones",
    "secretWord": "Músico Callejero",
    "impostorWord": "Director de Orquesta"
  },
  {
    "id": 322,
    "category": "Profesiones",
    "secretWord": "Bailarín de Ballet",
    "impostorWord": "Gimnasta Olímpico"
  },
  {
    "id": 323,
    "category": "Profesiones",
    "secretWord": "Luchador de Sumo",
    "impostorWord": "Boxeador Campeón"
  },
  {
    "id": 324,
    "category": "Profesiones",
    "secretWord": "Piloto de Fórmula 1",
    "impostorWord": "Piloto de Rally"
  },
  {
    "id": 325,
    "category": "Profesiones",
    "secretWord": "DJ de Música Electrónica",
    "impostorWord": "Productor Musical"
  },
  {
    "id": 326,
    "category": "Profesiones",
    "secretWord": "Bibliotecario",
    "impostorWord": "Escritor de Novelas"
  },
  {
    "id": 327,
    "category": "Profesiones",
    "secretWord": "Joyero",
    "impostorWord": "Relojero Suizo"
  },
  {
    "id": 328,
    "category": "Profesiones",
    "secretWord": "Sommelier de Vinos",
    "impostorWord": "Barista de Café"
  },
  {
    "id": 329,
    "category": "Profesiones",
    "secretWord": "Cerrajero",
    "impostorWord": "Herrero Artesanal"
  },
  {
    "id": 330,
    "category": "Profesiones",
    "secretWord": "Carpintero",
    "impostorWord": "Ebanista"
  },
  {
    "id": 331,
    "category": "Profesiones",
    "secretWord": "Vigilante Nocturno",
    "impostorWord": "Portero de Discoteca"
  },
  {
    "id": 332,
    "category": "Profesiones",
    "secretWord": "Cobrador de Autobús",
    "impostorWord": "Revisor de Tren"
  },
  {
    "id": 333,
    "category": "Profesiones",
    "secretWord": "Agente de Tráfico",
    "impostorWord": "Patrullero de Carretera"
  },
  {
    "id": 334,
    "category": "Profesiones",
    "secretWord": "Ninja Sigiloso",
    "impostorWord": "Samurái de Honor"
  },
  {
    "id": 335,
    "category": "Profesiones",
    "secretWord": "Gladiador Romano",
    "impostorWord": "Caballero de Armadura"
  },
  {
    "id": 336,
    "category": "Profesiones",
    "secretWord": "Vikingo Navegante",
    "impostorWord": "Corsario Inglés"
  },
  {
    "id": 337,
    "category": "Profesiones",
    "secretWord": "Faraón Egipcio",
    "impostorWord": "Emperador Romano"
  },
  {
    "id": 338,
    "category": "Profesiones",
    "secretWord": "Detective Sherlock Holmes",
    "impostorWord": "Inspector Gadget"
  },
  {
    "id": 339,
    "category": "Profesiones",
    "secretWord": "Superhéroe con Capa",
    "impostorWord": "Villano de Cómic"
  },
  {
    "id": 340,
    "category": "Profesiones",
    "secretWord": "Guardia del Museo",
    "impostorWord": "Ladrón de Joyas"
  },
  {
    "id": 341,
    "category": "Ropa y Moda",
    "secretWord": "Camiseta de Algodón",
    "impostorWord": "Camisa de Manga Larga"
  },
  {
    "id": 342,
    "category": "Ropa y Moda",
    "secretWord": "Pantalones Vaqueros / Jeans",
    "impostorWord": "Pantalón de Chándal"
  },
  {
    "id": 343,
    "category": "Ropa y Moda",
    "secretWord": "Chaqueta de Cuero",
    "impostorWord": "Abrigo de Lana"
  },
  {
    "id": 344,
    "category": "Ropa y Moda",
    "secretWord": "Sudadera con Capucha",
    "impostorWord": "Jersey de Punto"
  },
  {
    "id": 345,
    "category": "Ropa y Moda",
    "secretWord": "Vestido de Noche",
    "impostorWord": "Falda Plisada"
  },
  {
    "id": 346,
    "category": "Ropa y Moda",
    "secretWord": "Traje Elegante / Esmoquin",
    "impostorWord": "Chaleco de Gala"
  },
  {
    "id": 347,
    "category": "Ropa y Moda",
    "secretWord": "Corbata",
    "impostorWord": "Pajarita / Lazo"
  },
  {
    "id": 348,
    "category": "Ropa y Moda",
    "secretWord": "Cinturón de Piel",
    "impostorWord": "Tirantes de Pantalón"
  },
  {
    "id": 349,
    "category": "Ropa y Moda",
    "secretWord": "Zapatillas Deportivas",
    "impostorWord": "Zapatos de Cuero"
  },
  {
    "id": 350,
    "category": "Ropa y Moda",
    "secretWord": "Botas de Nieve",
    "impostorWord": "Botas de Agua"
  },
  {
    "id": 351,
    "category": "Ropa y Moda",
    "secretWord": "Sandalias de Verano",
    "impostorWord": "Chanclas de Playa"
  },
  {
    "id": 352,
    "category": "Ropa y Moda",
    "secretWord": "Tacones Altos",
    "impostorWord": "Bailarinas / Zapatos Planos"
  },
  {
    "id": 353,
    "category": "Ropa y Moda",
    "secretWord": "Bufanda de Lana",
    "impostorWord": "Pañuelo de Seda"
  },
  {
    "id": 354,
    "category": "Ropa y Moda",
    "secretWord": "Guantes de Invierno",
    "impostorWord": "Mitones sin Dedos"
  },
  {
    "id": 355,
    "category": "Ropa y Moda",
    "secretWord": "Gorra de Béisbol",
    "impostorWord": "Sombrero de Paja"
  },
  {
    "id": 356,
    "category": "Ropa y Moda",
    "secretWord": "Gorro de Lana (Beanie)",
    "impostorWord": "Boina Francesa"
  },
  {
    "id": 357,
    "category": "Ropa y Moda",
    "secretWord": "Bañador / Traje de Baño",
    "impostorWord": "Bikini"
  },
  {
    "id": 358,
    "category": "Ropa y Moda",
    "secretWord": "Pijama de Franela",
    "impostorWord": "Camisón de Dormir"
  },
  {
    "id": 359,
    "category": "Ropa y Moda",
    "secretWord": "Calcetines Altos",
    "impostorWord": "Medias de Nylon"
  },
  {
    "id": 360,
    "category": "Ropa y Moda",
    "secretWord": "Chaleco Salvavidas",
    "impostorWord": "Chaleco Reflectante"
  },
  {
    "id": 361,
    "category": "Ropa y Moda",
    "secretWord": "Gafas de Buceo",
    "impostorWord": "Tubo de Snorkel"
  },
  {
    "id": 362,
    "category": "Ropa y Moda",
    "secretWord": "Corona de Diamantes",
    "impostorWord": "Tiara de Princesa"
  },
  {
    "id": 363,
    "category": "Ropa y Moda",
    "secretWord": "Capa de Mago",
    "impostorWord": "Túnica Medieval"
  },
  {
    "id": 364,
    "category": "Ropa y Moda",
    "secretWord": "Sombrero de Vaquero",
    "impostorWord": "Sombrero de Copa"
  },
  {
    "id": 365,
    "category": "Ropa y Moda",
    "secretWord": "Uniforme Militar",
    "impostorWord": "Uniforme Escolar"
  },
  {
    "id": 366,
    "category": "Ropa y Moda",
    "secretWord": "Delantal de Cocina",
    "impostorWord": "Bata de Laboratorio"
  },
  {
    "id": 367,
    "category": "Ropa y Moda",
    "secretWord": "Kimono Tradicional",
    "impostorWord": "Poncho de Lana"
  },
  {
    "id": 368,
    "category": "Ropa y Moda",
    "secretWord": "Pantalones Cortos / Shorts",
    "impostorWord": "Bermudas Playeras"
  },
  {
    "id": 369,
    "category": "Ropa y Moda",
    "secretWord": "Chubasquero Amarillo",
    "impostorWord": "Gabardina de Detective"
  },
  {
    "id": 370,
    "category": "Ropa y Moda",
    "secretWord": "Zapatillas de Casa",
    "impostorWord": "Pantuflas de Felpa"
  },
  {
    "id": 371,
    "category": "Ropa y Moda",
    "secretWord": "Gafas de Realidad Virtual",
    "impostorWord": "Visor Nocturno"
  },
  {
    "id": 372,
    "category": "Ropa y Moda",
    "secretWord": "Brazalete Deportivo",
    "impostorWord": "Tobillera de Plata"
  },
  {
    "id": 373,
    "category": "Ropa y Moda",
    "secretWord": "Albornoz de Hotel",
    "impostorWord": "Toalla con Capucha"
  },
  {
    "id": 374,
    "category": "Ropa y Moda",
    "secretWord": "Zapatos de Tacón de Aguja",
    "impostorWord": "Mocasines"
  },
  {
    "id": 375,
    "category": "Ropa y Moda",
    "secretWord": "Bandana para la Cabeza",
    "impostorWord": "Diadema para el Pelo"
  },
  {
    "id": 376,
    "category": "Ropa y Moda",
    "secretWord": "Bolso de Mano de Marca",
    "impostorWord": "Riñonera / Cangurera"
  },
  {
    "id": 377,
    "category": "Ropa y Moda",
    "secretWord": "Broche de Joyería",
    "impostorWord": "Pin Metálico"
  },
  {
    "id": 378,
    "category": "Ropa y Moda",
    "secretWord": "Gemelos de Camisa",
    "impostorWord": "Alfiler de Corbata"
  },
  {
    "id": 379,
    "category": "Ropa y Moda",
    "secretWord": "Máscara de Carnaval",
    "impostorWord": "Antifaz Veneciano"
  },
  {
    "id": 380,
    "category": "Ropa y Moda",
    "secretWord": "Peluca Rubia",
    "impostorWord": "Extensiones de Pelo"
  },
  {
    "id": 381,
    "category": "Ropa y Moda",
    "secretWord": "Pajarita Roja",
    "impostorWord": "Corbatín Negro"
  },
  {
    "id": 382,
    "category": "Ropa y Moda",
    "secretWord": "Mono de Trabajo / Peto",
    "impostorWord": "Traje de Buzo"
  },
  {
    "id": 383,
    "category": "Ropa y Moda",
    "secretWord": "Pechera Blindada",
    "impostorWord": "Chaleco Antibalas"
  },
  {
    "id": 384,
    "category": "Ropa y Moda",
    "secretWord": "Espuelas de Vaquero",
    "impostorWord": "Estribos de Montar"
  },
  {
    "id": 385,
    "category": "Ropa y Moda",
    "secretWord": "Turbante Árabe",
    "impostorWord": "Keffiyeh / Paliacate"
  },
  {
    "id": 386,
    "category": "Ropa y Moda",
    "secretWord": "Polo de Golf",
    "impostorWord": "Camiseta de Tenis"
  },
  {
    "id": 387,
    "category": "Ropa y Moda",
    "secretWord": "Guantes de Boxeo",
    "impostorWord": "Vendas de Mano"
  },
  {
    "id": 388,
    "category": "Ropa y Moda",
    "secretWord": "Espinilleras de Fútbol",
    "impostorWord": "Rodilleras Protectoras"
  },
  {
    "id": 389,
    "category": "Ropa y Moda",
    "secretWord": "Gafas de Esquí",
    "impostorWord": "Máscara de Motocross"
  },
  {
    "id": 390,
    "category": "Ropa y Moda",
    "secretWord": "Patines de Cuatro Ruedas",
    "impostorWord": "Patines en Línea"
  },
  {
    "id": 391,
    "category": "Ropa y Moda",
    "secretWord": "Gorro de Natación",
    "impostorWord": "Tapones de Oídos"
  },
  {
    "id": 392,
    "category": "Ropa y Moda",
    "secretWord": "Pantalón de Cuero",
    "impostorWord": "Mallas Deportivas / Leggings"
  },
  {
    "id": 393,
    "category": "Ropa y Moda",
    "secretWord": "Cazadora Vaquera",
    "impostorWord": "Chaleco Vaquero"
  },
  {
    "id": 394,
    "category": "Ropa y Moda",
    "secretWord": "Zuecos de Madera",
    "impostorWord": "Crocs de Goma"
  },
  {
    "id": 395,
    "category": "Ropa y Moda",
    "secretWord": "Traje de Neopreno",
    "impostorWord": "Traje Espacial"
  },
  {
    "id": 396,
    "category": "Transporte",
    "secretWord": "Avión Comercial",
    "impostorWord": "Jet Privado"
  },
  {
    "id": 397,
    "category": "Transporte",
    "secretWord": "Helicóptero de Rescate",
    "impostorWord": "Autogiro"
  },
  {
    "id": 398,
    "category": "Transporte",
    "secretWord": "Coche Deportivo",
    "impostorWord": "Coche Eléctrico"
  },
  {
    "id": 399,
    "category": "Transporte",
    "secretWord": "Motocicleta Harley",
    "impostorWord": "Scooter de Ciudad"
  },
  {
    "id": 400,
    "category": "Transporte",
    "secretWord": "Tren de Alta Velocidad (AVE)",
    "impostorWord": "Metro Subterráneo"
  },
  {
    "id": 401,
    "category": "Transporte",
    "secretWord": "Tranvía Antiguo",
    "impostorWord": "Teleférico de Montaña"
  },
  {
    "id": 402,
    "category": "Transporte",
    "secretWord": "Autobús Escolar",
    "impostorWord": "Autobús Turístico de 2 Pisos"
  },
  {
    "id": 403,
    "category": "Transporte",
    "secretWord": "Camión de Bomberos",
    "impostorWord": "Ambulancia de Emergencias"
  },
  {
    "id": 404,
    "category": "Transporte",
    "secretWord": "Camión de la Basura",
    "impostorWord": "Barredora de Calles"
  },
  {
    "id": 405,
    "category": "Transporte",
    "secretWord": "Tractor Agrícola",
    "impostorWord": "Excavadora de Construcción"
  },
  {
    "id": 406,
    "category": "Transporte",
    "secretWord": "Grúa Móvil",
    "impostorWord": "Carretilla Elevadora (Forklift)"
  },
  {
    "id": 407,
    "category": "Transporte",
    "secretWord": "Barco Velero",
    "impostorWord": "Catamarán"
  },
  {
    "id": 408,
    "category": "Transporte",
    "secretWord": "Canoa de Madera",
    "impostorWord": "Kayak Deportivo"
  },
  {
    "id": 409,
    "category": "Transporte",
    "secretWord": "Moto de Agua (Jet Ski)",
    "impostorWord": "Lancha Rápida"
  },
  {
    "id": 410,
    "category": "Transporte",
    "secretWord": "Globo Aerostático",
    "impostorWord": "Dirigible / Zepelín"
  },
  {
    "id": 411,
    "category": "Transporte",
    "secretWord": "Parapente con Motor",
    "impostorWord": "Ala Delta"
  },
  {
    "id": 412,
    "category": "Transporte",
    "secretWord": "Cohete Espacial",
    "impostorWord": "Transbordador Espacial"
  },
  {
    "id": 413,
    "category": "Transporte",
    "secretWord": "Monociclo de Circo",
    "impostorWord": "Triciclo Infantil"
  },
  {
    "id": 414,
    "category": "Transporte",
    "secretWord": "Carroza de Caballos",
    "impostorWord": "Carreta del Oeste"
  },
  {
    "id": 415,
    "category": "Transporte",
    "secretWord": "Trineo de Perros Huskies",
    "impostorWord": "Moto de Nieve"
  },
  {
    "id": 416,
    "category": "Transporte",
    "secretWord": "Tuk-Tuk Asiático",
    "impostorWord": "Bicitaxi"
  },
  {
    "id": 417,
    "category": "Transporte",
    "secretWord": "Limusina Negra",
    "impostorWord": "Taxi Amarillo"
  },
  {
    "id": 418,
    "category": "Transporte",
    "secretWord": "Camión Cisterna de Gasolina",
    "impostorWord": "Camión Hormigonera"
  },
  {
    "id": 419,
    "category": "Transporte",
    "secretWord": "Furgoneta Camper",
    "impostorWord": "Caravana / Autocaravana"
  },
  {
    "id": 420,
    "category": "Transporte",
    "secretWord": "Quad / Cuatrimoto",
    "impostorWord": "Buggy del Desierto"
  },
  {
    "id": 421,
    "category": "Transporte",
    "secretWord": "Patinete Eléctrico",
    "impostorWord": "Segway"
  },
  {
    "id": 422,
    "category": "Transporte",
    "secretWord": "Monorraíl de Ciudad",
    "impostorWord": "Funicular"
  },
  {
    "id": 423,
    "category": "Transporte",
    "secretWord": "Ferris / Buque Transbordador",
    "impostorWord": "Portaviones Militar"
  },
  {
    "id": 424,
    "category": "Transporte",
    "secretWord": "Submarino Amarillo",
    "impostorWord": "Batscafo de Profundidad"
  },
  {
    "id": 425,
    "category": "Transporte",
    "secretWord": "Góndola Veneciana",
    "impostorWord": "Balsa de Troncos"
  },
  {
    "id": 426,
    "category": "Transporte",
    "secretWord": "Carretilla de Jardín",
    "impostorWord": "Carrito del Supermercado"
  },
  {
    "id": 427,
    "category": "Transporte",
    "secretWord": "Tanque de Guerra",
    "impostorWord": "Vehículo Blindado Humvee"
  },
  {
    "id": 428,
    "category": "Transporte",
    "secretWord": "Coche Fúnebre",
    "impostorWord": "Furgoneta de Reparto"
  },
  {
    "id": 429,
    "category": "Transporte",
    "secretWord": "Quitanieves Gigante",
    "impostorWord": "Aplanadora de Asfalto"
  },
  {
    "id": 430,
    "category": "Transporte",
    "secretWord": "Hovercraft / Aerodeslizador",
    "impostorWord": "Hidroavión"
  },
  {
    "id": 431,
    "category": "Transporte",
    "secretWord": "Sidecar de Moto",
    "impostorWord": "Remolque de Coche"
  },
  {
    "id": 432,
    "category": "Transporte",
    "secretWord": "Coche de Choque (Feria)",
    "impostorWord": "Kart de Carreras"
  },
  {
    "id": 433,
    "category": "Transporte",
    "secretWord": "Patineta Longboard",
    "impostorWord": "Patineta Penny"
  },
  {
    "id": 434,
    "category": "Transporte",
    "secretWord": "Bicicleta Tandem para Dos",
    "impostorWord": "Bicicleta Eléctrica"
  },
  {
    "id": 435,
    "category": "Transporte",
    "secretWord": "Avioneta de Fumigación",
    "impostorWord": "Biplano Clásico"
  },
  {
    "id": 436,
    "category": "Transporte",
    "secretWord": "Barco Pesquero de Arrastre",
    "impostorWord": "Rompehielos Ártico"
  },
  {
    "id": 437,
    "category": "Transporte",
    "secretWord": "Hoverboard Eléctrico",
    "impostorWord": "Patineta Voladora de Regreso al Futuro"
  },
  {
    "id": 438,
    "category": "Transporte",
    "secretWord": "Coche Descapotable",
    "impostorWord": "Coche Cupé"
  },
  {
    "id": 439,
    "category": "Transporte",
    "secretWord": "Trolebús Eléctrico",
    "impostorWord": "Microbús Urbano"
  },
  {
    "id": 440,
    "category": "Transporte",
    "secretWord": "Cápsula Espacial Apollo",
    "impostorWord": "Satélite Artificial"
  },
  {
    "id": 441,
    "category": "Naturaleza",
    "secretWord": "Tormenta con Rayos",
    "impostorWord": "Huracán / Ciclón"
  },
  {
    "id": 442,
    "category": "Naturaleza",
    "secretWord": "Arcoíris Completo",
    "impostorWord": "Aurora Boreal"
  },
  {
    "id": 443,
    "category": "Naturaleza",
    "secretWord": "Terremoto Fuerte",
    "impostorWord": "Tsunami Gigante"
  },
  {
    "id": 444,
    "category": "Naturaleza",
    "secretWord": "Tornado en el Campo",
    "impostorWord": "Tormenta de Arena"
  },
  {
    "id": 445,
    "category": "Naturaleza",
    "secretWord": "Volcán en Erupción",
    "impostorWord": "Géiser de Agua Caliente"
  },
  {
    "id": 446,
    "category": "Naturaleza",
    "secretWord": "Eclipse Solar",
    "impostorWord": "Eclipse Lunar"
  },
  {
    "id": 447,
    "category": "Naturaleza",
    "secretWord": "Luna Llena Brillante",
    "impostorWord": "Estrella Fugaz"
  },
  {
    "id": 448,
    "category": "Naturaleza",
    "secretWord": "Galaxia Espiral",
    "impostorWord": "Agujero Negro"
  },
  {
    "id": 449,
    "category": "Naturaleza",
    "secretWord": "Planeta Marte",
    "impostorWord": "Planeta Júpiter con Anillos"
  },
  {
    "id": 450,
    "category": "Naturaleza",
    "secretWord": "Cometa Halley",
    "impostorWord": "Asteroide en Órbita"
  },
  {
    "id": 451,
    "category": "Naturaleza",
    "secretWord": "Granizo Helado",
    "impostorWord": "Nevada Intensa"
  },
  {
    "id": 452,
    "category": "Naturaleza",
    "secretWord": "Niebla Espesa",
    "impostorWord": "Humo de Bosque"
  },
  {
    "id": 453,
    "category": "Naturaleza",
    "secretWord": "Rocío de la Mañana",
    "impostorWord": "Escarcha Helada"
  },
  {
    "id": 454,
    "category": "Naturaleza",
    "secretWord": "Ola Marina Gigante",
    "impostorWord": "Marea Alta"
  },
  {
    "id": 455,
    "category": "Naturaleza",
    "secretWord": "Arrecife de Coral",
    "impostorWord": "Fosa Oceánica"
  },
  {
    "id": 456,
    "category": "Naturaleza",
    "secretWord": "Iceberg Flotante",
    "impostorWord": "Glaciar Milenario"
  },
  {
    "id": 457,
    "category": "Naturaleza",
    "secretWord": "Cascada de Agua",
    "impostorWord": "Rápido de Río"
  },
  {
    "id": 458,
    "category": "Naturaleza",
    "secretWord": "Árbol Secuoya Gigante",
    "impostorWord": "Palmera de Coco"
  },
  {
    "id": 459,
    "category": "Naturaleza",
    "secretWord": "Flor de Girasol",
    "impostorWord": "Rosa Roja con Espinas"
  },
  {
    "id": 460,
    "category": "Naturaleza",
    "secretWord": "Cactus del Desierto",
    "impostorWord": "Planta Carnívora"
  },
  {
    "id": 461,
    "category": "Naturaleza",
    "secretWord": "Trébol de Cuatro Hojas",
    "impostorWord": "Hoja de Laurel"
  },
  {
    "id": 462,
    "category": "Naturaleza",
    "secretWord": "Bambú Chino",
    "impostorWord": "Caña de Azúcar"
  },
  {
    "id": 463,
    "category": "Naturaleza",
    "secretWord": "Margarita Silvestre",
    "impostorWord": "Tulipán Holandés"
  },
  {
    "id": 464,
    "category": "Naturaleza",
    "secretWord": "Orquídea Exótica",
    "impostorWord": "Flor de Loto"
  },
  {
    "id": 465,
    "category": "Naturaleza",
    "secretWord": "Musgo Húmedo",
    "impostorWord": "Helecho del Bosque"
  },
  {
    "id": 466,
    "category": "Naturaleza",
    "secretWord": "Hongo Champiñón",
    "impostorWord": "Seta Venenosa Roja"
  },
  {
    "id": 467,
    "category": "Naturaleza",
    "secretWord": "Diamante en Bruto",
    "impostorWord": "Rubí Rojo"
  },
  {
    "id": 468,
    "category": "Naturaleza",
    "secretWord": "Pepita de Oro",
    "impostorWord": "Lingote de Plata"
  },
  {
    "id": 469,
    "category": "Naturaleza",
    "secretWord": "Fósil de Dinosaurio",
    "impostorWord": "Hueso de Mamut"
  },
  {
    "id": 470,
    "category": "Naturaleza",
    "secretWord": "Meteorito Caído",
    "impostorWord": "Roca Volcánica"
  },
  {
    "id": 471,
    "category": "Naturaleza",
    "secretWord": "Sol del Mediodía",
    "impostorWord": "Atardecer Dorado"
  },
  {
    "id": 472,
    "category": "Naturaleza",
    "secretWord": "Cielo Estrellado",
    "impostorWord": "Vía Láctea"
  },
  {
    "id": 473,
    "category": "Naturaleza",
    "secretWord": "Pantano Nublado",
    "impostorWord": "Manglar Tropical"
  },
  {
    "id": 474,
    "category": "Naturaleza",
    "secretWord": "Cañón Rocoso",
    "impostorWord": "Acantilado Marino"
  },
  {
    "id": 475,
    "category": "Naturaleza",
    "secretWord": "Estalactita de Cueva",
    "impostorWord": "Estalagmita"
  },
  {
    "id": 476,
    "category": "Naturaleza",
    "secretWord": "Duna de Arena",
    "impostorWord": "Cerro de Piedras"
  },
  {
    "id": 477,
    "category": "Naturaleza",
    "secretWord": "Manantial de Agua Dulce",
    "impostorWord": "Pozo Artesiano"
  },
  {
    "id": 478,
    "category": "Naturaleza",
    "secretWord": "Selva Húmeda",
    "impostorWord": "Sabana Africana"
  },
  {
    "id": 479,
    "category": "Naturaleza",
    "secretWord": "Tundra Helada",
    "impostorWord": "Taiga de Pinos"
  },
  {
    "id": 480,
    "category": "Naturaleza",
    "secretWord": "Pradera Verde",
    "impostorWord": "Valle Floral"
  },
  {
    "id": 481,
    "category": "Naturaleza",
    "secretWord": "Brisa Marina",
    "impostorWord": "Ventisca de Nieve"
  },
  {
    "id": 482,
    "category": "Naturaleza",
    "secretWord": "Llovizna Suave",
    "impostorWord": "Diluvio Torrencial"
  },
  {
    "id": 483,
    "category": "Naturaleza",
    "secretWord": "Calor Sofocante",
    "impostorWord": "Ola de Frío Polar"
  },
  {
    "id": 484,
    "category": "Naturaleza",
    "secretWord": "Rayo Láser Solar",
    "impostorWord": "Luz de Neón"
  },
  {
    "id": 485,
    "category": "Naturaleza",
    "secretWord": "Ámbar con Insecto",
    "impostorWord": "Cristal de Cuarzo"
  },
  {
    "id": 486,
    "category": "Naturaleza",
    "secretWord": "Perla Ostrífera",
    "impostorWord": "Concha Marina"
  },
  {
    "id": 487,
    "category": "Naturaleza",
    "secretWord": "Arena Movediza",
    "impostorWord": "Lodo Fangoso"
  },
  {
    "id": 488,
    "category": "Naturaleza",
    "secretWord": "Lago de Lava",
    "impostorWord": "Cráter de Volcán"
  },
  {
    "id": 489,
    "category": "Naturaleza",
    "secretWord": "Isla Volcánica",
    "impostorWord": "Archipiélago"
  },
  {
    "id": 490,
    "category": "Naturaleza",
    "secretWord": "Pino de Navidad",
    "impostorWord": "Roble Centenario"
  },
  {
    "id": 491,
    "category": "Naturaleza",
    "secretWord": "Sauce Llorón",
    "impostorWord": "Eucalipto Gigante"
  },
  {
    "id": 492,
    "category": "Naturaleza",
    "secretWord": "Olivo Centenario",
    "impostorWord": "Vid de Uva"
  },
  {
    "id": 493,
    "category": "Naturaleza",
    "secretWord": "Lavanda Morada",
    "impostorWord": "Menta Fresca"
  },
  {
    "id": 494,
    "category": "Naturaleza",
    "secretWord": "Albahaca Aromática",
    "impostorWord": "Romero Silvestre"
  },
  {
    "id": 495,
    "category": "Naturaleza",
    "secretWord": "Cilantro Fresco",
    "impostorWord": "Perejil Verde"
  },
  {
    "id": 496,
    "category": "Naturaleza",
    "secretWord": "Pimienta Negra",
    "impostorWord": "Canela en Rama"
  },
  {
    "id": 497,
    "category": "Naturaleza",
    "secretWord": "Vainilla Natural",
    "impostorWord": "Cacao Puro"
  },
  {
    "id": 498,
    "category": "Naturaleza",
    "secretWord": "Jengibre Picante",
    "impostorWord": "Cúrcuma Dorada"
  },
  {
    "id": 499,
    "category": "Naturaleza",
    "secretWord": "Nuez Moscada",
    "impostorWord": "Clavo de Olor"
  },
  {
    "id": 500,
    "category": "Naturaleza",
    "secretWord": "Champiñón Portobello",
    "impostorWord": "Trufa Negra Subterránea"
  },
  {
    "id": 501,
    "category": "Naturaleza",
    "secretWord": "Roca Caliza",
    "impostorWord": "Mármol Blanco"
  },
  {
    "id": 502,
    "category": "Naturaleza",
    "secretWord": "Granito Gris",
    "impostorWord": "Basalto Negro"
  },
  {
    "id": 503,
    "category": "Naturaleza",
    "secretWord": "Obsidiana Brillante",
    "impostorWord": "Jade Verde"
  },
  {
    "id": 504,
    "category": "Naturaleza",
    "secretWord": "Ópalo Multicolor",
    "impostorWord": "Zafiro Azul"
  },
  {
    "id": 505,
    "category": "Naturaleza",
    "secretWord": "Esmeralda Verde",
    "impostorWord": "Turquesa Marina"
  }
];
