# El Impostor 🕵️‍♂️ (created by Kendry)

Juego de deduccion social y palabras secretas con mas de 500 palabras.

## 📱 ¿Como obtener tu archivo APK automaticamente?

1. Crea un nuevo repositorio en tu cuenta de [GitHub](https://github.com/new).
2. Sube los archivos de este proyecto (o el zip directamente).
3. Ve a la pestana **Actions** en tu repositorio de GitHub.
4. El flujo **Generar APK El Impostor** se ejecutara automaticamente.
5. Haz clic en la ejecucion completada y descarga el artefacto **El-Impostor-APK**.
6. ¡Instala el archivo `.apk` en tu telefono Android y a jugar!
