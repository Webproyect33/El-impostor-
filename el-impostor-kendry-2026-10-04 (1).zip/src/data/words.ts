import { WordItem } from '../types';

export const CATEGORIES = [
  { id: 'all', name: 'Todas las categorías (500+)', icon: '🎲', color: 'from-purple-500 to-indigo-600' },
  { id: 'animales', name: 'Animales y Criaturas', icon: '🦁', color: 'from-amber-500 to-orange-600' },
  { id: 'comida', name: 'Comida y Bebida', icon: '🍕', color: 'from-red-500 to-rose-600' },
  { id: 'objetos', name: 'Objetos y Tecnología', icon: '📱', color: 'from-blue-500 to-cyan-600' },
  { id: 'lugares', name: 'Lugares y Edificios', icon: '🏰', color: 'from-emerald-500 to-teal-600' },
  { id: 'profesiones', name: 'Profesiones y Oficios', icon: '👨‍🚀', color: 'from-violet-500 to-purple-600' },
  { id: 'deportes', name: 'Deportes y Juegos', icon: '⚽', color: 'from-green-500 to-emerald-600' },
  { id: 'cotidiano', name: 'Hogar y Cosas Cotidianas', icon: '🛋️', color: 'from-yellow-500 to-amber-600' },
  { id: 'naturaleza', name: 'Naturaleza y Clima', icon: '🌋', color: 'from-sky-500 to-blue-600' },
] as const;

export const WORDS_DATABASE: WordItem[] = [
  {
    "id": "a1",
    "category": "animales",
    "mainWord": "Perro",
    "impostorWord": "Lobo"
  },
  {
    "id": "a2",
    "category": "animales",
    "mainWord": "Gato",
    "impostorWord": "Tigre"
  },
  {
    "id": "a3",
    "category": "animales",
    "mainWord": "León",
    "impostorWord": "Leopardo"
  },
  {
    "id": "a4",
    "category": "animales",
    "mainWord": "Elefante",
    "impostorWord": "Mamut"
  },
  {
    "id": "a5",
    "category": "animales",
    "mainWord": "Jirafa",
    "impostorWord": "Cebra"
  },
  {
    "id": "a6",
    "category": "animales",
    "mainWord": "Caballo",
    "impostorWord": "Burro"
  },
  {
    "id": "a7",
    "category": "animales",
    "mainWord": "Oso polar",
    "impostorWord": "Oso pardo"
  },
  {
    "id": "a8",
    "category": "animales",
    "mainWord": "Tiburón",
    "impostorWord": "Delfín"
  },
  {
    "id": "a9",
    "category": "animales",
    "mainWord": "Ballena",
    "impostorWord": "Orca"
  },
  {
    "id": "a10",
    "category": "animales",
    "mainWord": "Pingüino",
    "impostorWord": "Foca"
  },
  {
    "id": "a11",
    "category": "animales",
    "mainWord": "Águila",
    "impostorWord": "Halcón"
  },
  {
    "id": "a12",
    "category": "animales",
    "mainWord": "Búho",
    "impostorWord": "Lechuza"
  },
  {
    "id": "a13",
    "category": "animales",
    "mainWord": "Cocodrilo",
    "impostorWord": "Caimán"
  },
  {
    "id": "a14",
    "category": "animales",
    "mainWord": "Serpiente",
    "impostorWord": "Lagarto"
  },
  {
    "id": "a15",
    "category": "animales",
    "mainWord": "Rana",
    "impostorWord": "Sapo"
  },
  {
    "id": "a16",
    "category": "animales",
    "mainWord": "Mono",
    "impostorWord": "Gorila"
  },
  {
    "id": "a17",
    "category": "animales",
    "mainWord": "Chimpancé",
    "impostorWord": "Orangután"
  },
  {
    "id": "a18",
    "category": "animales",
    "mainWord": "Canguro",
    "impostorWord": "Koala"
  },
  {
    "id": "a19",
    "category": "animales",
    "mainWord": "Conejo",
    "impostorWord": "Liebre"
  },
  {
    "id": "a20",
    "category": "animales",
    "mainWord": "Ratón",
    "impostorWord": "Hámster"
  },
  {
    "id": "a21",
    "category": "animales",
    "mainWord": "Murciélago",
    "impostorWord": "Vampiro"
  },
  {
    "id": "a22",
    "category": "animales",
    "mainWord": "Pulpo",
    "impostorWord": "Calamar"
  },
  {
    "id": "a23",
    "category": "animales",
    "mainWord": "Medusa",
    "impostorWord": "Estrella de mar"
  },
  {
    "id": "a24",
    "category": "animales",
    "mainWord": "Cangrejo",
    "impostorWord": "Langosta"
  },
  {
    "id": "a25",
    "category": "animales",
    "mainWord": "Camello",
    "impostorWord": "Dromedario"
  },
  {
    "id": "a26",
    "category": "animales",
    "mainWord": "Llama",
    "impostorWord": "Alpaca"
  },
  {
    "id": "a27",
    "category": "animales",
    "mainWord": "Oveja",
    "impostorWord": "Cabra"
  },
  {
    "id": "a28",
    "category": "animales",
    "mainWord": "Vaca",
    "impostorWord": "Toro"
  },
  {
    "id": "a29",
    "category": "animales",
    "mainWord": "Cerdo",
    "impostorWord": "Jabalí"
  },
  {
    "id": "a30",
    "category": "animales",
    "mainWord": "Pato",
    "impostorWord": "Ganso"
  },
  {
    "id": "a31",
    "category": "animales",
    "mainWord": "Gallina",
    "impostorWord": "Pavo"
  },
  {
    "id": "a32",
    "category": "animales",
    "mainWord": "Flamenco",
    "impostorWord": "Cigüeña"
  },
  {
    "id": "a33",
    "category": "animales",
    "mainWord": "Loro",
    "impostorWord": "Guacamayo"
  },
  {
    "id": "a34",
    "category": "animales",
    "mainWord": "Pájaro carpintero",
    "impostorWord": "Colibrí"
  },
  {
    "id": "a35",
    "category": "animales",
    "mainWord": "Avestruz",
    "impostorWord": "Emú"
  },
  {
    "id": "a36",
    "category": "animales",
    "mainWord": "Pavo real",
    "impostorWord": "Faisán"
  },
  {
    "id": "a37",
    "category": "animales",
    "mainWord": "Zorro",
    "impostorWord": "Chacal"
  },
  {
    "id": "a38",
    "category": "animales",
    "mainWord": "Hiena",
    "impostorWord": "Guepardo"
  },
  {
    "id": "a39",
    "category": "animales",
    "mainWord": "Hipopótamo",
    "impostorWord": "Rinoceronte"
  },
  {
    "id": "a40",
    "category": "animales",
    "mainWord": "Panda",
    "impostorWord": "Panda rojo"
  },
  {
    "id": "a41",
    "category": "animales",
    "mainWord": "Ardilla",
    "impostorWord": "Castor"
  },
  {
    "id": "a42",
    "category": "animales",
    "mainWord": "Nutria",
    "impostorWord": "Hurón"
  },
  {
    "id": "a43",
    "category": "animales",
    "mainWord": "Camaleón",
    "impostorWord": "Iguana"
  },
  {
    "id": "a44",
    "category": "animales",
    "mainWord": "Tortuga marina",
    "impostorWord": "Tortuga terrestre"
  },
  {
    "id": "a45",
    "category": "animales",
    "mainWord": "Abeja",
    "impostorWord": "Avispa"
  },
  {
    "id": "a46",
    "category": "animales",
    "mainWord": "Hormiga",
    "impostorWord": "Termita"
  },
  {
    "id": "a47",
    "category": "animales",
    "mainWord": "Mariposa",
    "impostorWord": "Polilla"
  },
  {
    "id": "a48",
    "category": "animales",
    "mainWord": "Mariquita",
    "impostorWord": "Escarabajo"
  },
  {
    "id": "a49",
    "category": "animales",
    "mainWord": "Grillo",
    "impostorWord": "Saltamontes"
  },
  {
    "id": "a50",
    "category": "animales",
    "mainWord": "Escorpión",
    "impostorWord": "Araña"
  },
  {
    "id": "a51",
    "category": "animales",
    "mainWord": "Ciempiés",
    "impostorWord": "Milpiés"
  },
  {
    "id": "a52",
    "category": "animales",
    "mainWord": "Caracol",
    "impostorWord": "Babosa"
  },
  {
    "id": "a53",
    "category": "animales",
    "mainWord": "Caballito de mar",
    "impostorWord": "Pez payaso"
  },
  {
    "id": "a54",
    "category": "animales",
    "mainWord": "Pez espada",
    "impostorWord": "Manta raya"
  },
  {
    "id": "a55",
    "category": "animales",
    "mainWord": "Piraña",
    "impostorWord": "Barracuda"
  },
  {
    "id": "a56",
    "category": "animales",
    "mainWord": "Suricata",
    "impostorWord": "Mangosta"
  },
  {
    "id": "a57",
    "category": "animales",
    "mainWord": "Perezoso",
    "impostorWord": "Oso hormiguero"
  },
  {
    "id": "a58",
    "category": "animales",
    "mainWord": "Armadillo",
    "impostorWord": "Pangolín"
  },
  {
    "id": "a59",
    "category": "animales",
    "mainWord": "Tucán",
    "impostorWord": "Pelícano"
  },
  {
    "id": "a60",
    "category": "animales",
    "mainWord": "Cisne",
    "impostorWord": "Garza"
  },
  {
    "id": "a61",
    "category": "animales",
    "mainWord": "Cuervo",
    "impostorWord": "Urraca"
  },
  {
    "id": "a62",
    "category": "animales",
    "mainWord": "Búfalo",
    "impostorWord": "Bisonte"
  },
  {
    "id": "a63",
    "category": "animales",
    "mainWord": "Alce",
    "impostorWord": "Ciervo"
  },
  {
    "id": "a64",
    "category": "animales",
    "mainWord": "Reno",
    "impostorWord": "Antílope"
  },
  {
    "id": "a65",
    "category": "animales",
    "mainWord": "Mapache",
    "impostorWord": "Tejón"
  },
  {
    "id": "a66",
    "category": "animales",
    "mainWord": "Mofeta",
    "impostorWord": "Comadreja"
  },
  {
    "id": "a67",
    "category": "animales",
    "mainWord": "Morsa",
    "impostorWord": "León marino"
  },
  {
    "id": "a68",
    "category": "animales",
    "mainWord": "Erizo",
    "impostorWord": "Puercoespín"
  },
  {
    "id": "a69",
    "category": "animales",
    "mainWord": "Ornitorrinco",
    "impostorWord": "Equidna"
  },
  {
    "id": "a70",
    "category": "animales",
    "mainWord": "Tarántula",
    "impostorWord": "Viuda negra"
  },
  {
    "id": "a71",
    "category": "animales",
    "mainWord": "Gaviota",
    "impostorWord": "Albatros"
  },
  {
    "id": "a72",
    "category": "animales",
    "mainWord": "Pez globo",
    "impostorWord": "Anguila"
  },
  {
    "id": "a73",
    "category": "animales",
    "mainWord": "Salamandra",
    "impostorWord": "Tritón"
  },
  {
    "id": "a74",
    "category": "animales",
    "mainWord": "Jaguar",
    "impostorWord": "Pantera"
  },
  {
    "id": "a75",
    "category": "animales",
    "mainWord": "Lince",
    "impostorWord": "Gato montés"
  },
  {
    "id": "c1",
    "category": "comida",
    "mainWord": "Pizza",
    "impostorWord": "Hamburguesa"
  },
  {
    "id": "c2",
    "category": "comida",
    "mainWord": "Sushi",
    "impostorWord": "Ceviche"
  },
  {
    "id": "c3",
    "category": "comida",
    "mainWord": "Tacos",
    "impostorWord": "Burritos"
  },
  {
    "id": "c4",
    "category": "comida",
    "mainWord": "Espaguetis",
    "impostorWord": "Lasaña"
  },
  {
    "id": "c5",
    "category": "comida",
    "mainWord": "Paella",
    "impostorWord": "Risotto"
  },
  {
    "id": "c6",
    "category": "comida",
    "mainWord": "Hot dog",
    "impostorWord": "Sándwich"
  },
  {
    "id": "c7",
    "category": "comida",
    "mainWord": "Papas fritas",
    "impostorWord": "Aros de cebolla"
  },
  {
    "id": "c8",
    "category": "comida",
    "mainWord": "Pollo frito",
    "impostorWord": "Alitas picantes"
  },
  {
    "id": "c9",
    "category": "comida",
    "mainWord": "Asado",
    "impostorWord": "Barbacoa"
  },
  {
    "id": "c10",
    "category": "comida",
    "mainWord": "Empanada",
    "impostorWord": "Arepa"
  },
  {
    "id": "c11",
    "category": "comida",
    "mainWord": "Nachos",
    "impostorWord": "Quesadilla"
  },
  {
    "id": "c12",
    "category": "comida",
    "mainWord": "Croquetas",
    "impostorWord": "Nuggets"
  },
  {
    "id": "c13",
    "category": "comida",
    "mainWord": "Sopa de fideos",
    "impostorWord": "Ramen"
  },
  {
    "id": "c14",
    "category": "comida",
    "mainWord": "Ensalada César",
    "impostorWord": "Ensalada rusa"
  },
  {
    "id": "c15",
    "category": "comida",
    "mainWord": "Guacamole",
    "impostorWord": "Hummus"
  },
  {
    "id": "c16",
    "category": "comida",
    "mainWord": "Tortilla de patatas",
    "impostorWord": "Omelette"
  },
  {
    "id": "c17",
    "category": "comida",
    "mainWord": "Crepes",
    "impostorWord": "Pancakes"
  },
  {
    "id": "c18",
    "category": "comida",
    "mainWord": "Waffles",
    "impostorWord": "Churros"
  },
  {
    "id": "c19",
    "category": "comida",
    "mainWord": "Donut",
    "impostorWord": "Muffin"
  },
  {
    "id": "c20",
    "category": "comida",
    "mainWord": "Croissant",
    "impostorWord": "Baguette"
  },
  {
    "id": "c21",
    "category": "comida",
    "mainWord": "Helado de vainilla",
    "impostorWord": "Helado de chocolate"
  },
  {
    "id": "c22",
    "category": "comida",
    "mainWord": "Pastel de fresa",
    "impostorWord": "Tarta de queso"
  },
  {
    "id": "c23",
    "category": "comida",
    "mainWord": "Brownie",
    "impostorWord": "Galletas"
  },
  {
    "id": "c24",
    "category": "comida",
    "mainWord": "Flan",
    "impostorWord": "Gelatina"
  },
  {
    "id": "c25",
    "category": "comida",
    "mainWord": "Chocolate caliente",
    "impostorWord": "Café latte"
  },
  {
    "id": "c26",
    "category": "comida",
    "mainWord": "Té verde",
    "impostorWord": "Té negro"
  },
  {
    "id": "c27",
    "category": "comida",
    "mainWord": "Coca Cola",
    "impostorWord": "Pepsi"
  },
  {
    "id": "c28",
    "category": "comida",
    "mainWord": "Limonada",
    "impostorWord": "Naranjada"
  },
  {
    "id": "c29",
    "category": "comida",
    "mainWord": "Batido de fresa",
    "impostorWord": "Smoothie de mango"
  },
  {
    "id": "c30",
    "category": "comida",
    "mainWord": "Cerveza",
    "impostorWord": "Sidra"
  },
  {
    "id": "c31",
    "category": "comida",
    "mainWord": "Vino tinto",
    "impostorWord": "Vino blanco"
  },
  {
    "id": "c32",
    "category": "comida",
    "mainWord": "Mojito",
    "impostorWord": "Margarita"
  },
  {
    "id": "c33",
    "category": "comida",
    "mainWord": "Manzana",
    "impostorWord": "Pera"
  },
  {
    "id": "c34",
    "category": "comida",
    "mainWord": "Plátano",
    "impostorWord": "Mango"
  },
  {
    "id": "c35",
    "category": "comida",
    "mainWord": "Fresa",
    "impostorWord": "Frambuesa"
  },
  {
    "id": "c36",
    "category": "comida",
    "mainWord": "Sandía",
    "impostorWord": "Melón"
  },
  {
    "id": "c37",
    "category": "comida",
    "mainWord": "Uvas",
    "impostorWord": "Cerezas"
  },
  {
    "id": "c38",
    "category": "comida",
    "mainWord": "Piña",
    "impostorWord": "Coco"
  },
  {
    "id": "c39",
    "category": "comida",
    "mainWord": "Naranja",
    "impostorWord": "Mandarina"
  },
  {
    "id": "c40",
    "category": "comida",
    "mainWord": "Aguacate",
    "impostorWord": "Tomate"
  },
  {
    "id": "c41",
    "category": "comida",
    "mainWord": "Zanahoria",
    "impostorWord": "Pepino"
  },
  {
    "id": "c42",
    "category": "comida",
    "mainWord": "Cebolla",
    "impostorWord": "Ajo"
  },
  {
    "id": "c43",
    "category": "comida",
    "mainWord": "Brócoli",
    "impostorWord": "Coliflor"
  },
  {
    "id": "c44",
    "category": "comida",
    "mainWord": "Lechuga",
    "impostorWord": "Espinaca"
  },
  {
    "id": "c45",
    "category": "comida",
    "mainWord": "Queso cheddar",
    "impostorWord": "Queso mozzarella"
  },
  {
    "id": "c46",
    "category": "comida",
    "mainWord": "Yogur griego",
    "impostorWord": "Mantequilla"
  },
  {
    "id": "c47",
    "category": "comida",
    "mainWord": "Huevo frito",
    "impostorWord": "Huevo revuelto"
  },
  {
    "id": "c48",
    "category": "comida",
    "mainWord": "Pescado frito",
    "impostorWord": "Salmón a la plancha"
  },
  {
    "id": "c49",
    "category": "comida",
    "mainWord": "Palomitas de maíz",
    "impostorWord": "Frutos secos"
  },
  {
    "id": "c50",
    "category": "comida",
    "mainWord": "Algodón de azúcar",
    "impostorWord": "Piruleta"
  },
  {
    "id": "c51",
    "category": "comida",
    "mainWord": "Gominolas",
    "impostorWord": "Chicle"
  },
  {
    "id": "c52",
    "category": "comida",
    "mainWord": "Macarrones con queso",
    "impostorWord": "Ñoquis"
  },
  {
    "id": "c53",
    "category": "comida",
    "mainWord": "Kebab",
    "impostorWord": "Shawarma"
  },
  {
    "id": "c54",
    "category": "comida",
    "mainWord": "Dim sum",
    "impostorWord": "Gyozas"
  },
  {
    "id": "c55",
    "category": "comida",
    "mainWord": "Curry con arroz",
    "impostorWord": "Chili con carne"
  },
  {
    "id": "c56",
    "category": "comida",
    "mainWord": "Fondue de queso",
    "impostorWord": "Raclette"
  },
  {
    "id": "c57",
    "category": "comida",
    "mainWord": "Sashimi",
    "impostorWord": "Tartar de atún"
  },
  {
    "id": "c58",
    "category": "comida",
    "mainWord": "Milanesa",
    "impostorWord": "Escalope"
  },
  {
    "id": "c59",
    "category": "comida",
    "mainWord": "Pan de ajo",
    "impostorWord": "Bruschetta"
  },
  {
    "id": "c60",
    "category": "comida",
    "mainWord": "Gazpacho",
    "impostorWord": "Salmorejo"
  },
  {
    "id": "c61",
    "category": "comida",
    "mainWord": "Tiramisú",
    "impostorWord": "Panna cotta"
  },
  {
    "id": "c62",
    "category": "comida",
    "mainWord": "Churrasco",
    "impostorWord": "Bife de chorizo"
  },
  {
    "id": "c63",
    "category": "comida",
    "mainWord": "Poción mágica",
    "impostorWord": "Bebida energética"
  },
  {
    "id": "c64",
    "category": "comida",
    "mainWord": "Café expreso",
    "impostorWord": "Café capuchino"
  },
  {
    "id": "c65",
    "category": "comida",
    "mainWord": "Agua con gas",
    "impostorWord": "Agua mineral"
  },
  {
    "id": "c66",
    "category": "comida",
    "mainWord": "Mostaza",
    "impostorWord": "Kétchup"
  },
  {
    "id": "c67",
    "category": "comida",
    "mainWord": "Mayonesa",
    "impostorWord": "Salsa tártara"
  },
  {
    "id": "c68",
    "category": "comida",
    "mainWord": "Salsa picante",
    "impostorWord": "Wasabi"
  },
  {
    "id": "c69",
    "category": "comida",
    "mainWord": "Aceite de oliva",
    "impostorWord": "Vinagre balsámico"
  },
  {
    "id": "c70",
    "category": "comida",
    "mainWord": "Miel",
    "impostorWord": "Sirope de arce"
  },
  {
    "id": "c71",
    "category": "comida",
    "mainWord": "Mermelada de fresa",
    "impostorWord": "Nutella"
  },
  {
    "id": "c72",
    "category": "comida",
    "mainWord": "Almendra",
    "impostorWord": "Nuez"
  },
  {
    "id": "c73",
    "category": "comida",
    "mainWord": "Cacahuate",
    "impostorWord": "Pistacho"
  },
  {
    "id": "c74",
    "category": "comida",
    "mainWord": "Avena con leche",
    "impostorWord": "Cereales con leche"
  },
  {
    "id": "c75",
    "category": "comida",
    "mainWord": "Sangría",
    "impostorWord": "Tinto de verano"
  },
  {
    "id": "o1",
    "category": "objetos",
    "mainWord": "Teléfono inteligente",
    "impostorWord": "Tablet"
  },
  {
    "id": "o2",
    "category": "objetos",
    "mainWord": "Computadora portátil",
    "impostorWord": "Computadora de escritorio"
  },
  {
    "id": "o3",
    "category": "objetos",
    "mainWord": "Auriculares inalámbricos",
    "impostorWord": "Altavoz bluetooth"
  },
  {
    "id": "o4",
    "category": "objetos",
    "mainWord": "Reloj inteligente",
    "impostorWord": "Pulsera de actividad"
  },
  {
    "id": "o5",
    "category": "objetos",
    "mainWord": "Cámara fotográfica",
    "impostorWord": "Videocámara"
  },
  {
    "id": "o6",
    "category": "objetos",
    "mainWord": "Consola de videojuegos",
    "impostorWord": "Máquina arcade"
  },
  {
    "id": "o7",
    "category": "objetos",
    "mainWord": "Televisor 4K",
    "impostorWord": "Proyector de cine"
  },
  {
    "id": "o8",
    "category": "objetos",
    "mainWord": "Micrófono",
    "impostorWord": "Megáfono"
  },
  {
    "id": "o9",
    "category": "objetos",
    "mainWord": "Teclado mecánico",
    "impostorWord": "Mouse gamer"
  },
  {
    "id": "o10",
    "category": "objetos",
    "mainWord": "Gafas de realidad virtual",
    "impostorWord": "Casco de piloto"
  },
  {
    "id": "o11",
    "category": "objetos",
    "mainWord": "Dron con cámara",
    "impostorWord": "Helicóptero a control remoto"
  },
  {
    "id": "o12",
    "category": "objetos",
    "mainWord": "Batería portátil",
    "impostorWord": "Cargador solar"
  },
  {
    "id": "o13",
    "category": "objetos",
    "mainWord": "Memoria USB",
    "impostorWord": "Disco duro externo"
  },
  {
    "id": "o14",
    "category": "objetos",
    "mainWord": "Impresora 3D",
    "impostorWord": "Escáner láser"
  },
  {
    "id": "o15",
    "category": "objetos",
    "mainWord": "Telescopio",
    "impostorWord": "Microscopio"
  },
  {
    "id": "o16",
    "category": "objetos",
    "mainWord": "Prismáticos",
    "impostorWord": "Catalejo"
  },
  {
    "id": "o17",
    "category": "objetos",
    "mainWord": "Linterna LED",
    "impostorWord": "Antorcha"
  },
  {
    "id": "o18",
    "category": "objetos",
    "mainWord": "Brújula",
    "impostorWord": "GPS"
  },
  {
    "id": "o19",
    "category": "objetos",
    "mainWord": "Guitarra acústica",
    "impostorWord": "Guitarra eléctrica"
  },
  {
    "id": "o20",
    "category": "objetos",
    "mainWord": "Piano de cola",
    "impostorWord": "Teclado sintetizador"
  },
  {
    "id": "o21",
    "category": "objetos",
    "mainWord": "Batería musical",
    "impostorWord": "Bongos"
  },
  {
    "id": "o22",
    "category": "objetos",
    "mainWord": "Violín",
    "impostorWord": "Violonchelo"
  },
  {
    "id": "o23",
    "category": "objetos",
    "mainWord": "Trompeta",
    "impostorWord": "Saxofón"
  },
  {
    "id": "o24",
    "category": "objetos",
    "mainWord": "Flauta traversa",
    "impostorWord": "Clarinete"
  },
  {
    "id": "o25",
    "category": "objetos",
    "mainWord": "Acordeón",
    "impostorWord": "Armónica"
  },
  {
    "id": "o26",
    "category": "objetos",
    "mainWord": "Martillo",
    "impostorWord": "Mazo"
  },
  {
    "id": "o27",
    "category": "objetos",
    "mainWord": "Destornillador",
    "impostorWord": "Llave inglesa"
  },
  {
    "id": "o28",
    "category": "objetos",
    "mainWord": "Taladro eléctrico",
    "impostorWord": "Sierra circular"
  },
  {
    "id": "o29",
    "category": "objetos",
    "mainWord": "Cinta métrica",
    "impostorWord": "Regla de medir"
  },
  {
    "id": "o30",
    "category": "objetos",
    "mainWord": "Alicates",
    "impostorWord": "Tenazas"
  },
  {
    "id": "o31",
    "category": "objetos",
    "mainWord": "Mochila escolar",
    "impostorWord": "Maleta de viaje"
  },
  {
    "id": "o32",
    "category": "objetos",
    "mainWord": "Paraguas",
    "impostorWord": "Impermeable"
  },
  {
    "id": "o33",
    "category": "objetos",
    "mainWord": "Candado",
    "impostorWord": "Cerradura digital"
  },
  {
    "id": "o34",
    "category": "objetos",
    "mainWord": "Llave maestra",
    "impostorWord": "Tarjeta magnética"
  },
  {
    "id": "o35",
    "category": "objetos",
    "mainWord": "Bicicleta de montaña",
    "impostorWord": "Monopatín eléctrico"
  },
  {
    "id": "o36",
    "category": "objetos",
    "mainWord": "Patineta",
    "impostorWord": "Patines en línea"
  },
  {
    "id": "o37",
    "category": "objetos",
    "mainWord": "Casco de moto",
    "impostorWord": "Casco de ciclista"
  },
  {
    "id": "o38",
    "category": "objetos",
    "mainWord": "Lámpara de noche",
    "impostorWord": "Vela aromática"
  },
  {
    "id": "o39",
    "category": "objetos",
    "mainWord": "Espejo de pared",
    "impostorWord": "Cuadro pintado"
  },
  {
    "id": "o40",
    "category": "objetos",
    "mainWord": "Libro de cuentos",
    "impostorWord": "Revista de cómics"
  },
  {
    "id": "o41",
    "category": "objetos",
    "mainWord": "Bolígrafo de tinta",
    "impostorWord": "Lápiz de grafito"
  },
  {
    "id": "o42",
    "category": "objetos",
    "mainWord": "Tijeras",
    "impostorWord": "Cúter"
  },
  {
    "id": "o43",
    "category": "objetos",
    "mainWord": "Grapadora",
    "impostorWord": "Perforadora"
  },
  {
    "id": "o44",
    "category": "objetos",
    "mainWord": "Calculadora científica",
    "impostorWord": "Ábaco"
  },
  {
    "id": "o45",
    "category": "objetos",
    "mainWord": "Termo para café",
    "impostorWord": "Botella de agua"
  },
  {
    "id": "o46",
    "category": "objetos",
    "mainWord": "Cuchillo de cocina",
    "impostorWord": "Tenedor"
  },
  {
    "id": "o47",
    "category": "objetos",
    "mainWord": "Sartén antiadherente",
    "impostorWord": "Olla a presión"
  },
  {
    "id": "o48",
    "category": "objetos",
    "mainWord": "Licuadora",
    "impostorWord": "Batidora de mano"
  },
  {
    "id": "o49",
    "category": "objetos",
    "mainWord": "Microondas",
    "impostorWord": "Horno eléctrico"
  },
  {
    "id": "o50",
    "category": "objetos",
    "mainWord": "Tostadora",
    "impostorWord": "Sandwichera"
  },
  {
    "id": "o51",
    "category": "objetos",
    "mainWord": "Cafetera italiana",
    "impostorWord": "Tetera de porcelana"
  },
  {
    "id": "o52",
    "category": "objetos",
    "mainWord": "Aspiradora robot",
    "impostorWord": "Escoba y recogedor"
  },
  {
    "id": "o53",
    "category": "objetos",
    "mainWord": "Lavadora automática",
    "impostorWord": "Secadora de ropa"
  },
  {
    "id": "o54",
    "category": "objetos",
    "mainWord": "Plancha de ropa",
    "impostorWord": "Vaporizador textil"
  },
  {
    "id": "o55",
    "category": "objetos",
    "mainWord": "Secador de pelo",
    "impostorWord": "Plancha de cabello"
  },
  {
    "id": "o56",
    "category": "objetos",
    "mainWord": "Cepillo de dientes eléctrico",
    "impostorWord": "Hilo dental"
  },
  {
    "id": "o57",
    "category": "objetos",
    "mainWord": "Báscula de baño",
    "impostorWord": "Termómetro digital"
  },
  {
    "id": "o58",
    "category": "objetos",
    "mainWord": "Extintor de fuego",
    "impostorWord": "Manguera de agua"
  },
  {
    "id": "o59",
    "category": "objetos",
    "mainWord": "Semáforo de calle",
    "impostorWord": "Señal de tráfico"
  },
  {
    "id": "o60",
    "category": "objetos",
    "mainWord": "Caja fuerte blindada",
    "impostorWord": "Alcancía de cerdito"
  },
  {
    "id": "o61",
    "category": "objetos",
    "mainWord": "Globo terráqueo",
    "impostorWord": "Mapa mundi"
  },
  {
    "id": "o62",
    "category": "objetos",
    "mainWord": "Moneda de oro",
    "impostorWord": "Billete de cien"
  },
  {
    "id": "o63",
    "category": "objetos",
    "mainWord": "Gafas de sol",
    "impostorWord": "Gafas de buceo"
  },
  {
    "id": "o64",
    "category": "objetos",
    "mainWord": "Sombrero de copa",
    "impostorWord": "Gorra deportiva"
  },
  {
    "id": "o65",
    "category": "objetos",
    "mainWord": "Bufanda de lana",
    "impostorWord": "Guantes de nieve"
  },
  {
    "id": "o66",
    "category": "objetos",
    "mainWord": "Zapatos de tacón",
    "impostorWord": "Zapatillas deportivas"
  },
  {
    "id": "o67",
    "category": "objetos",
    "mainWord": "Botas de lluvia",
    "impostorWord": "Sandalias de playa"
  },
  {
    "id": "o68",
    "category": "objetos",
    "mainWord": "Cinturón de cuero",
    "impostorWord": "Tirantes elásticos"
  },
  {
    "id": "o69",
    "category": "objetos",
    "mainWord": "Anillo de diamantes",
    "impostorWord": "Collar de perlas"
  },
  {
    "id": "o70",
    "category": "objetos",
    "mainWord": "Pendientes de plata",
    "impostorWord": "Pulsera de oro"
  },
  {
    "id": "o71",
    "category": "objetos",
    "mainWord": "Billetera de cuero",
    "impostorWord": "Monedero con cremallera"
  },
  {
    "id": "o72",
    "category": "objetos",
    "mainWord": "Pasaporte internacional",
    "impostorWord": "Documento de identidad"
  },
  {
    "id": "o73",
    "category": "objetos",
    "mainWord": "Escudo medieval",
    "impostorWord": "Espada láser"
  },
  {
    "id": "o74",
    "category": "objetos",
    "mainWord": "Arco y flecha",
    "impostorWord": "Ballesta"
  },
  {
    "id": "o75",
    "category": "objetos",
    "mainWord": "Varita mágica",
    "impostorWord": "Bola de cristal"
  },
  {
    "id": "l1",
    "category": "lugares",
    "mainWord": "Aeropuerto",
    "impostorWord": "Estación de tren"
  },
  {
    "id": "l2",
    "category": "lugares",
    "mainWord": "Hospital",
    "impostorWord": "Farmacia"
  },
  {
    "id": "l3",
    "category": "lugares",
    "mainWord": "Biblioteca",
    "impostorWord": "Librería"
  },
  {
    "id": "l4",
    "category": "lugares",
    "mainWord": "Cine",
    "impostorWord": "Teatro"
  },
  {
    "id": "l5",
    "category": "lugares",
    "mainWord": "Supermercado",
    "impostorWord": "Mercado callejero"
  },
  {
    "id": "l6",
    "category": "lugares",
    "mainWord": "Gimnasio",
    "impostorWord": "Piscina olímpica"
  },
  {
    "id": "l7",
    "category": "lugares",
    "mainWord": "Restaurante de lujo",
    "impostorWord": "Cafetería acogedora"
  },
  {
    "id": "l8",
    "category": "lugares",
    "mainWord": "Parque de atracciones",
    "impostorWord": "Zoológico"
  },
  {
    "id": "l9",
    "category": "lugares",
    "mainWord": "Museo de arte",
    "impostorWord": "Galería de fotos"
  },
  {
    "id": "l10",
    "category": "lugares",
    "mainWord": "Hotel cinco estrellas",
    "impostorWord": "Hostal de mochileros"
  },
  {
    "id": "l11",
    "category": "lugares",
    "mainWord": "Estadio de fútbol",
    "impostorWord": "Coliseo romano"
  },
  {
    "id": "l12",
    "category": "lugares",
    "mainWord": "Castillo medieval",
    "impostorWord": "Palacio real"
  },
  {
    "id": "l13",
    "category": "lugares",
    "mainWord": "Catedral gótica",
    "impostorWord": "Mezquita"
  },
  {
    "id": "l14",
    "category": "lugares",
    "mainWord": "Faro marítimo",
    "impostorWord": "Muelle de pescadores"
  },
  {
    "id": "l15",
    "category": "lugares",
    "mainWord": "Playa tropical",
    "impostorWord": "Isla desierta"
  },
  {
    "id": "l16",
    "category": "lugares",
    "mainWord": "Selva amazónica",
    "impostorWord": "Bosque de pinos"
  },
  {
    "id": "l17",
    "category": "lugares",
    "mainWord": "Desierto de dunas",
    "impostorWord": "Oasis con palmeras"
  },
  {
    "id": "l18",
    "category": "lugares",
    "mainWord": "Montaña nevada",
    "impostorWord": "Glaciar gigante"
  },
  {
    "id": "l19",
    "category": "lugares",
    "mainWord": "Volcán activo",
    "impostorWord": "Cueva subterránea"
  },
  {
    "id": "l20",
    "category": "lugares",
    "mainWord": "Cascada de agua",
    "impostorWord": "Lago cristalino"
  },
  {
    "id": "l21",
    "category": "lugares",
    "mainWord": "Estación espacial",
    "impostorWord": "Submarino militar"
  },
  {
    "id": "l22",
    "category": "lugares",
    "mainWord": "Laboratorio secreto",
    "impostorWord": "Búnker nuclear"
  },
  {
    "id": "l23",
    "category": "lugares",
    "mainWord": "Prisión de máxima seguridad",
    "impostorWord": "Comisaría de policía"
  },
  {
    "id": "l24",
    "category": "lugares",
    "mainWord": "Banco central",
    "impostorWord": "Casino de juegos"
  },
  {
    "id": "l25",
    "category": "lugares",
    "mainWord": "Pista de esquí",
    "impostorWord": "Pista de patinaje sobre hielo"
  },
  {
    "id": "l26",
    "category": "lugares",
    "mainWord": "Plaza principal",
    "impostorWord": "Avenida transitada"
  },
  {
    "id": "l27",
    "category": "lugares",
    "mainWord": "Cementerio nocturno",
    "impostorWord": "Casa embrujada"
  },
  {
    "id": "l28",
    "category": "lugares",
    "mainWord": "Granja con animales",
    "impostorWord": "Invernadero botánico"
  },
  {
    "id": "l29",
    "category": "lugares",
    "mainWord": "Gasolinera",
    "impostorWord": "Taller mecánico"
  },
  {
    "id": "l30",
    "category": "lugares",
    "mainWord": "Discoteca de moda",
    "impostorWord": "Bar de copas"
  },
  {
    "id": "l31",
    "category": "lugares",
    "mainWord": "Centro comercial",
    "impostorWord": "Tienda de antigüedades"
  },
  {
    "id": "l32",
    "category": "lugares",
    "mainWord": "Universidad",
    "impostorWord": "Colegio primario"
  },
  {
    "id": "l33",
    "category": "lugares",
    "mainWord": "Guardería infantil",
    "impostorWord": "Campamento de verano"
  },
  {
    "id": "l34",
    "category": "lugares",
    "mainWord": "Templo budista",
    "impostorWord": "Pirámide maya"
  },
  {
    "id": "l35",
    "category": "lugares",
    "mainWord": "Torre Eiffel",
    "impostorWord": "Estatua de la Libertad"
  },
  {
    "id": "l36",
    "category": "lugares",
    "mainWord": "Gran Muralla China",
    "impostorWord": "Machu Picchu"
  },
  {
    "id": "l37",
    "category": "lugares",
    "mainWord": "Canal de Venecia",
    "impostorWord": "Parque acuático"
  },
  {
    "id": "l38",
    "category": "lugares",
    "mainWord": "Balneario termal",
    "impostorWord": "Sauna finlandés"
  },
  {
    "id": "l39",
    "category": "lugares",
    "mainWord": "Parada de autobús",
    "impostorWord": "Estación de metro"
  },
  {
    "id": "l40",
    "category": "lugares",
    "mainWord": "Puerto marítimo",
    "impostorWord": "Barco crucero"
  },
  {
    "id": "l41",
    "category": "lugares",
    "mainWord": "Barco pirata",
    "impostorWord": "Isla del tesoro"
  },
  {
    "id": "l42",
    "category": "lugares",
    "mainWord": "Helipuerto",
    "impostorWord": "Torre de control aéreo"
  },
  {
    "id": "l43",
    "category": "lugares",
    "mainWord": "Oficina corporativa",
    "impostorWord": "Sala de juntas"
  },
  {
    "id": "l44",
    "category": "lugares",
    "mainWord": "Estudio de grabación",
    "impostorWord": "Canal de televisión"
  },
  {
    "id": "l45",
    "category": "lugares",
    "mainWord": "Peluquería",
    "impostorWord": "Salón de belleza"
  },
  {
    "id": "l46",
    "category": "lugares",
    "mainWord": "Floristería",
    "impostorWord": "Huerto orgánico"
  },
  {
    "id": "l47",
    "category": "lugares",
    "mainWord": "Panadería artesanal",
    "impostorWord": "Pastelería francesa"
  },
  {
    "id": "l48",
    "category": "lugares",
    "mainWord": "Carnicería",
    "impostorWord": "Pescadería"
  },
  {
    "id": "l49",
    "category": "lugares",
    "mainWord": "Zapatería",
    "impostorWord": "Tienda de ropa"
  },
  {
    "id": "l50",
    "category": "lugares",
    "mainWord": "Lavacoches automático",
    "impostorWord": "Aparcamiento subterráneo"
  },
  {
    "id": "l51",
    "category": "lugares",
    "mainWord": "Circo ambulante",
    "impostorWord": "Feria patronal"
  },
  {
    "id": "l52",
    "category": "lugares",
    "mainWord": "Bolera americana",
    "impostorWord": "Salón de billar"
  },
  {
    "id": "l53",
    "category": "lugares",
    "mainWord": "Campo de golf",
    "impostorWord": "Cancha de tenis"
  },
  {
    "id": "l54",
    "category": "lugares",
    "mainWord": "Pista de carreras de F1",
    "impostorWord": "Kartódromo"
  },
  {
    "id": "l55",
    "category": "lugares",
    "mainWord": "Trinchera de guerra",
    "impostorWord": "Base militar"
  },
  {
    "id": "l56",
    "category": "lugares",
    "mainWord": "Trono real",
    "impostorWord": "Cámara acorazada"
  },
  {
    "id": "l57",
    "category": "lugares",
    "mainWord": "Cañón del Colorado",
    "impostorWord": "Valle verde"
  },
  {
    "id": "l58",
    "category": "lugares",
    "mainWord": "Arrecife de coral",
    "impostorWord": "Fosa marina profunda"
  },
  {
    "id": "l59",
    "category": "lugares",
    "mainWord": "Sabana africana",
    "impostorWord": "Tundra ártica"
  },
  {
    "id": "l60",
    "category": "lugares",
    "mainWord": "Iglú polar",
    "impostorWord": "Cabaña de madera"
  },
  {
    "id": "l61",
    "category": "lugares",
    "mainWord": "Rascacielos",
    "impostorWord": "Mirador panorámico"
  },
  {
    "id": "l62",
    "category": "lugares",
    "mainWord": "Planeta Marte",
    "impostorWord": "La Luna"
  },
  {
    "id": "l63",
    "category": "lugares",
    "mainWord": "Agujero negro",
    "impostorWord": "Galaxia espiral"
  },
  {
    "id": "l64",
    "category": "lugares",
    "mainWord": "Casa del árbol",
    "impostorWord": "Tienda de campaña"
  },
  {
    "id": "l65",
    "category": "lugares",
    "mainWord": "Molino de viento",
    "impostorWord": "Fábrica industrial"
  },
  {
    "id": "l66",
    "category": "lugares",
    "mainWord": "Puente colgante",
    "impostorWord": "Túnel bajo el agua"
  },
  {
    "id": "l67",
    "category": "lugares",
    "mainWord": "Tejado de tejas",
    "impostorWord": "Terraza con piscina"
  },
  {
    "id": "l68",
    "category": "lugares",
    "mainWord": "Sótano oscuro",
    "impostorWord": "Ático polvoriento"
  },
  {
    "id": "l69",
    "category": "lugares",
    "mainWord": "Cocina de chef",
    "impostorWord": "Comedor escolar"
  },
  {
    "id": "l70",
    "category": "lugares",
    "mainWord": "Dormitorio infantil",
    "impostorWord": "Sala de estar"
  },
  {
    "id": "l71",
    "category": "lugares",
    "mainWord": "Garaje con herramientas",
    "impostorWord": "Trastero desordenado"
  },
  {
    "id": "l72",
    "category": "lugares",
    "mainWord": "Balcón floreado",
    "impostorWord": "Patio interior"
  },
  {
    "id": "l73",
    "category": "lugares",
    "mainWord": "Ascensor de cristal",
    "impostorWord": "Escaleras mecánicas"
  },
  {
    "id": "l74",
    "category": "lugares",
    "mainWord": "Pasillo de hotel",
    "impostorWord": "Recepción"
  },
  {
    "id": "l75",
    "category": "lugares",
    "mainWord": "Planetario",
    "impostorWord": "Observatorio astronómico"
  },
  {
    "id": "p1",
    "category": "profesiones",
    "mainWord": "Médico cirujano",
    "impostorWord": "Enfermero de urgencias"
  },
  {
    "id": "p2",
    "category": "profesiones",
    "mainWord": "Bombero voluntario",
    "impostorWord": "Paramédico"
  },
  {
    "id": "p3",
    "category": "profesiones",
    "mainWord": "Policía detective",
    "impostorWord": "Agente secreto"
  },
  {
    "id": "p4",
    "category": "profesiones",
    "mainWord": "Astronauta de la NASA",
    "impostorWord": "Piloto de avión"
  },
  {
    "id": "p5",
    "category": "profesiones",
    "mainWord": "Chef de cocina",
    "impostorWord": "Panadero pastelero"
  },
  {
    "id": "p6",
    "category": "profesiones",
    "mainWord": "Profesor de escuela",
    "impostorWord": "Director de colegio"
  },
  {
    "id": "p7",
    "category": "profesiones",
    "mainWord": "Abogado defensor",
    "impostorWord": "Juez de tribunal"
  },
  {
    "id": "p8",
    "category": "profesiones",
    "mainWord": "Arquitecto de edificios",
    "impostorWord": "Ingeniero civil"
  },
  {
    "id": "p9",
    "category": "profesiones",
    "mainWord": "Programador de software",
    "impostorWord": "Hacker informático"
  },
  {
    "id": "p10",
    "category": "profesiones",
    "mainWord": "Científico de laboratorio",
    "impostorWord": "Profesor universitario"
  },
  {
    "id": "p11",
    "category": "profesiones",
    "mainWord": "Actor de cine",
    "impostorWord": "Director de teatro"
  },
  {
    "id": "p12",
    "category": "profesiones",
    "mainWord": "Cantante de rock",
    "impostorWord": "Músico de orquesta"
  },
  {
    "id": "p13",
    "category": "profesiones",
    "mainWord": "Pintor de cuadros",
    "impostorWord": "Escultor en mármol"
  },
  {
    "id": "p14",
    "category": "profesiones",
    "mainWord": "Fotógrafo profesional",
    "impostorWord": "Camarógrafo de TV"
  },
  {
    "id": "p15",
    "category": "profesiones",
    "mainWord": "Veterinario",
    "impostorWord": "Biólogo marino"
  },
  {
    "id": "p16",
    "category": "profesiones",
    "mainWord": "Dentista",
    "impostorWord": "Ortodoncista"
  },
  {
    "id": "p17",
    "category": "profesiones",
    "mainWord": "Psicólogo",
    "impostorWord": "Psiquiatra"
  },
  {
    "id": "p18",
    "category": "profesiones",
    "mainWord": "Peluquero estilista",
    "impostorWord": "Maquillador artístico"
  },
  {
    "id": "p19",
    "category": "profesiones",
    "mainWord": "Mecánico de coches",
    "impostorWord": "Electricista"
  },
  {
    "id": "p20",
    "category": "profesiones",
    "mainWord": "Fontanero",
    "impostorWord": "Albañil constructor"
  },
  {
    "id": "p21",
    "category": "profesiones",
    "mainWord": "Carpintero",
    "impostorWord": "Ebanista"
  },
  {
    "id": "p22",
    "category": "profesiones",
    "mainWord": "Jardinero",
    "impostorWord": "Agricultor"
  },
  {
    "id": "p23",
    "category": "profesiones",
    "mainWord": "Pescador de alta mar",
    "impostorWord": "Marinero mercante"
  },
  {
    "id": "p24",
    "category": "profesiones",
    "mainWord": "Capitán de barco",
    "impostorWord": "Guía turístico"
  },
  {
    "id": "p25",
    "category": "profesiones",
    "mainWord": "Azafata de vuelo",
    "impostorWord": "Recepcionista de hotel"
  },
  {
    "id": "p26",
    "category": "profesiones",
    "mainWord": "Camarero de restaurante",
    "impostorWord": "Barman experto"
  },
  {
    "id": "p27",
    "category": "profesiones",
    "mainWord": "Entrenador de fútbol",
    "impostorWord": "Árbitro de partido"
  },
  {
    "id": "p28",
    "category": "profesiones",
    "mainWord": "Jugador de baloncesto",
    "impostorWord": "Atleta olímpico"
  },
  {
    "id": "p29",
    "category": "profesiones",
    "mainWord": "Boxeador profesional",
    "impostorWord": "Luchador de karate"
  },
  {
    "id": "p30",
    "category": "profesiones",
    "mainWord": "Bailarín de ballet",
    "impostorWord": "Gimnasta rítmico"
  },
  {
    "id": "p31",
    "category": "profesiones",
    "mainWord": "Mago ilusionista",
    "impostorWord": "Payaso de circo"
  },
  {
    "id": "p32",
    "category": "profesiones",
    "mainWord": "Acróbata de trapecio",
    "impostorWord": "Malabarista de fuego"
  },
  {
    "id": "p33",
    "category": "profesiones",
    "mainWord": "Pirata de los mares",
    "impostorWord": "Corsario"
  },
  {
    "id": "p34",
    "category": "profesiones",
    "mainWord": "Caballero con armadura",
    "impostorWord": "Guerrero samurái"
  },
  {
    "id": "p35",
    "category": "profesiones",
    "mainWord": "Vikingo nórdico",
    "impostorWord": "Gladiador romano"
  },
  {
    "id": "p36",
    "category": "profesiones",
    "mainWord": "Rey soberano",
    "impostorWord": "Emperador"
  },
  {
    "id": "p37",
    "category": "profesiones",
    "mainWord": "Princesa heredera",
    "impostorWord": "Reina consorte"
  },
  {
    "id": "p38",
    "category": "profesiones",
    "mainWord": "Superhéroe con capa",
    "impostorWord": "Villano enmascarado"
  },
  {
    "id": "p39",
    "category": "profesiones",
    "mainWord": "Espía encubierto",
    "impostorWord": "Guardaespaldas"
  },
  {
    "id": "p40",
    "category": "profesiones",
    "mainWord": "Arqueólogo de tumbas",
    "impostorWord": "Historiador"
  },
  {
    "id": "p41",
    "category": "profesiones",
    "mainWord": "Astrónomo observador",
    "impostorWord": "Meteorólogo del clima"
  },
  {
    "id": "p42",
    "category": "profesiones",
    "mainWord": "Periodista de noticias",
    "impostorWord": "Presentador de televisión"
  },
  {
    "id": "p43",
    "category": "profesiones",
    "mainWord": "Escritor de novelas",
    "impostorWord": "Poeta lírico"
  },
  {
    "id": "p44",
    "category": "profesiones",
    "mainWord": "Traductor políglota",
    "impostorWord": "Diplomático de embajada"
  },
  {
    "id": "p45",
    "category": "profesiones",
    "mainWord": "Cartero de barrio",
    "impostorWord": "Repartidor de paquetes"
  },
  {
    "id": "p46",
    "category": "profesiones",
    "mainWord": "Taxista nocturno",
    "impostorWord": "Conductor de autobús"
  },
  {
    "id": "p47",
    "category": "profesiones",
    "mainWord": "Maquinista de tren",
    "impostorWord": "Conductor de metro"
  },
  {
    "id": "p48",
    "category": "profesiones",
    "mainWord": "Guardián del faro",
    "impostorWord": "Guardabosques"
  },
  {
    "id": "p49",
    "category": "profesiones",
    "mainWord": "Buceador de rescate",
    "impostorWord": "Socorrista de playa"
  },
  {
    "id": "p50",
    "category": "profesiones",
    "mainWord": "Minero de carbón",
    "impostorWord": "Espeleólogo de cuevas"
  },
  {
    "id": "p51",
    "category": "profesiones",
    "mainWord": "Joyero artesano",
    "impostorWord": "Relojero de precisión"
  },
  {
    "id": "p52",
    "category": "profesiones",
    "mainWord": "Sastre de trajes",
    "impostorWord": "Diseñador de modas"
  },
  {
    "id": "p53",
    "category": "profesiones",
    "mainWord": "Zapatero remendón",
    "impostorWord": "Curtidor de pieles"
  },
  {
    "id": "p54",
    "category": "profesiones",
    "mainWord": "Cerrajero de emergencia",
    "impostorWord": "Instalador de alarmas"
  },
  {
    "id": "p55",
    "category": "profesiones",
    "mainWord": "Soldador industrial",
    "impostorWord": "Herrero de forja"
  },
  {
    "id": "p56",
    "category": "profesiones",
    "mainWord": "DJ de discoteca",
    "impostorWord": "Locutor de radio"
  },
  {
    "id": "p57",
    "category": "profesiones",
    "mainWord": "Diseñador gráfico",
    "impostorWord": "Ilustrador digital"
  },
  {
    "id": "p58",
    "category": "profesiones",
    "mainWord": "Streamer de videojuegos",
    "impostorWord": "YouTuber creador"
  },
  {
    "id": "p59",
    "category": "profesiones",
    "mainWord": "Influencer de redes",
    "impostorWord": "Modelo de pasarela"
  },
  {
    "id": "p60",
    "category": "profesiones",
    "mainWord": "Sommelier de vinos",
    "impostorWord": "Catador de café"
  },
  {
    "id": "p61",
    "category": "profesiones",
    "mainWord": "Ninja en las sombras",
    "impostorWord": "Asesino silencioso"
  },
  {
    "id": "p62",
    "category": "profesiones",
    "mainWord": "Vampiro milenario",
    "impostorWord": "Hombre lobo"
  },
  {
    "id": "p63",
    "category": "profesiones",
    "mainWord": "Bruja con caldero",
    "impostorWord": "Hechicero arcano"
  },
  {
    "id": "p64",
    "category": "profesiones",
    "mainWord": "Fantasma de castillo",
    "impostorWord": "Zombi errante"
  },
  {
    "id": "p65",
    "category": "profesiones",
    "mainWord": "Alien espacial",
    "impostorWord": "Robot cibernético"
  },
  {
    "id": "p66",
    "category": "profesiones",
    "mainWord": "Sirena del océano",
    "impostorWord": "Hada del bosque"
  },
  {
    "id": "p67",
    "category": "profesiones",
    "mainWord": "Duende con oro",
    "impostorWord": "Elfo mágico"
  },
  {
    "id": "p68",
    "category": "profesiones",
    "mainWord": "Gigante de montañas",
    "impostorWord": "Trol de puente"
  },
  {
    "id": "p69",
    "category": "profesiones",
    "mainWord": "Dragón de fuego",
    "impostorWord": "Fénix renacido"
  },
  {
    "id": "p70",
    "category": "profesiones",
    "mainWord": "Unicornio alado",
    "impostorWord": "Pegaso"
  },
  {
    "id": "p71",
    "category": "profesiones",
    "mainWord": "Croupier de casino",
    "impostorWord": "Banquero financiero"
  },
  {
    "id": "p72",
    "category": "profesiones",
    "mainWord": "Bibliotecario",
    "impostorWord": "Archivero histórico"
  },
  {
    "id": "p73",
    "category": "profesiones",
    "mainWord": "Guardián del museo",
    "impostorWord": "Vigilante nocturno"
  },
  {
    "id": "p74",
    "category": "profesiones",
    "mainWord": "Cazador furtivo",
    "impostorWord": "Explorador de safaris"
  },
  {
    "id": "p75",
    "category": "profesiones",
    "mainWord": "Doble de acción de riesgo",
    "impostorWord": "Especialista en acrobacias"
  },
  {
    "id": "d1",
    "category": "deportes",
    "mainWord": "Fútbol",
    "impostorWord": "Fútbol americano"
  },
  {
    "id": "d2",
    "category": "deportes",
    "mainWord": "Baloncesto",
    "impostorWord": "Voleibol"
  },
  {
    "id": "d3",
    "category": "deportes",
    "mainWord": "Tenis de pista",
    "impostorWord": "Pádel"
  },
  {
    "id": "d4",
    "category": "deportes",
    "mainWord": "Ping pong",
    "impostorWord": "Bádminton"
  },
  {
    "id": "d5",
    "category": "deportes",
    "mainWord": "Béisbol",
    "impostorWord": "Críquet"
  },
  {
    "id": "d6",
    "category": "deportes",
    "mainWord": "Golf",
    "impostorWord": "Minigolf"
  },
  {
    "id": "d7",
    "category": "deportes",
    "mainWord": "Rugby",
    "impostorWord": "Hockey sobre césped"
  },
  {
    "id": "d8",
    "category": "deportes",
    "mainWord": "Hockey sobre hielo",
    "impostorWord": "Patinaje artístico"
  },
  {
    "id": "d9",
    "category": "deportes",
    "mainWord": "Natación estilo libre",
    "impostorWord": "Waterpolo"
  },
  {
    "id": "d10",
    "category": "deportes",
    "mainWord": "Surf de olas",
    "impostorWord": "Windsurf"
  },
  {
    "id": "d11",
    "category": "deportes",
    "mainWord": "Esquí alpino",
    "impostorWord": "Snowboard"
  },
  {
    "id": "d12",
    "category": "deportes",
    "mainWord": "Boxeo de ring",
    "impostorWord": "Kickboxing"
  },
  {
    "id": "d13",
    "category": "deportes",
    "mainWord": "Judo",
    "impostorWord": "Karate"
  },
  {
    "id": "d14",
    "category": "deportes",
    "mainWord": "Taekwondo",
    "impostorWord": "Kung fu"
  },
  {
    "id": "d15",
    "category": "deportes",
    "mainWord": "Ciclismo de ruta",
    "impostorWord": "Motociclismo"
  },
  {
    "id": "d16",
    "category": "deportes",
    "mainWord": "Fórmula 1",
    "impostorWord": "Rally de coches"
  },
  {
    "id": "d17",
    "category": "deportes",
    "mainWord": "Maratón de 42km",
    "impostorWord": "Triatlón"
  },
  {
    "id": "d18",
    "category": "deportes",
    "mainWord": "Salto en paracaídas",
    "impostorWord": "Parapente"
  },
  {
    "id": "d19",
    "category": "deportes",
    "mainWord": "Escalada en roca",
    "impostorWord": "Alpinismo"
  },
  {
    "id": "d20",
    "category": "deportes",
    "mainWord": "Tiro con arco",
    "impostorWord": "Tiro al plato"
  },
  {
    "id": "d21",
    "category": "deportes",
    "mainWord": "Ajedrez clásico",
    "impostorWord": "Damas chinas"
  },
  {
    "id": "d22",
    "category": "deportes",
    "mainWord": "Monopoly",
    "impostorWord": "Catan"
  },
  {
    "id": "d23",
    "category": "deportes",
    "mainWord": "Scrabble de palabras",
    "impostorWord": "Crucigrama"
  },
  {
    "id": "d24",
    "category": "deportes",
    "mainWord": "Dominó de fichas",
    "impostorWord": "Jenga de madera"
  },
  {
    "id": "d25",
    "category": "deportes",
    "mainWord": "Póker de cartas",
    "impostorWord": "Blackjack"
  },
  {
    "id": "d26",
    "category": "deportes",
    "mainWord": "Ruleta de casino",
    "impostorWord": "Bingo de números"
  },
  {
    "id": "d27",
    "category": "deportes",
    "mainWord": "Billar americano",
    "impostorWord": "Dardos de diana"
  },
  {
    "id": "d28",
    "category": "deportes",
    "mainWord": "Bolos",
    "impostorWord": "Petanca"
  },
  {
    "id": "d29",
    "category": "deportes",
    "mainWord": "Puzzles y rompecabezas",
    "impostorWord": "Cubo de Rubik"
  },
  {
    "id": "d30",
    "category": "deportes",
    "mainWord": "Juego de las sillas",
    "impostorWord": "Escondite secreto"
  },
  {
    "id": "d31",
    "category": "deportes",
    "mainWord": "Pilla-pilla",
    "impostorWord": "Policías y ladrones"
  },
  {
    "id": "d32",
    "category": "deportes",
    "mainWord": "Rayuela",
    "impostorWord": "Saltar a la comba"
  },
  {
    "id": "d33",
    "category": "deportes",
    "mainWord": "Pádel surf",
    "impostorWord": "Kayak de río"
  },
  {
    "id": "d34",
    "category": "deportes",
    "mainWord": "Rafting en rápidos",
    "impostorWord": "Piragüismo"
  },
  {
    "id": "d35",
    "category": "deportes",
    "mainWord": "Puenting de adrenalina",
    "impostorWord": "Tirolesa gigante"
  },
  {
    "id": "d36",
    "category": "deportes",
    "mainWord": "Halterofilia de pesas",
    "impostorWord": "Crossfit de alta intensidad"
  },
  {
    "id": "d37",
    "category": "deportes",
    "mainWord": "Yoga relajante",
    "impostorWord": "Pilates"
  },
  {
    "id": "d38",
    "category": "deportes",
    "mainWord": "Gimnasia artística",
    "impostorWord": "Acrobacias aéreas"
  },
  {
    "id": "d39",
    "category": "deportes",
    "mainWord": "Carrera de vallas",
    "impostorWord": "Salto de longitud"
  },
  {
    "id": "d40",
    "category": "deportes",
    "mainWord": "Lanzamiento de jabalina",
    "impostorWord": "Lanzamiento de disco"
  },
  {
    "id": "d41",
    "category": "deportes",
    "mainWord": "Lucha libre en ring",
    "impostorWord": "Sumo tradicional"
  },
  {
    "id": "d42",
    "category": "deportes",
    "mainWord": "Esgrima con espada",
    "impostorWord": "Kendo japonés"
  },
  {
    "id": "d43",
    "category": "deportes",
    "mainWord": "Polo a caballo",
    "impostorWord": "Equitación de saltos"
  },
  {
    "id": "d44",
    "category": "deportes",
    "mainWord": "Trekking en senderos",
    "impostorWord": "Senderismo de montaña"
  },
  {
    "id": "d45",
    "category": "deportes",
    "mainWord": "Patinaje sobre ruedas",
    "impostorWord": "Skateboarding urbano"
  },
  {
    "id": "d46",
    "category": "deportes",
    "mainWord": "Paintball táctico",
    "impostorWord": "Laser tag con chaleco"
  },
  {
    "id": "d47",
    "category": "deportes",
    "mainWord": "Escape room misterioso",
    "impostorWord": "Laberinto de setos"
  },
  {
    "id": "d48",
    "category": "deportes",
    "mainWord": "Mario Kart",
    "impostorWord": "Sonic Racing"
  },
  {
    "id": "d49",
    "category": "deportes",
    "mainWord": "Minecraft",
    "impostorWord": "Roblox"
  },
  {
    "id": "d50",
    "category": "deportes",
    "mainWord": "Fortnite",
    "impostorWord": "PUBG"
  },
  {
    "id": "d51",
    "category": "deportes",
    "mainWord": "Among Us",
    "impostorWord": "Town of Salem"
  },
  {
    "id": "d52",
    "category": "deportes",
    "mainWord": "Tetris de bloques",
    "impostorWord": "Candy Crush"
  },
  {
    "id": "d53",
    "category": "deportes",
    "mainWord": "Pac-Man clásico",
    "impostorWord": "Space Invaders"
  },
  {
    "id": "d54",
    "category": "deportes",
    "mainWord": "Zelda de aventuras",
    "impostorWord": "Genshin Impact"
  },
  {
    "id": "d55",
    "category": "deportes",
    "mainWord": "Pokémon combate",
    "impostorWord": "Digimon"
  },
  {
    "id": "d56",
    "category": "deportes",
    "mainWord": "Pictionary de dibujos",
    "impostorWord": "Mímica de gestos"
  },
  {
    "id": "d57",
    "category": "deportes",
    "mainWord": "Trivial Pursuit",
    "impostorWord": "Pasapalabra"
  },
  {
    "id": "d58",
    "category": "deportes",
    "mainWord": "Uno de cartas",
    "impostorWord": "Chinchón"
  },
  {
    "id": "d59",
    "category": "deportes",
    "mainWord": "Risk de conquista",
    "impostorWord": "Estrategia naval"
  },
  {
    "id": "d60",
    "category": "deportes",
    "mainWord": "Cluedo del asesinato",
    "impostorWord": "Hombre Lobo de Castronegro"
  },
  {
    "id": "n1",
    "category": "naturaleza",
    "mainWord": "Arcoíris doble",
    "impostorWord": "Aurora boreal"
  },
  {
    "id": "n2",
    "category": "naturaleza",
    "mainWord": "Rayo tormentoso",
    "impostorWord": "Trueno ensordecedor"
  },
  {
    "id": "n3",
    "category": "naturaleza",
    "mainWord": "Tornado destructor",
    "impostorWord": "Huracán marino"
  },
  {
    "id": "n4",
    "category": "naturaleza",
    "mainWord": "Tsunami gigante",
    "impostorWord": "Terremoto tectónico"
  },
  {
    "id": "n5",
    "category": "naturaleza",
    "mainWord": "Eclipse de sol",
    "impostorWord": "Luna llena"
  },
  {
    "id": "n6",
    "category": "naturaleza",
    "mainWord": "Estrella fugaz",
    "impostorWord": "Cometa con cola"
  },
  {
    "id": "n7",
    "category": "naturaleza",
    "mainWord": "Nevada de invierno",
    "impostorWord": "Granizo helado"
  },
  {
    "id": "n8",
    "category": "naturaleza",
    "mainWord": "Niebla espesa",
    "impostorWord": "Rocío matutino"
  },
  {
    "id": "n9",
    "category": "naturaleza",
    "mainWord": "Ola de calor",
    "impostorWord": "Sequía extrema"
  },
  {
    "id": "n10",
    "category": "naturaleza",
    "mainWord": "Atardecer rojo",
    "impostorWord": "Amanecer dorado"
  },
  {
    "id": "n11",
    "category": "naturaleza",
    "mainWord": "Volcán en erupción",
    "impostorWord": "Géiser de vapor"
  },
  {
    "id": "n12",
    "category": "naturaleza",
    "mainWord": "Cataratas de Iguazú",
    "impostorWord": "Río caudaloso"
  },
  {
    "id": "n13",
    "category": "naturaleza",
    "mainWord": "Bosque tropical",
    "impostorWord": "Manglar pantanoso"
  },
  {
    "id": "n14",
    "category": "naturaleza",
    "mainWord": "Rosa roja",
    "impostorWord": "Tulipán holandés"
  },
  {
    "id": "n15",
    "category": "naturaleza",
    "mainWord": "Girasol brillante",
    "impostorWord": "Margarita blanca"
  },
  {
    "id": "n16",
    "category": "naturaleza",
    "mainWord": "Orquídea exótica",
    "impostorWord": "Flor de loto"
  },
  {
    "id": "n17",
    "category": "naturaleza",
    "mainWord": "Cactus del desierto",
    "impostorWord": "Bonsái japonés"
  },
  {
    "id": "n18",
    "category": "naturaleza",
    "mainWord": "Roble centenario",
    "impostorWord": "Secuoya gigante"
  },
  {
    "id": "n19",
    "category": "naturaleza",
    "mainWord": "Palmera de playa",
    "impostorWord": "Bambú verde"
  },
  {
    "id": "n20",
    "category": "naturaleza",
    "mainWord": "Hongo venenoso",
    "impostorWord": "Champiñón silvestre"
  },
  {
    "id": "n21",
    "category": "naturaleza",
    "mainWord": "Diamante puro",
    "impostorWord": "Esmeralda brillante"
  },
  {
    "id": "n22",
    "category": "naturaleza",
    "mainWord": "Rubí rojo",
    "impostorWord": "Zafiro azul"
  },
  {
    "id": "n23",
    "category": "naturaleza",
    "mainWord": "Oro brillante",
    "impostorWord": "Plata pulida"
  },
  {
    "id": "n24",
    "category": "naturaleza",
    "mainWord": "Cobre rojizo",
    "impostorWord": "Bronce antiguo"
  },
  {
    "id": "n25",
    "category": "naturaleza",
    "mainWord": "Fósil de dinosaurio",
    "impostorWord": "Meteorito caído"
  },
  {
    "id": "n26",
    "category": "naturaleza",
    "mainWord": "Ámbar con insecto",
    "impostorWord": "Perla de ostra"
  },
  {
    "id": "n27",
    "category": "naturaleza",
    "mainWord": "Cueva de estalactitas",
    "impostorWord": "Cenote mexicano"
  },
  {
    "id": "n28",
    "category": "naturaleza",
    "mainWord": "Iceberg flotante",
    "impostorWord": "Banquisa polar"
  },
  {
    "id": "n29",
    "category": "naturaleza",
    "mainWord": "Agua mineral manantial",
    "impostorWord": "Agua de lluvia pura"
  },
  {
    "id": "n30",
    "category": "naturaleza",
    "mainWord": "Arena de cuarzo",
    "impostorWord": "Tierra fértil"
  },
  {
    "id": "n31",
    "category": "naturaleza",
    "mainWord": "Gravedad terrestre",
    "impostorWord": "Magnetismo de imán"
  },
  {
    "id": "n32",
    "category": "naturaleza",
    "mainWord": "Átomo diminuto",
    "impostorWord": "Molécula compleja"
  },
  {
    "id": "n33",
    "category": "naturaleza",
    "mainWord": "Electricidad estática",
    "impostorWord": "Corriente eléctrica"
  },
  {
    "id": "n34",
    "category": "naturaleza",
    "mainWord": "Láser rojo",
    "impostorWord": "Rayo ultravioleta"
  },
  {
    "id": "n35",
    "category": "naturaleza",
    "mainWord": "ADN genético",
    "impostorWord": "Célula madre"
  },
  {
    "id": "n36",
    "category": "naturaleza",
    "mainWord": "Saturno con anillos",
    "impostorWord": "Júpiter con la gran mancha"
  },
  {
    "id": "n37",
    "category": "naturaleza",
    "mainWord": "Sol ardiente",
    "impostorWord": "Supernova estelar"
  },
  {
    "id": "n38",
    "category": "naturaleza",
    "mainWord": "Vía Láctea",
    "impostorWord": "Nebulosa brillante"
  },
  {
    "id": "n39",
    "category": "naturaleza",
    "mainWord": "Oxígeno puro",
    "impostorWord": "Helio para globos"
  },
  {
    "id": "n40",
    "category": "naturaleza",
    "mainWord": "Fuego de fogata",
    "impostorWord": "Brasa ardiente"
  },
  {
    "id": "n41",
    "category": "naturaleza",
    "mainWord": "Hielo seco",
    "impostorWord": "Nieve fresca"
  },
  {
    "id": "n42",
    "category": "naturaleza",
    "mainWord": "Lava ardiente",
    "impostorWord": "Magma volcánico"
  },
  {
    "id": "n43",
    "category": "naturaleza",
    "mainWord": "Viento huracanado",
    "impostorWord": "Brisa marina suave"
  },
  {
    "id": "n44",
    "category": "naturaleza",
    "mainWord": "Bosque encantado",
    "impostorWord": "Pantano tenebroso"
  },
  {
    "id": "n45",
    "category": "naturaleza",
    "mainWord": "Pradera verde",
    "impostorWord": "Colina soleada"
  },
  {
    "id": "n46",
    "category": "naturaleza",
    "mainWord": "Pluma de ave",
    "impostorWord": "Escama de reptil"
  },
  {
    "id": "n47",
    "category": "naturaleza",
    "mainWord": "Veneno de serpiente",
    "impostorWord": "Antídoto curativo"
  },
  {
    "id": "n48",
    "category": "naturaleza",
    "mainWord": "Tela de araña",
    "impostorWord": "Capullo de seda"
  },
  {
    "id": "n49",
    "category": "naturaleza",
    "mainWord": "Coral de mar",
    "impostorWord": "Anémona marina"
  },
  {
    "id": "n50",
    "category": "naturaleza",
    "mainWord": "Panal de abejas",
    "impostorWord": "Nido de avispas"
  },
  {
    "id": "n51",
    "category": "naturaleza",
    "mainWord": "Nido de pájaro",
    "impostorWord": "Madriguera bajo tierra"
  },
  {
    "id": "n52",
    "category": "naturaleza",
    "mainWord": "Alga marina",
    "impostorWord": "Musgo de roca"
  },
  {
    "id": "n53",
    "category": "naturaleza",
    "mainWord": "Semilla germinada",
    "impostorWord": "Brote nuevo"
  },
  {
    "id": "n54",
    "category": "naturaleza",
    "mainWord": "Piña de pino",
    "impostorWord": "Bellota de roble"
  },
  {
    "id": "n55",
    "category": "naturaleza",
    "mainWord": "Diente de león",
    "impostorWord": "Trébol de cuatro hojas"
  },
  {
    "id": "n56",
    "category": "naturaleza",
    "mainWord": "Planeta Tierra",
    "impostorWord": "Planeta Neptuno"
  },
  {
    "id": "n57",
    "category": "naturaleza",
    "mainWord": "Estación de primavera",
    "impostorWord": "Estación de otoño"
  },
  {
    "id": "n58",
    "category": "naturaleza",
    "mainWord": "Verano caluroso",
    "impostorWord": "Invierno gélido"
  },
  {
    "id": "n59",
    "category": "naturaleza",
    "mainWord": "Marea alta",
    "impostorWord": "Marea baja"
  },
  {
    "id": "n60",
    "category": "naturaleza",
    "mainWord": "Remolino de agua",
    "impostorWord": "Ola gigante"
  },
  {
    "id": "n61",
    "category": "naturaleza",
    "mainWord": "Espejismo en el desierto",
    "impostorWord": "Ilusión óptica"
  },
  {
    "id": "n62",
    "category": "naturaleza",
    "mainWord": "Nube de algodón",
    "impostorWord": "Nube de tormenta"
  },
  {
    "id": "n63",
    "category": "naturaleza",
    "mainWord": "Eco en la cueva",
    "impostorWord": "Silencio absoluto"
  },
  {
    "id": "n64",
    "category": "naturaleza",
    "mainWord": "Sombra proyectada",
    "impostorWord": "Reflejo en el agua"
  },
  {
    "id": "n65",
    "category": "naturaleza",
    "mainWord": "Cristal de nieve",
    "impostorWord": "Gota de rocío"
  },
  {
    "id": "n66",
    "category": "naturaleza",
    "mainWord": "Cuarzo rosa",
    "impostorWord": "Amatista violeta"
  },
  {
    "id": "n67",
    "category": "naturaleza",
    "mainWord": "Arena movediza",
    "impostorWord": "Lodo espeso"
  },
  {
    "id": "n68",
    "category": "naturaleza",
    "mainWord": "Acantilado sobre el mar",
    "impostorWord": "Barranco profundo"
  },
  {
    "id": "n69",
    "category": "naturaleza",
    "mainWord": "Isla volcánica",
    "impostorWord": "Atolón de coral"
  },
  {
    "id": "n70",
    "category": "naturaleza",
    "mainWord": "Rocío de la mañana",
    "impostorWord": "Escarcha congelada"
  }
];

export function getRandomWordPair(categoryId: string = 'all'): WordItem {
  let pool = WORDS_DATABASE;
  if (categoryId !== 'all') {
    pool = WORDS_DATABASE.filter(w => w.category === categoryId);
    if (pool.length === 0) pool = WORDS_DATABASE;
  }
  const index = Math.floor(Math.random() * pool.length);
  return pool[index];
}
