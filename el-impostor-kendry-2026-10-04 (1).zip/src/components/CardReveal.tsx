import React, { useState } from 'react';
import { Fingerprint, ArrowRight, Play, Eye, EyeOff, Shield } from 'lucide-react';
import { Player } from '../types';
import { sounds } from '../utils/sound';

export const CardReveal: React.FC<{ players: Player[]; category: string; onFinishReveal: () => void }> = ({ players, onFinishReveal }) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [hasViewedCurrent, setHasViewedCurrent] = useState<boolean>(false);

  const currentPlayer = players[currentIndex];
  const isLastPlayer = currentIndex === players.length - 1;

  const handlePressStart = (e: React.SyntheticEvent) => {
    e.preventDefault();
    if (!isFlipped) { setIsFlipped(true); sounds.playFlip(); sounds.playSecretReveal(); }
  };
  const handlePressEnd = (e: React.SyntheticEvent) => {
    e.preventDefault();
    if (isFlipped) { setIsFlipped(false); setHasViewedCurrent(true); sounds.playFlip(); }
  };
  const handleAdvance = () => {
    sounds.playClick();
    if (isLastPlayer) onFinishReveal();
    else { setIsFlipped(false); setHasViewedCurrent(false); setCurrentIndex(prev => prev + 1); }
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 text-white flex flex-col justify-between p-4 sm:p-6 select-none">
      <div className="max-w-md w-full mx-auto flex items-center justify-between py-2">
        <p className="text-sm font-bold text-white">Jugador {currentIndex + 1} de {players.length}</p>
      </div>

      <div className="max-w-sm w-full mx-auto flex-1 flex flex-col items-center justify-center my-4">
        <div
          onPointerDown={handlePressStart} onPointerUp={handlePressEnd} onPointerLeave={handlePressEnd}
          onTouchStart={handlePressStart} onTouchEnd={handlePressEnd}
          className="w-full min-h-[380px] rounded-3xl p-6 bg-slate-900 border-2 border-red-500/60 flex flex-col items-center justify-between text-center cursor-pointer shadow-2xl"
        >
          {!isFlipped ? (
            <>
              <div className="text-5xl">{currentPlayer.avatar}</div>
              <h3 className="text-3xl font-black text-white">{currentPlayer.name}</h3>
              <div className="py-3 px-4 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-300 font-bold">
                Mantén presionado para ver
              </div>
            </>
          ) : (
            <>
              <p className="text-xs uppercase font-bold text-slate-300">Tu palabra secreta es:</p>
              <h2 className="text-3xl font-black text-amber-300 uppercase">{currentPlayer.assignedWord}</h2>
              <p className="text-xs text-slate-400">Suelta para ocultar</p>
            </>
          )}
        </div>
      </div>

      <div className="max-w-md w-full mx-auto pb-4">
        {hasViewedCurrent ? (
          <button onClick={handleAdvance} className="w-full py-4 rounded-2xl bg-red-600 text-white font-black text-lg shadow-xl cursor-pointer">
            {isLastPlayer ? 'Empezar juego' : 'Pasar a otro jugador'}
          </button>
        ) : (
          <p className="text-xs text-slate-500 text-center animate-pulse">👆 Mantén presionada la card para continuar</p>
        )}
      </div>
    </div>
  );
};
