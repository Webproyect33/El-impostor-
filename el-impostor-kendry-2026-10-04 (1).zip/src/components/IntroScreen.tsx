import React, { useState, useEffect, useCallback } from 'react';
import { ChevronRight, Eye, Sparkles } from 'lucide-react';
import { sounds } from '../utils/sound';

const WORDS = ['Cuidado,', 'hay', 'un', 'impostor', 'entre', 'nosotros'];

export const IntroScreen: React.FC<{ onNext: () => void }> = ({ onNext }) => {
  const [revealedCount, setRevealedCount] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  const advance = useCallback(() => {
    setRevealedCount((current) => {
      if (current < WORDS.length) {
        sounds.playWordTick();
        const next = current + 1;
        if (next === WORDS.length) {
          setIsCompleted(true);
          sounds.playDramaticAlert();
        }
        return next;
      } else {
        onNext();
        return current;
      }
    });
  }, [onNext]);

  useEffect(() => {
    if (revealedCount < WORDS.length) {
      const timer = setTimeout(advance, 550);
      return () => clearTimeout(timer);
    }
  }, [revealedCount, advance]);

  return (
    <div onClick={() => !isCompleted && advance()} className="min-h-screen w-full flex flex-col items-center justify-between p-6 bg-radial from-slate-950 via-zinc-950 to-black text-white select-none cursor-pointer relative overflow-hidden">
      <div className="pt-6 text-center z-10">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/60 border border-red-800/40 text-[11px] font-medium uppercase text-red-400">
          <Eye className="w-3.5 h-3.5 animate-pulse" /> Advertencia
        </span>
      </div>
      <div className="flex flex-col items-center justify-center text-center px-4 max-w-xl z-10 my-auto min-h-[160px]">
        <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
          {WORDS.map((word, index) => {
            const isShown = index < revealedCount;
            const isImp = word.toLowerCase() === 'impostor';
            return (
              <span key={index} className={`transition-all duration-300 font-extrabold ${isShown ? 'opacity-100 scale-100' : 'opacity-0 scale-75 pointer-events-none'} ${isImp ? 'text-4xl sm:text-6xl text-red-500 underline underline-offset-8' : 'text-3xl sm:text-5xl text-slate-100'}`}>
                {word}
              </span>
            );
          })}
        </div>
        {!isCompleted && (
          <p className="mt-8 text-xs text-slate-500 animate-pulse flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-red-400" /> Toca la pantalla para apresurar
          </p>
        )}
      </div>
      <div className="w-full max-w-sm pb-8 z-10 text-center">
        {isCompleted && (
          <button onClick={(e) => { e.stopPropagation(); sounds.playClick(); onNext(); }} className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 text-white font-bold text-lg shadow-xl flex items-center justify-center gap-2 cursor-pointer">
            <span>Configurar Jugadores</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
};
