import React, { useState } from 'react';
import { Users, Shuffle, ArrowRight, ArrowLeft, Dices, Sparkles } from 'lucide-react';
import { Player, CategoryId } from '../types';
import { CATEGORIES, getRandomWordPair } from '../data/words';
import { sounds } from '../utils/sound';

const DEFAULT_AVATARS = ['🕵️', '🕶️', '🎭', '🦊', '🐺', '🦁', '🐯', '🦅', '🛸', '🤖', '👾', '🧙', '👑', '🎯', '🐱', '🐼'];
const DEFAULT_COLORS = ['bg-red-500/20 text-red-400 border-red-500/40', 'bg-blue-500/20 text-blue-400 border-blue-500/40', 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40', 'bg-amber-500/20 text-amber-400 border-amber-500/40'];
const RANDOM_NICKNAMES = ['Agente Secreto', 'Sombra', 'El Fantasma', 'Lobo Astuto', 'Ojo de Águila', 'Camaleón', 'Capitán M', 'Infiltrado', 'El Zorro'];

export const PlayerSetup: React.FC<{
  initialPlayers?: Player[];
  onStartGame: (players: Player[], category: string, wordInfo: { mainWord: string; impostorWord: string; category: string }) => void;
  onBackToIntro: () => void;
}> = ({ initialPlayers, onStartGame, onBackToIntro }) => {
  const [subStep, setSubStep] = useState<'count' | 'names'>(initialPlayers && initialPlayers.length > 0 ? 'names' : 'count');
  const [playerCount, setPlayerCount] = useState<number>(initialPlayers && initialPlayers.length > 0 ? initialPlayers.length : 4);
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');

  const [playersData, setPlayersData] = useState(() => {
    if (initialPlayers && initialPlayers.length > 0) return initialPlayers.map(p => ({ id: p.id, name: p.name, avatar: p.avatar, color: p.color }));
    return Array.from({ length: 4 }, (_, i) => ({ id: `p-${i + 1}`, name: `Jugador ${i + 1}`, avatar: DEFAULT_AVATARS[i % DEFAULT_AVATARS.length], color: DEFAULT_COLORS[i % DEFAULT_COLORS.length] }));
  });

  const handleConfirmCount = () => {
    sounds.playClick();
    setPlayersData(Array.from({ length: playerCount }, (_, i) => playersData[i] || { id: `p-${i + 1}`, name: `Jugador ${i + 1}`, avatar: DEFAULT_AVATARS[i % DEFAULT_AVATARS.length], color: DEFAULT_COLORS[i % DEFAULT_COLORS.length] }));
    setSubStep('names');
  };

  const handleLaunchRound = () => {
    sounds.playFanfare();
    const wordPair = getRandomWordPair(selectedCategory);
    const impostorIndex = Math.floor(Math.random() * playersData.length);
    const finalized = playersData.map((p, idx) => ({
      id: p.id, name: p.name.trim() || `Jugador ${idx + 1}`, avatar: p.avatar, color: p.color,
      isImpostor: idx === impostorIndex, assignedWord: idx === impostorIndex ? wordPair.impostorWord : wordPair.mainWord, hasViewedCard: false
    }));
    onStartGame(finalized, selectedCategory, { mainWord: wordPair.mainWord, impostorWord: wordPair.impostorWord, category: wordPair.category });
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col p-4 sm:p-6 select-none">
      <div className="max-w-2xl w-full mx-auto flex items-center justify-between py-2 border-b border-slate-800">
        <h1 className="text-lg font-bold text-white">🕵️ EL IMPOSTOR</h1>
        {subStep === 'names' ? (
          <button onClick={() => setSubStep('count')} className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 cursor-pointer">Cambiar cantidad ({playerCount})</button>
        ) : (
          <button onClick={onBackToIntro} className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 cursor-pointer">Inicio</button>
        )}
      </div>

      <div className="max-w-2xl w-full mx-auto flex-1 flex flex-col justify-center py-6">
        {subStep === 'count' ? (
          <div className="bg-slate-900/70 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 text-center">
            <h2 className="text-2xl sm:text-3xl font-black text-white">¿Cuántos jugadores son?</h2>
            <div className="flex items-center justify-center gap-6 py-4">
              <button onClick={() => setPlayerCount(Math.max(3, playerCount - 1))} className="w-14 h-14 rounded-2xl bg-slate-800 text-2xl font-bold">-</button>
              <span className="text-6xl font-black text-white font-mono">{playerCount}</span>
              <button onClick={() => setPlayerCount(Math.min(20, playerCount + 1))} className="w-14 h-14 rounded-2xl bg-slate-800 text-2xl font-bold">+</button>
            </div>
            <button onClick={handleConfirmCount} className="w-full py-4 rounded-2xl bg-red-600 text-white font-bold text-lg shadow-xl cursor-pointer">Continuar con {playerCount} jugadores</button>
          </div>
        ) : (
          <div className="space-y-6 pb-12">
            <h2 className="text-2xl font-black text-white text-center">Nombres de los Jugadores</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {playersData.map((player, idx) => (
                <div key={player.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center gap-3">
                  <span className="text-2xl">{player.avatar}</span>
                  <input type="text" maxLength={18} value={player.name} onChange={(e) => {
                    const up = [...playersData]; up[idx].name = e.target.value; setPlayersData(up);
                  }} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-sm text-white outline-none" />
                </div>
              ))}
            </div>
            <button onClick={handleLaunchRound} className="w-full py-4 rounded-2xl bg-red-600 text-white font-black text-lg shadow-xl cursor-pointer flex items-center justify-center gap-2">
              <Sparkles className="w-5 h-5" />
              <span>Elegir Palabra y Repartir</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
