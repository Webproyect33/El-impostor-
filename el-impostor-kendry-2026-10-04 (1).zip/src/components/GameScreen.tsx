import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Play, Eye, Timer } from 'lucide-react';
import { Player } from '../types';
import { sounds } from '../utils/sound';

export const GameScreen: React.FC<{
  players: Player[];
  wordInfo: { mainWord: string; impostorWord: string; category: string };
  onRestartNewGame: () => void;
  onPlayAnotherRound: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}> = ({ players, wordInfo, onRestartNewGame, onPlayAnotherRound }) => {
  const [startingPlayer, setStartingPlayer] = useState<Player | null>(null);
  const [showReveal, setShowReveal] = useState(false);
  const impostor = players.find(p => p.isImpostor) || players[0];

  useEffect(() => {
    const chosen = players[Math.floor(Math.random() * players.length)];
    setStartingPlayer(chosen);
    sounds.playFanfare();
    confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
  }, [players]);

  return (
    <div className="min-h-screen w-full bg-slate-950 text-white flex flex-col justify-between p-4 sm:p-6 select-none">
      <div className="max-w-2xl w-full mx-auto py-2 border-b border-slate-800 flex justify-between">
        <h1 className="text-base font-black text-white">EL IMPOSTOR</h1>
        <span className="text-xs text-emerald-400 font-bold">¡Ronda en Curso!</span>
      </div>

      <div className="max-w-2xl w-full mx-auto flex-1 flex flex-col justify-center py-6 space-y-6 text-center">
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="text-6xl">{startingPlayer?.avatar}</div>
          <h2 className="text-3xl font-black text-white">¡Empieza {startingPlayer?.name}!</h2>
          <p className="text-xs text-slate-400">Debe decir una pista sobre su palabra sin regalarla.</p>
        </div>

        <button onClick={() => setShowReveal(!showReveal)} className="py-3 px-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 cursor-pointer">
          {showReveal ? 'Ocultar Solución' : '¿Terminaron de debatir? Revelar Impostor'}
        </button>

        {showReveal && (
          <div className="p-4 rounded-2xl bg-red-950/60 border border-red-500 space-y-2">
            <p className="text-xs text-red-400 uppercase font-bold">El Impostor era: {impostor.name} ({impostor.avatar})</p>
            <p className="text-xs text-slate-300">Palabra impostor: <strong className="text-amber-300">"{impostor.assignedWord}"</strong></p>
            <p className="text-xs text-slate-300">Palabra del grupo: <strong className="text-emerald-400">"{wordInfo.mainWord}"</strong></p>
          </div>
        )}
      </div>

      <div className="max-w-2xl w-full mx-auto pt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button onClick={onPlayAnotherRound} className="py-4 rounded-2xl bg-red-600 text-white font-bold cursor-pointer">Jugar otra ronda</button>
        <button onClick={onRestartNewGame} className="py-4 rounded-2xl bg-slate-900 text-slate-300 border border-slate-800 font-semibold cursor-pointer">Reiniciar</button>
      </div>
    </div>
  );
};
