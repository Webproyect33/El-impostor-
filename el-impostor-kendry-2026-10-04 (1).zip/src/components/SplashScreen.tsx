import React, { useEffect, useState } from 'react';
import { ShieldAlert, UserCheck } from 'lucide-react';

export const SplashScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 400);
          return 100;
        }
        const increment = Math.floor(Math.random() * 8) + 4;
        return Math.min(100, prev + increment);
      });
    }, 90);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-between p-6 bg-gradient-to-b from-slate-950 via-gray-900 to-black text-white select-none relative overflow-hidden">
      <div className="w-full pt-4"></div>
      <div className="flex flex-col items-center justify-center text-center z-10 space-y-6 max-w-sm px-4">
        <div className="relative">
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-red-600 via-rose-700 to-amber-900 p-1 shadow-2xl shadow-red-900/50 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950/90 rounded-[22px] flex items-center justify-center relative overflow-hidden backdrop-blur-md">
              <ShieldAlert className="w-14 h-14 text-red-500 drop-shadow-[0_0_15px_rgba(239,68,68,0.8)]" />
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 bg-red-600 text-white p-1.5 rounded-full border-2 border-slate-950 shadow-md">
            <UserCheck className="w-4 h-4" />
          </div>
        </div>
        <div className="space-y-1">
          <h1 className="text-4xl sm:text-5xl font-black tracking-wider uppercase bg-clip-text text-transparent bg-gradient-to-r from-red-500 via-rose-300 to-red-600">
            EL IMPOSTOR
          </h1>
          <p className="text-xs sm:text-sm font-medium text-slate-400 tracking-widest uppercase">
            Juego de Fiesta & Deducción
          </p>
        </div>
        <div className="w-full max-w-xs space-y-2 pt-4">
          <div className="w-full h-2.5 bg-slate-800/90 rounded-full p-0.5 overflow-hidden border border-slate-700/50">
            <div className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 rounded-full transition-all duration-150 ease-out" style={{ width: `${progress}%` }}></div>
          </div>
          <div className="flex justify-between items-center text-[11px] text-slate-400 font-mono">
            <span>Cargando palabras secretas...</span>
            <span className="text-red-400 font-semibold">{progress}%</span>
          </div>
        </div>
      </div>
      <div className="z-10 pb-4 text-center">
        <p className="text-[12px] text-slate-500 font-light tracking-wide">created by <span className="font-semibold text-slate-400">Kendry</span></p>
      </div>
    </div>
  );
};
