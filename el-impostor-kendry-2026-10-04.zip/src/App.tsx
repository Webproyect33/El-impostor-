import React, { useState } from 'react';
import { GamePhase, Player } from './types';
import { SplashScreen } from './components/SplashScreen';
import { IntroScreen } from './components/IntroScreen';
import { PlayerSetup } from './components/PlayerSetup';
import { CardReveal } from './components/CardReveal';
import { GameScreen } from './components/GameScreen';
import { getRandomWordPair } from './data/words';
import { sounds } from './utils/sound';

export const App: React.FC = () => {
  const [phase, setPhase] = useState<GamePhase>('splash');
  const [players, setPlayers] = useState<Player[]>([]);
  const [category, setCategory] = useState<string>('all');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [wordInfo, setWordInfo] = useState<{
    mainWord: string;
    impostorWord: string;
    category: string;
  }>({
    mainWord: '',
    impostorWord: '',
    category: '',
  });

  const handleToggleSound = () => {
    const newState = sounds.toggleSound();
    setSoundEnabled(newState);
  };

  const handleStartGameRound = (
    configuredPlayers: Player[],
    chosenCategory: string,
    wordData: { mainWord: string; impostorWord: string; category: string }
  ) => {
    setPlayers(configuredPlayers);
    setCategory(chosenCategory);
    setWordInfo(wordData);
    setPhase('card_reveal');
  };

  const handlePlayAnotherRound = () => {
    sounds.playFanfare();
    const wordPair = getRandomWordPair(category);
    const impostorIndex = Math.floor(Math.random() * players.length);

    const reDistributedPlayers: Player[] = players.map((p, idx) => {
      const isImp = idx === impostorIndex;
      return {
        ...p,
        isImpostor: isImp,
        assignedWord: isImp ? wordPair.impostorWord : wordPair.mainWord,
        hasViewedCard: false,
      };
    });

    setPlayers(reDistributedPlayers);
    setWordInfo({
      mainWord: wordPair.mainWord,
      impostorWord: wordPair.impostorWord,
      category: wordPair.category,
    });
    setPhase('card_reveal');
  };

  const handleRestartNewGame = () => {
    sounds.playClick();
    setPhase('player_count');
  };

  return (
    <div className="min-h-screen w-full bg-black font-sans text-slate-100 antialiased selection:bg-red-500 selection:text-white">
      {phase === 'splash' && <SplashScreen onComplete={() => setPhase('intro')} />}
      {phase === 'intro' && <IntroScreen onNext={() => setPhase('player_count')} />}
      {(phase === 'player_count' || phase === 'player_names') && (
        <PlayerSetup
          initialPlayers={players.length > 0 ? players : undefined}
          onStartGame={handleStartGameRound}
          onBackToIntro={() => setPhase('intro')}
        />
      )}
      {phase === 'card_reveal' && (
        <CardReveal
          players={players}
          category={category}
          onFinishReveal={() => setPhase('game_active')}
        />
      )}
      {phase === 'game_active' && (
        <GameScreen
          players={players}
          wordInfo={wordInfo}
          onRestartNewGame={handleRestartNewGame}
          onPlayAnotherRound={handlePlayAnotherRound}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
        />
      )}
    </div>
  );
};
export default App;
