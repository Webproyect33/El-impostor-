# 🕵️ El Impostor - Juego de Deducción y Fiesta
Creado por Kendry

## 📱 ¿Cómo generar tu archivo .APK en GitHub automáticamente?

1. Sube este archivo `.zip` a tu repositorio de GitHub (o arrástralo directamente a los archivos de tu repositorio).
2. Asegúrate de tener el archivo `.github/workflows/build-apk.yml` en tu repositorio.
3. El workflow se activará automáticamente con cada subida o puedes iniciarlo manualmente desde la pestaña **Actions** en GitHub.
4. Cuando termine (en aprox. 2-3 minutos), descarga el archivo **`El-Impostor-APK-Debug`** en la sección **Artifacts** del run de GitHub Actions.
5. ¡Instala el archivo `.apk` en tu teléfono Android y juega con tus amigos!
