import React, { useState } from 'react';
import { Users, User, Shuffle, ArrowRight, ArrowLeft, Dices, Sparkles, CheckCircle2 } from 'lucide-react';
import { Player, CategoryId } from '../types';
import { CATEGORIES, getRandomWordPair } from '../data/words';
import { sounds } from '../utils/sound';

interface PlayerSetupProps {
  initialPlayers?: Player[];
  onStartGame: (players: Player[], category: string, wordInfo: { mainWord: string; impostorWord: string; category: string }) => void;
  onBackToIntro: () => void;
}

const DEFAULT_AVATARS = ['🕵️', '🕶️', '🎭', '🦊', '🐺', '🦁', '🐯', '🦅', '🛸', '🤖', '👾', '🧙', '👑', '🎯', '🐱', '🐼'];
const DEFAULT_COLORS = [
  'bg-red-500/20 text-red-400 border-red-500/40',
  'bg-blue-500/20 text-blue-400 border-blue-500/40',
  'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
  'bg-amber-500/20 text-amber-400 border-amber-500/40',
  'bg-purple-500/20 text-purple-400 border-purple-500/40',
  'bg-pink-500/20 text-pink-400 border-pink-500/40',
  'bg-cyan-500/20 text-cyan-400 border-cyan-500/40',
  'bg-orange-500/20 text-orange-400 border-orange-500/40',
];

const RANDOM_NICKNAMES = [
  'Agente Secreto', 'Sombra', 'El Fantasma', 'Lobo Astuto', 'Ojo de Águila',
  'Camaleón', 'Capitán M', 'Infiltrado', 'El Zorro', 'Misterio X',
  'Cyber Ninja', 'Espía 007', 'Detective', 'Halcón Veloz', 'Silencioso'
];

export const PlayerSetup: React.FC<PlayerSetupProps> = ({ initialPlayers, onStartGame, onBackToIntro }) => {
  // Setup Sub-phases: 'count' | 'names'
  const [subStep, setSubStep] = useState<'count' | 'names'>(initialPlayers && initialPlayers.length > 0 ? 'names' : 'count');
  const [playerCount, setPlayerCount] = useState<number>(initialPlayers && initialPlayers.length > 0 ? initialPlayers.length : 4);
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');

  // Players state
  const [playersData, setPlayersData] = useState<Array<{ id: string; name: string; avatar: string; color: string }>>(() => {
    if (initialPlayers && initialPlayers.length > 0) {
      return initialPlayers.map(p => ({
        id: p.id,
        name: p.name,
        avatar: p.avatar,
        color: p.color
      }));
    }
    return Array.from({ length: 4 }, (_, i) => ({
      id: `p-${i + 1}`,
      name: `Jugador ${i + 1}`,
      avatar: DEFAULT_AVATARS[i % DEFAULT_AVATARS.length],
      color: DEFAULT_COLORS[i % DEFAULT_COLORS.length],
    }));
  });

  // Handle player count adjustment
  const handleCountChange = (newCount: number) => {
    const clamped = Math.max(3, Math.min(20, newCount));
    setPlayerCount(clamped);
    sounds.playClick();
  };

  // When confirming player count, construct players list with defaults
  const handleConfirmCount = () => {
    sounds.playClick();
    const updated = Array.from({ length: playerCount }, (_, i) => {
      if (playersData[i]) {
        return playersData[i];
      }
      return {
        id: `p-${i + 1}`,
        name: `Jugador ${i + 1}`,
        avatar: DEFAULT_AVATARS[i % DEFAULT_AVATARS.length],
        color: DEFAULT_COLORS[i % DEFAULT_COLORS.length],
      };
    });
    setPlayersData(updated);
    setSubStep('names');
  };

  // Update a single player's name
  const handleNameChange = (index: number, newName: string) => {
    const updated = [...playersData];
    updated[index] = { ...updated[index], name: newName };
    setPlayersData(updated);
  };

  // Randomize nickname for a player
  const handleRandomizeName = (index: number) => {
    sounds.playClick();
    const randomNick = RANDOM_NICKNAMES[Math.floor(Math.random() * RANDOM_NICKNAMES.length)];
    const randomAvatar = DEFAULT_AVATARS[Math.floor(Math.random() * DEFAULT_AVATARS.length)];
    const updated = [...playersData];
    updated[index] = { ...updated[index], name: randomNick, avatar: randomAvatar };
    setPlayersData(updated);
  };

  // Cycle avatar for a player
  const handleCycleAvatar = (index: number) => {
    sounds.playClick();
    const currentAvatar = playersData[index].avatar;
    const currentIdx = DEFAULT_AVATARS.indexOf(currentAvatar);
    const nextAvatar = DEFAULT_AVATARS[(currentIdx + 1) % DEFAULT_AVATARS.length];
    const updated = [...playersData];
    updated[index] = { ...updated[index], avatar: nextAvatar };
    setPlayersData(updated);
  };

  // Proceed to game: Select random word & select 1 Impostor
  const handleLaunchRound = () => {
    sounds.playFanfare();

    // 1. Pick a random word pair from database (500+ items)
    const wordPair = getRandomWordPair(selectedCategory);

    // 2. Select 1 random player to be the impostor
    const impostorIndex = Math.floor(Math.random() * playersData.length);

    // 3. Assemble complete players objects with secret words
    const finalizedPlayers: Player[] = playersData.map((p, idx) => {
      const isImp = idx === impostorIndex;
      const finalName = p.name.trim() || `Jugador ${idx + 1}`;
      return {
        id: p.id,
        name: finalName,
        avatar: p.avatar,
        color: p.color,
        isImpostor: isImp,
        assignedWord: isImp ? wordPair.impostorWord : wordPair.mainWord,
        hasViewedCard: false,
      };
    });

    onStartGame(finalizedPlayers, selectedCategory, {
      mainWord: wordPair.mainWord,
      impostorWord: wordPair.impostorWord,
      category: wordPair.category,
    });
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col p-4 sm:p-6 select-none">
      {/* Top Header */}
      <div className="max-w-2xl w-full mx-auto flex items-center justify-between py-2 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400 font-black">
            🕵️
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white">EL IMPOSTOR</h1>
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Configuración</p>
          </div>
        </div>

        {subStep === 'names' ? (
          <button
            onClick={() => {
              sounds.playClick();
              setSubStep('count');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Cambiar cantidad ({playerCount})</span>
          </button>
        ) : (
          <button
            onClick={() => {
              sounds.playClick();
              onBackToIntro();
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Inicio</span>
          </button>
        )}
      </div>

      {/* Main Content Area */}
      <div className="max-w-2xl w-full mx-auto flex-1 flex flex-col justify-center py-6">
        {subStep === 'count' ? (
          /* STEP 1: PLAYER COUNT SELECTION */
          <div className="bg-slate-900/70 border border-slate-800/90 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl space-y-8 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="inline-flex p-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 mb-2">
                <Users className="w-8 h-8" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white">¿Cuántos jugadores son?</h2>
              <p className="text-sm text-slate-400 max-w-sm mx-auto">
                Reúne a tus amigos. Se necesita un mínimo de 3 jugadores para jugar.
              </p>
            </div>

            {/* Stepper counter */}
            <div className="flex items-center justify-center gap-6 py-4">
              <button
                onClick={() => handleCountChange(playerCount - 1)}
                disabled={playerCount <= 3}
                className="w-14 h-14 rounded-2xl bg-slate-800 border border-slate-700/80 text-2xl font-bold flex items-center justify-center hover:bg-slate-700 active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer shadow-md"
              >
                -
              </button>

              <div className="flex flex-col items-center">
                <span className="text-6xl sm:text-7xl font-black text-white font-mono tracking-tight drop-shadow-[0_0_20px_rgba(239,68,68,0.4)]">
                  {playerCount}
                </span>
                <span className="text-xs text-slate-400 uppercase font-semibold tracking-widest mt-1">Jugadores</span>
              </div>

              <button
                onClick={() => handleCountChange(playerCount + 1)}
                disabled={playerCount >= 20}
                className="w-14 h-14 rounded-2xl bg-slate-800 border border-slate-700/80 text-2xl font-bold flex items-center justify-center hover:bg-slate-700 active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer shadow-md"
              >
                +
              </button>
            </div>

            {/* Quick preset buttons */}
            <div className="space-y-2">
              <p className="text-xs text-slate-500 font-medium text-center uppercase tracking-wider">Accesos rápidos</p>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {[3, 4, 5, 6, 8, 10, 12].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleCountChange(num)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      playerCount === num
                        ? 'bg-red-600 text-white shadow-md shadow-red-900/40 border border-red-400'
                        : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 border border-slate-700/50'
                    }`}
                  >
                    {num} jugadores
                  </button>
                ))}
              </div>
            </div>

            {/* Confirm button */}
            <button
              onClick={handleConfirmCount}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-lg shadow-xl shadow-red-950/60 flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer border border-red-400/30"
            >
              <span>Continuar con {playerCount} jugadores</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        ) : (
          /* STEP 2: PLAYER NAMES & CATEGORY SELECTION */
          <div className="space-y-6 animate-fadeIn pb-12">
            <div className="text-center space-y-1">
              <h2 className="text-2xl sm:text-3xl font-black text-white">Nombres de los Jugadores</h2>
              <p className="text-xs sm:text-sm text-slate-400">
                Elige un nombre personalizado para cada jugador o usa el nombre por defecto.
              </p>
            </div>

            {/* Category Selector */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 backdrop-blur-md">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Dices className="w-4 h-4 text-red-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Categoría de Palabras (+500 opciones)
                  </span>
                </div>
                <span className="text-[11px] text-red-400 font-semibold bg-red-950/60 px-2 py-0.5 rounded-md border border-red-800/40">
                  Base de datos lista
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {CATEGORIES.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        sounds.playClick();
                        setSelectedCategory(cat.id as CategoryId);
                      }}
                      className={`flex items-center gap-2 p-2.5 rounded-xl text-left text-xs font-semibold transition-all cursor-pointer border ${
                        isSelected
                          ? 'bg-gradient-to-r from-red-900/50 to-rose-900/50 border-red-500 text-white shadow-md'
                          : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                      }`}
                    >
                      <span className="text-base">{cat.icon}</span>
                      <span className="truncate">{cat.name.split(' (')[0]}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Players List Form */}
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Lista de Jugadores ({playersData.length})
                </span>
                <span className="text-[11px] text-slate-500">Toca el avatar para cambiarlo</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {playersData.map((player, idx) => (
                  <div
                    key={player.id}
                    className="bg-slate-900/80 border border-slate-800 hover:border-slate-700/90 rounded-2xl p-3 flex items-center gap-3 transition-all backdrop-blur shadow-sm"
                  >
                    {/* Interactive Avatar button */}
                    <button
                      type="button"
                      onClick={() => handleCycleAvatar(idx)}
                      title="Toca para cambiar avatar"
                      className="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 hover:border-slate-500 flex items-center justify-center text-xl shrink-0 cursor-pointer active:scale-95 transition-transform"
                    >
                      {player.avatar}
                    </button>

                    {/* Name Input */}
                    <div className="flex-1 min-w-0">
                      <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-0.5">
                        Jugador {idx + 1}
                      </label>
                      <input
                        type="text"
                        maxLength={18}
                        value={player.name}
                        onChange={(e) => handleNameChange(idx, e.target.value)}
                        placeholder={`Jugador ${idx + 1}`}
                        className="w-full bg-slate-950/70 border border-slate-700/70 focus:border-red-500 focus:ring-1 focus:ring-red-500 rounded-lg px-2.5 py-1.5 text-sm font-semibold text-white placeholder-slate-500 outline-none transition-all"
                      />
                    </div>

                    {/* Randomize Nickname Button */}
                    <button
                      type="button"
                      onClick={() => handleRandomizeName(idx)}
                      title="Nombre aleatorio divertido"
                      className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer shrink-0"
                    >
                      <Shuffle className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Launch Round Button */}
            <div className="pt-4">
              <button
                onClick={handleLaunchRound}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-lg sm:text-xl shadow-2xl shadow-red-950/80 flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer border border-red-400/40"
              >
                <Sparkles className="w-6 h-6 text-amber-300 animate-pulse" />
                <span>Elegir Palabra y Repartir</span>
                <ArrowRight className="w-6 h-6" />
              </button>
              <p className="text-center text-[11px] text-slate-500 mt-2">
                Se seleccionará al azar una palabra de la base de datos y un impostor secreto.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
