import React, { useState, useEffect, useCallback } from 'react';
import { ChevronRight, Eye, Sparkles } from 'lucide-react';
import { sounds } from '../utils/sound';

interface IntroScreenProps {
  onNext: () => void;
}

const WORDS = ['Cuidado,', 'hay', 'un', 'impostor', 'entre', 'nosotros'];

export const IntroScreen: React.FC<IntroScreenProps> = ({ onNext }) => {
  const [revealedCount, setRevealedCount] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  // Advance by one word or complete if already at end
  const advance = useCallback(() => {
    setRevealedCount((current) => {
      if (current < WORDS.length) {
        sounds.playWordTick();
        const next = current + 1;
        if (next === WORDS.length) {
          setIsCompleted(true);
          sounds.playDramaticAlert();
        }
        return next;
      } else {
        // If already completed and user taps, advance to next phase
        onNext();
        return current;
      }
    });
  }, [onNext]);

  // Automated typing interval
  useEffect(() => {
    if (revealedCount < WORDS.length) {
      const timer = setTimeout(() => {
        advance();
      }, 550);
      return () => clearTimeout(timer);
    }
  }, [revealedCount, advance]);

  // Handle tap / click anywhere on screen to speed up
  const handleScreenTap = () => {
    if (!isCompleted) {
      advance();
    }
  };

  return (
    <div
      onClick={handleScreenTap}
      className="min-h-screen w-full flex flex-col items-center justify-between p-6 bg-radial from-slate-950 via-zinc-950 to-black text-white select-none cursor-pointer relative overflow-hidden"
    >
      {/* Dynamic glow spotlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/15 rounded-full blur-[100px] pointer-events-none"></div>

      {/* Top indicator */}
      <div className="pt-6 text-center z-10">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/60 border border-red-800/40 text-[11px] font-medium uppercase tracking-widest text-red-400 backdrop-blur-md">
          <Eye className="w-3.5 h-3.5 animate-pulse" /> Advertencia
        </span>
      </div>

      {/* Word-by-word reveal container */}
      <div className="flex flex-col items-center justify-center text-center px-4 max-w-xl z-10 my-auto min-h-[160px]">
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-3 sm:gap-x-4 sm:gap-y-4">
          {WORDS.map((word, index) => {
            const isShown = index < revealedCount;
            const isImpostorWord = word.toLowerCase() === 'impostor';

            return (
              <span
                key={index}
                className={`transition-all duration-300 font-extrabold tracking-wide ${
                  isShown
                    ? 'opacity-100 scale-100 translate-y-0'
                    : 'opacity-0 scale-75 translate-y-3 pointer-events-none'
                } ${
                  isImpostorWord
                    ? 'text-4xl sm:text-6xl text-red-500 underline decoration-red-600/70 underline-offset-8 drop-shadow-[0_0_20px_rgba(239,68,68,0.8)]'
                    : 'text-3xl sm:text-5xl text-slate-100 drop-shadow-md'
                }`}
              >
                {word}
              </span>
            );
          })}
        </div>

        {/* Speed up hint */}
        {!isCompleted && (
          <p className="mt-8 text-xs text-slate-500 animate-pulse flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-red-400" /> Toca la pantalla para apresurar
          </p>
        )}
      </div>

      {/* Bottom Action */}
      <div className="w-full max-w-sm pb-8 z-10 text-center flex flex-col items-center space-y-3">
        {isCompleted ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              sounds.playClick();
              onNext();
            }}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-lg shadow-xl shadow-red-950/60 flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer border border-red-400/30"
          >
            <span>Configurar Jugadores</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        ) : (
          <div className="text-[12px] text-slate-500 font-mono">
            Mostrando mensaje... ({revealedCount}/{WORDS.length})
          </div>
        )}
      </div>
    </div>
  );
};
