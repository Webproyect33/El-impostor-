import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Play, Eye, Timer, CheckCircle, HelpCircle, Dices, Crown, AlertTriangle, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { Player } from '../types';
import { sounds } from '../utils/sound';

interface GameScreenProps {
  players: Player[];
  wordInfo: {
    mainWord: string;
    impostorWord: string;
    category: string;
  };
  onRestartNewGame: () => void;
  onPlayAnotherRound: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  players,
  wordInfo,
  onRestartNewGame,
  onPlayAnotherRound,
  soundEnabled,
  onToggleSound,
}) => {
  const [startingPlayer, setStartingPlayer] = useState<Player | null>(null);
  const [isSelectingStarter, setIsSelectingStarter] = useState<boolean>(true);
  const [highlightedIndex, setHighlightedIndex] = useState<number>(0);
  const [showRevealModal, setShowRevealModal] = useState<boolean>(false);
  const [showRules, setShowRules] = useState<boolean>(false);

  // Timer state
  const [timerSeconds, setTimerSeconds] = useState<number>(180); // 3 minutes default
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  // Impostor info
  const impostorPlayer = players.find((p) => p.isImpostor) || players[0];

  // Random selection animation for who starts
  useEffect(() => {
    let iteration = 0;
    const totalIterations = 18 + Math.floor(Math.random() * 8);
    const chosenIndex = Math.floor(Math.random() * players.length);

    const interval = setInterval(() => {
      iteration++;
      sounds.playRouletteTick();
      setHighlightedIndex((prev) => (prev + 1) % players.length);

      if (iteration >= totalIterations) {
        clearInterval(interval);
        setHighlightedIndex(chosenIndex);
        setStartingPlayer(players[chosenIndex]);
        setIsSelectingStarter(false);
        sounds.playFanfare();

        // Confetti explosion
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#ec4899'],
        });
      }
    }, 90 + iteration * 6);

    return () => clearInterval(interval);
  }, [players]);

  // Discussion Timer Effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            sounds.playDramaticAlert();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timerSeconds]);

  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 text-white flex flex-col justify-between p-4 sm:p-6 select-none relative overflow-x-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-[120px] pointer-events-none"></div>

      {/* Top Header Bar */}
      <div className="max-w-2xl w-full mx-auto flex items-center justify-between py-2 border-b border-slate-800/80 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400 font-bold">
            🕵️
          </div>
          <div>
            <h1 className="text-base font-black tracking-tight text-white">EL IMPOSTOR</h1>
            <p className="text-[10px] text-emerald-400 uppercase font-semibold tracking-wider">
              ¡Ronda en Curso!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Rules info */}
          <button
            onClick={() => {
              sounds.playClick();
              setShowRules(!showRules);
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Cómo jugar"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              onToggleSound();
              sounds.playClick();
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title={soundEnabled ? 'Silenciar sonido' : 'Activar sonido'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>
        </div>
      </div>

      {/* Main Game In Progress Content */}
      <div className="max-w-2xl w-full mx-auto flex-1 flex flex-col justify-center py-6 space-y-6 z-10">
        {/* WHO STARTS ANNOUNCEMENT BANNER */}
        <div className="bg-gradient-to-b from-slate-900 via-slate-900/90 to-zinc-950 border border-slate-800/90 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-600 via-amber-500 to-rose-600"></div>

          {isSelectingStarter ? (
            /* Roulette Animation */
            <div className="py-6 space-y-4">
              <div className="inline-flex p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 animate-spin">
                <Dices className="w-8 h-8" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Eligiendo quién empieza la ronda...
              </h2>
              <div className="flex items-center justify-center gap-3">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-amber-500 flex items-center justify-center text-3xl shadow-lg">
                  {players[highlightedIndex]?.avatar}
                </div>
                <div className="text-left">
                  <p className="text-xs text-slate-400 font-semibold uppercase">Candidato</p>
                  <p className="text-lg font-bold text-amber-400">{players[highlightedIndex]?.name}</p>
                </div>
              </div>
            </div>
          ) : (
            /* Starting Player Chosen Announcement */
            <div className="py-2 space-y-5">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>Jugador Inicial</span>
              </div>

              <div className="flex flex-col items-center space-y-2">
                <div className="relative">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-br from-amber-500/20 to-red-600/20 border-2 border-amber-500/80 flex items-center justify-center text-5xl sm:text-6xl shadow-xl shadow-amber-950/40">
                    {startingPlayer?.avatar}
                  </div>
                  <span className="absolute -bottom-2.5 bg-amber-500 text-slate-950 font-black text-[11px] px-2.5 py-0.5 rounded-full uppercase shadow">
                    Empieza
                  </span>
                </div>

                <div className="pt-2">
                  <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight drop-shadow-md">
                    ¡Empieza {startingPlayer?.name}!
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md mx-auto">
                    Debe decir una palabra o pista relacionada con su palabra secreta. Luego continúa el jugador a su izquierda/derecha.
                  </p>
                </div>
              </div>

              {/* Instructions Summary Pill */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 text-left text-xs text-slate-300">
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span><strong>Jugadores normales:</strong> Da pistas sutiles para que el resto sepa que sabes la palabra sin regalársela al impostor.</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-start gap-2">
                  <span className="text-red-400 font-bold">⚠️</span>
                  <span><strong>El impostor:</strong> Tu palabra es ligeramente distinta. ¡Presta atención a las pistas para no ser descubierto!</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* DISCUSSION TIMER WIDGET */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-800 text-slate-300">
              <Timer className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Tiempo de debate</p>
              <p className="text-2xl font-black font-mono text-white">{formatTime(timerSeconds)}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sounds.playClick();
                setIsTimerRunning(!isTimerRunning);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isTimerRunning
                  ? 'bg-amber-600 hover:bg-amber-500 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {isTimerRunning ? 'Pausar' : 'Iniciar'}
            </button>
            <button
              onClick={() => {
                sounds.playClick();
                setIsTimerRunning(false);
                setTimerSeconds(180);
              }}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Reiniciar reloj
            </button>
          </div>
        </div>

        {/* PLAYERS IN THIS ROUND */}
        <div className="bg-slate-900/40 border border-slate-800/60 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Jugadores en la partida ({players.length})
            </span>
            <span className="text-[11px] text-red-400 font-medium">Hay 1 impostor oculto</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {players.map((p) => {
              const isStarter = p.id === startingPlayer?.id;
              return (
                <div
                  key={p.id}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                    isStarter
                      ? 'bg-amber-500/15 border-amber-500/60 text-amber-300 shadow-sm'
                      : 'bg-slate-800/50 border-slate-700/50 text-slate-300'
                  }`}
                >
                  <span className="text-base">{p.avatar}</span>
                  <span className="truncate max-w-[100px]">{p.name}</span>
                  {isStarter && <span className="text-[10px] text-amber-400 font-black">👑</span>}
                </div>
              );
            })}
          </div>
        </div>

        {/* REVEAL SOLUTION BUTTON */}
        <button
          onClick={() => {
            sounds.playClick();
            setShowRevealModal(true);
          }}
          className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Eye className="w-4 h-4 text-red-400" />
          <span>¿Terminaron de debatir? Revelar quién era el Impostor</span>
        </button>
      </div>

      {/* BOTTOM ACTION BUTTONS: REINICIAR & JUGAR OTRA RONDA */}
      <div className="max-w-2xl w-full mx-auto pt-4 pb-2 border-t border-slate-800/80 z-10 grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* JUGAR OTRA RONDA (same players) */}
        <button
          onClick={() => {
            sounds.playClick();
            onPlayAnotherRound();
          }}
          className="py-3.5 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-bold text-base shadow-xl shadow-red-950/60 flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer border border-red-400/30"
        >
          <Play className="w-4 h-4 fill-white text-white" />
          <span>Jugar otra ronda</span>
        </button>

        {/* REINICIAR (asks player count again) */}
        <button
          onClick={() => {
            sounds.playClick();
            onRestartNewGame();
          }}
          className="py-3.5 px-6 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white font-semibold text-base border border-slate-700/80 flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer"
        >
          <RotateCcw className="w-4 h-4 text-slate-400" />
          <span>Reiniciar</span>
        </button>
      </div>

      {/* ================= REVEAL & VOTING MODAL ================= */}
      {showRevealModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-5 animate-scaleUp">
            <div className="text-center space-y-1">
              <span className="text-4xl">🕵️‍♂️</span>
              <h3 className="text-2xl font-black text-white">¡Resultado de la Ronda!</h3>
              <p className="text-xs text-slate-400">Aquí tienes las palabras secretas asignadas:</p>
            </div>

            {/* The Impostor Card */}
            <div className="p-4 rounded-2xl bg-red-950/50 border-2 border-red-500/70 text-center space-y-2 shadow-inner">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-600 text-white font-black text-[10px] uppercase tracking-wider">
                <AlertTriangle className="w-3 h-3" /> El Impostor era
              </div>

              <div className="flex items-center justify-center gap-3">
                <span className="text-4xl">{impostorPlayer.avatar}</span>
                <div className="text-left">
                  <h4 className="text-xl font-black text-white">{impostorPlayer.name}</h4>
                  <p className="text-xs text-red-300 font-mono">
                    Palabra impostora: <span className="font-bold text-amber-300 text-sm">"{impostorPlayer.assignedWord}"</span>
                  </p>
                </div>
              </div>
            </div>

            {/* The Group's Word */}
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-center">
              <p className="text-[11px] text-slate-400 uppercase font-semibold">Palabra del grupo:</p>
              <p className="text-xl font-black text-emerald-400 uppercase tracking-wide">
                "{wordInfo.mainWord}"
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setShowRevealModal(false)}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Cerrar
              </button>
              <button
                onClick={() => {
                  setShowRevealModal(false);
                  onPlayAnotherRound();
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Siguiente Ronda
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= RULES MODAL ================= */}
      {showRules && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-lg font-black text-white flex items-center gap-2">
                <span>📖</span> ¿Cómo se juega?
              </h3>
              <button
                onClick={() => setShowRules(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed max-h-[60vh] overflow-y-auto pr-1">
              <p>
                <strong>1. El Turno de Pistas:</strong> Comenzando por el jugador inicial elegido por la app, cada participante dice por turnos una sola palabra o frase corta relacionada con su palabra secreta.
              </p>
              <p>
                <strong>2. El Reto del Impostor:</strong> El impostor tiene una palabra distinta (por ejemplo, si todos tienen <em>"Pizza"</em>, el impostor puede tener <em>"Hamburguesa"</em>). Debe fingir que sabe la palabra común y evitar que sospechen de él.
              </p>
              <p>
                <strong>3. El Debate y Votación:</strong> Tras una o dos rondas de pistas, los jugadores debaten y señalan a la de tres a quién creen que es el impostor.
              </p>
              <p>
                <strong>4. Victoria:</strong>
                <br />• Los inocentes ganan si descubren al impostor.
                <br />• El impostor gana si no lo descubren o si adivina la palabra del grupo.
              </p>
            </div>

            <button
              onClick={() => setShowRules(false)}
              className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              ¡Entendido, a jugar!
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
