import React, { useState } from 'react';
import { Fingerprint, ArrowRight, Play, Eye, EyeOff, Shield } from 'lucide-react';
import { Player } from '../types';
import { sounds } from '../utils/sound';

interface CardRevealProps {
  players: Player[];
  category: string;
  onFinishReveal: () => void;
}

export const CardReveal: React.FC<CardRevealProps> = ({ players, onFinishReveal }) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [hasViewedCurrent, setHasViewedCurrent] = useState<boolean>(false);

  const currentPlayer = players[currentIndex];
  const isLastPlayer = currentIndex === players.length - 1;

  // Touch and hold handlers
  const handlePressStart = (e: React.SyntheticEvent) => {
    e.preventDefault();
    if (!isFlipped) {
      setIsFlipped(true);
      sounds.playFlip();
      sounds.playSecretReveal();
    }
  };

  const handlePressEnd = (e: React.SyntheticEvent) => {
    e.preventDefault();
    if (isFlipped) {
      setIsFlipped(false);
      setHasViewedCurrent(true);
      sounds.playFlip();
    }
  };

  // Next player or start game
  const handleAdvance = () => {
    sounds.playClick();
    if (isLastPlayer) {
      onFinishReveal();
    } else {
      setIsFlipped(false);
      setHasViewedCurrent(false);
      setCurrentIndex((prev) => prev + 1);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-950 via-zinc-950 to-black text-white flex flex-col justify-between p-4 sm:p-6 select-none overflow-hidden">
      {/* Top Header info */}
      <div className="max-w-md w-full mx-auto flex items-center justify-between py-2 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-red-600/20 border border-red-500/40 flex items-center justify-center text-sm font-bold text-red-400">
            {currentIndex + 1}
          </div>
          <div>
            <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Turno Secreto</p>
            <p className="text-sm font-bold text-white">Jugador {currentIndex + 1} de {players.length}</p>
          </div>
        </div>

        <div className="flex gap-1">
          {players.map((_, idx) => (
            <div
              key={idx}
              className={`h-1.5 rounded-full transition-all ${
                idx === currentIndex
                  ? 'w-6 bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]'
                  : idx < currentIndex
                  ? 'w-2 bg-emerald-500'
                  : 'w-2 bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Center 3D Flip Card Container */}
      <div className="max-w-sm w-full mx-auto flex-1 flex flex-col items-center justify-center my-4 z-10">
        <div className="w-full relative [perspective:1200px]">
          {/* Card element with 3D transform */}
          <div
            onPointerDown={handlePressStart}
            onPointerUp={handlePressEnd}
            onPointerLeave={handlePressEnd}
            onPointerCancel={handlePressEnd}
            onTouchStart={handlePressStart}
            onTouchEnd={handlePressEnd}
            onTouchCancel={handlePressEnd}
            onContextMenu={(e) => e.preventDefault()}
            style={{
              transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
              transformStyle: 'preserve-3d',
            }}
            className={`w-full min-h-[380px] sm:min-h-[420px] rounded-3xl transition-transform duration-500 ease-out cursor-pointer relative shadow-2xl ${
              isFlipped
                ? 'shadow-red-600/40'
                : 'shadow-black/80 hover:shadow-slate-800/50'
            }`}
          >
            {/* ================= CARD FRONT (Player Name & Hold prompt) ================= */}
            <div
              style={{ backfaceVisibility: 'hidden' }}
              className="absolute inset-0 w-full h-full rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-slate-900 via-slate-950 to-zinc-900 border-2 border-slate-700/60 flex flex-col items-center justify-between text-center overflow-hidden"
            >
              {/* Decorative background grid pattern */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none opacity-40"></div>

              {/* Card top badge */}
              <div className="w-full flex items-center justify-between text-[11px] font-mono text-slate-500 uppercase tracking-wider z-10">
                <span className="flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-red-400" /> CONFIDENCIAL
                </span>
                <span>N° {currentIndex + 1}</span>
              </div>

              {/* Player Identifier */}
              <div className="flex flex-col items-center space-y-3 z-10 my-auto">
                <div className="relative">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-slate-800/90 border-2 border-slate-600/60 flex items-center justify-center text-5xl sm:text-6xl shadow-inner shadow-black">
                    {currentPlayer.avatar}
                  </div>
                  <div className="absolute -bottom-2 bg-red-600 text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-full text-white uppercase border border-slate-900 shadow">
                    Turno
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">¿Eres tú?</p>
                  <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight break-words px-2 drop-shadow-md">
                    {currentPlayer.name}
                  </h3>
                </div>
              </div>

              {/* Instruction to Hold */}
              <div className="w-full z-10 pt-2">
                <div className="py-3 px-4 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-300 flex items-center justify-center gap-2.5 text-sm font-bold shadow-lg animate-pulse">
                  <Fingerprint className="w-5 h-5 text-red-400" />
                  <span>Mantén presionado para ver</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 font-medium">
                  Nadie más debe ver la pantalla
                </p>
              </div>
            </div>

            {/* ================= CARD BACK (Revealed Secret Word) ================= */}
            <div
              style={{
                backfaceVisibility: 'hidden',
                transform: 'rotateY(180deg)',
              }}
              className="absolute inset-0 w-full h-full rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-red-950 via-slate-950 to-rose-950 border-2 border-red-500 flex flex-col items-center justify-between text-center overflow-hidden shadow-[inset_0_0_30px_rgba(239,68,68,0.3)]"
            >
              {/* Top status */}
              <div className="w-full flex items-center justify-between text-[11px] font-mono text-red-400 uppercase tracking-wider z-10">
                <span className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-amber-400 animate-spin" /> PALABRA SECRETA
                </span>
                <span className="font-bold text-white">{currentPlayer.name}</span>
              </div>

              {/* Secret Word Display */}
              <div className="flex flex-col items-center justify-center space-y-3 z-10 my-auto">
                <span className="text-xs sm:text-sm font-bold uppercase tracking-widest text-slate-300">
                  Tu palabra es:
                </span>

                <div className="p-4 sm:p-5 rounded-2xl bg-black/70 border border-red-500/60 shadow-2xl backdrop-blur-lg max-w-full">
                  <h2 className="text-3xl sm:text-4xl font-black text-amber-300 tracking-wide uppercase drop-shadow-[0_0_20px_rgba(252,211,77,0.8)] break-words">
                    {currentPlayer.assignedWord}
                  </h2>
                </div>

                <p className="text-xs text-red-300/90 font-medium px-4">
                  Memorízala y disimula ante los demás.
                </p>
              </div>

              {/* Bottom hint when holding */}
              <div className="w-full z-10 pt-2">
                <div className="py-2.5 px-4 rounded-xl bg-slate-900/80 border border-slate-700/60 text-slate-300 flex items-center justify-center gap-2 text-xs font-semibold">
                  <EyeOff className="w-4 h-4 text-slate-400" />
                  <span>Suelta la pantalla para ocultar</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Actions Area */}
      <div className="max-w-md w-full mx-auto pb-4 z-10 min-h-[80px] flex flex-col items-center justify-center">
        {hasViewedCurrent ? (
          <button
            onClick={handleAdvance}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-lg shadow-xl shadow-red-950/80 flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer border border-red-400/40 animate-bounceIn"
          >
            {isLastPlayer ? (
              <>
                <Play className="w-5 h-5 fill-white text-white" />
                <span>Empezar juego</span>
              </>
            ) : (
              <>
                <span>Pasar a otro jugador</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        ) : (
          <p className="text-xs text-slate-500 text-center font-medium animate-pulse">
            👆 Toca y mantén presionada la card para continuar
          </p>
        )}
      </div>
    </div>
  );
};
