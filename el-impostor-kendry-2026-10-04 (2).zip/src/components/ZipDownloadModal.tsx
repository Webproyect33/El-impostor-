import React, { useState } from 'react';
import { Download, Copy, Check, FileCode2, Smartphone, Github, Sparkles, X, Terminal, ArrowRight } from 'lucide-react';
import { generateProjectZip, GITHUB_WORKFLOW_YML } from '../utils/zipGenerator';
import { sounds } from '../utils/sound';

interface ZipDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ZipDownloadModal: React.FC<ZipDownloadModalProps> = ({ isOpen, onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'download' | 'workflow' | 'guide'>('download');

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    try {
      sounds.playClick();
      setIsGenerating(true);
      const blob = await generateProjectZip();
      
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `el-impostor-kendry-${new Date().toISOString().slice(0, 10)}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      sounds.playFanfare();
      setIsGenerating(false);
    } catch (err) {
      console.error('Error generating zip:', err);
      setIsGenerating(false);
    }
  };

  const handleCopyWorkflow = async () => {
    try {
      sounds.playClick();
      await navigator.clipboard.writeText(GITHUB_WORKFLOW_YML);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 p-0.5 flex items-center justify-center text-white shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                Generador de APK para GitHub
              </h3>
              <p className="text-[11px] text-slate-400">
                Descarga el ZIP listo para compilar en GitHub Actions
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/30 px-4 pt-2 gap-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab('download')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer ${
              activeTab === 'download'
                ? 'border-red-500 text-red-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            1. Descargar ZIP
          </button>
          <button
            onClick={() => setActiveTab('workflow')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer ${
              activeTab === 'workflow'
                ? 'border-red-500 text-red-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            2. Workflow GitHub Actions (.yml)
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer ${
              activeTab === 'guide'
                ? 'border-red-500 text-red-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            3. Instrucciones Paso a Paso
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'download' && (
            <div className="space-y-4 text-center py-2">
              <div className="w-16 h-16 rounded-3xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
                <Download className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h4 className="text-xl font-bold text-white">Descargar Paquete ZIP Completo</h4>
                <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
                  El archivo <code>.zip</code> incluye todo el código fuente, la base de datos de +500 palabras, configuración de Capacitor para Android y el workflow automático.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-left text-xs text-slate-300 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                  <Check className="w-4 h-4" />
                  <span>Compatibilidad Multi-Zip garantizada</span>
                </div>
                <p className="text-slate-400 pl-6">
                  Si subes múltiples archivos <code>.zip</code> a tu repositorio, el workflow de GitHub Actions detectará automáticamente el archivo añadido o modificado más recientemente y lo compilará.
                </p>
              </div>

              <button
                onClick={handleDownloadZip}
                disabled={isGenerating}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-base shadow-xl shadow-red-950/60 flex items-center justify-center gap-2 transform active:scale-95 transition-all cursor-pointer border border-red-400/30 disabled:opacity-50"
              >
                {isGenerating ? (
                  <span>Generando archivo ZIP...</span>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 text-amber-300" />
                    <span>Descargar ZIP para GitHub (.zip)</span>
                  </>
                )}
              </button>
            </div>
          )}

          {activeTab === 'workflow' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <FileCode2 className="w-4 h-4 text-amber-400" />
                    .github/workflows/build-apk.yml
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Workflow preparado para buscar el .zip más reciente y devolver el .apk
                  </p>
                </div>

                <button
                  onClick={handleCopyWorkflow}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all cursor-pointer shadow"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>¡Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar Workflow</span>
                    </>
                  )}
                </button>
              </div>

              <div className="relative rounded-2xl bg-slate-950 border border-slate-800 p-3 overflow-x-auto text-[11px] font-mono text-emerald-300 max-h-72">
                <pre>{GITHUB_WORKFLOW_YML}</pre>
              </div>
            </div>
          )}

          {activeTab === 'guide' && (
            <div className="space-y-3 text-xs text-slate-300">
              <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-full bg-red-600/30 border border-red-500/50 text-red-400 flex items-center justify-center font-bold shrink-0 text-xs">
                    1
                  </div>
                  <div>
                    <strong className="text-white block">Crea tu repositorio en GitHub</strong>
                    <span>Crea un repositorio en GitHub (puede ser público o privado).</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-full bg-red-600/30 border border-red-500/50 text-red-400 flex items-center justify-center font-bold shrink-0 text-xs">
                    2
                  </div>
                  <div>
                    <strong className="text-white block">Sube el archivo .zip</strong>
                    <span>
                      Sube o arrastra el archivo <code>.zip</code> descargado en la pestaña 1 a tu repositorio. Puedes subir nuevas versiones en cualquier momento con nuevos nombres de archivo <code>.zip</code>.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-full bg-red-600/30 border border-red-500/50 text-red-400 flex items-center justify-center font-bold shrink-0 text-xs">
                    3
                  </div>
                  <div>
                    <strong className="text-white block">Agrega el Workflow de GitHub Actions</strong>
                    <span>
                      Crea el archivo en la ruta <code>.github/workflows/build-apk.yml</code> y pega el código de la pestaña 2.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-full bg-red-600/30 border border-red-500/50 text-red-400 flex items-center justify-center font-bold shrink-0 text-xs">
                    4
                  </div>
                  <div>
                    <strong className="text-white block">Descarga tu .APK compilado</strong>
                    <span>
                      Ve a la pestaña <strong>Actions</strong> en GitHub. Al finalizar el job (tarda 2-3 minutos), haz clic en el run y en la sección inferior <strong>Artifacts</strong> descarga <strong>El-Impostor-APK-Debug</strong>. ¡Listo para instalar en Android!
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white transition-colors cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
