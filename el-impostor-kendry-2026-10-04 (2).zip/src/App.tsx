import React, { useState } from 'react';
import { GamePhase, Player } from './types';
import { SplashScreen } from './components/SplashScreen';
import { IntroScreen } from './components/IntroScreen';
import { PlayerSetup } from './components/PlayerSetup';
import { CardReveal } from './components/CardReveal';
import { GameScreen } from './components/GameScreen';
import { ZipDownloadModal } from './components/ZipDownloadModal';
import { getRandomWordPair } from './data/words';
import { sounds } from './utils/sound';
import { Download, Sparkles } from 'lucide-react';

export const App: React.FC = () => {
  const [phase, setPhase] = useState<GamePhase>('splash');
  const [players, setPlayers] = useState<Player[]>([]);
  const [category, setCategory] = useState<string>('all');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isZipModalOpen, setIsZipModalOpen] = useState<boolean>(false);
  const [wordInfo, setWordInfo] = useState<{
    mainWord: string;
    impostorWord: string;
    category: string;
  }>({
    mainWord: '',
    impostorWord: '',
    category: '',
  });

  // Sound toggle
  const handleToggleSound = () => {
    const newState = sounds.toggleSound();
    setSoundEnabled(newState);
  };

  // Launch game round with newly distributed words
  const handleStartGameRound = (
    configuredPlayers: Player[],
    chosenCategory: string,
    wordData: { mainWord: string; impostorWord: string; category: string }
  ) => {
    setPlayers(configuredPlayers);
    setCategory(chosenCategory);
    setWordInfo(wordData);
    setPhase('card_reveal');
  };

  // Play another round with the same players
  const handlePlayAnotherRound = () => {
    sounds.playFanfare();
    // Pick new random word pair
    const wordPair = getRandomWordPair(category);
    // Pick new random impostor
    const impostorIndex = Math.floor(Math.random() * players.length);

    const reDistributedPlayers: Player[] = players.map((p, idx) => {
      const isImp = idx === impostorIndex;
      return {
        ...p,
        isImpostor: isImp,
        assignedWord: isImp ? wordPair.impostorWord : wordPair.mainWord,
        hasViewedCard: false,
      };
    });

    setPlayers(reDistributedPlayers);
    setWordInfo({
      mainWord: wordPair.mainWord,
      impostorWord: wordPair.impostorWord,
      category: wordPair.category,
    });
    setPhase('card_reveal');
  };

  // Reset to player count setup (as requested by user)
  const handleRestartNewGame = () => {
    sounds.playClick();
    setPhase('player_count');
  };

  return (
    <div className="min-h-screen w-full bg-black font-sans text-slate-100 antialiased selection:bg-red-500 selection:text-white relative">
      {/* Floating Preview Button to Download ZIP & GitHub Actions Workflow */}
      <div className="fixed top-3 right-3 z-40">
        <button
          onClick={() => {
            sounds.playClick();
            setIsZipModalOpen(true);
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 text-xs font-bold shadow-lg shadow-emerald-950/60 backdrop-blur-md transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Descargar ZIP (APK GitHub)</span>
          <span className="sm:hidden">ZIP APK</span>
        </button>
      </div>

      {phase === 'splash' && (
        <SplashScreen onComplete={() => setPhase('intro')} />
      )}

      {phase === 'intro' && (
        <IntroScreen onNext={() => setPhase('player_count')} />
      )}

      {(phase === 'player_count' || phase === 'player_names') && (
        <PlayerSetup
          initialPlayers={players.length > 0 ? players : undefined}
          onStartGame={handleStartGameRound}
          onBackToIntro={() => setPhase('intro')}
        />
      )}

      {phase === 'card_reveal' && (
        <CardReveal
          players={players}
          category={category}
          onFinishReveal={() => setPhase('game_active')}
        />
      )}

      {phase === 'game_active' && (
        <GameScreen
          players={players}
          wordInfo={wordInfo}
          onRestartNewGame={handleRestartNewGame}
          onPlayAnotherRound={handlePlayAnotherRound}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
        />
      )}

      {/* ZIP & Workflow Generator Modal */}
      <ZipDownloadModal
        isOpen={isZipModalOpen}
        onClose={() => setIsZipModalOpen(false)}
      />
    </div>
  );
};

export default App;
