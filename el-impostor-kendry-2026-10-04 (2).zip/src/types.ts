export type GamePhase = 
  | 'splash'
  | 'intro'
  | 'player_count'
  | 'player_names'
  | 'card_reveal'
  | 'game_active';

export interface Player {
  id: string;
  name: string;
  avatar: string;
  color: string;
  isImpostor: boolean;
  assignedWord: string;
  hasViewedCard: boolean;
  score?: number;
}

export interface WordItem {
  id: string;
  category: string;
  mainWord: string;
  impostorWord: string;
  hint?: string;
}

export type CategoryId = 'all' | 'animales' | 'comida' | 'objetos' | 'lugares' | 'profesiones' | 'deportes' | 'cotidiano' | 'peliculas' | 'naturaleza';
