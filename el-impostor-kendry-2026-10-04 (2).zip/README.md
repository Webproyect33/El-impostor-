# 🕵️ El Impostor - Creado por Kendry

Subir este archivo ZIP a GitHub para compilar automáticamente el APK.